# Fire-flow-orchestrator — System Flow

> The end-to-end picture of how a `Ready-For-AI` ticket becomes an attached implementation plan,
> and how the system keeps source code inside org infrastructure the whole time.

## Core principle
- **Knowledge graph (`repo.db`) = the MAP.** Code structure (nodes/edges) + vectors. ONE file per
  repo. PURE CODE STRUCTURE — no Jira, no docs, no file bodies.
- **The repo clone = the TERRITORY.** Real file contents, docs, configs. The local LLM reads it live.
- The **local LLM reads BOTH** (it's local/trusted). The brain stays lean; file bodies are read live,
  never stuffed into the graph.
- **Source code never leaves.** Only sanitized names + summaries + small bounded, secret-scrubbed
  snippets cross to the external LLM, and only after the egress guard passes them.

---

## 1. Big picture — three phases

```mermaid
flowchart LR
    subgraph DONE["✅ Phase 1 (done)"]
        A1["Fetch Jira ticket"]
        A2["Clone / pull repo"]
    end
    subgraph BRAIN["🧠 Phase 2 — Build the brain (nightly)"]
        B1["Parse CODE structure"] --> B2["Build graph + Jira memory"] --> B3["Local embeddings"] --> B4["ONE lean file: repo.db"]
    end
    subgraph USE["🤖 Phase 3 — Use the brain (per ticket)"]
        C1["LOCAL LLM agent<br/>(graph + files + skills)"] --> C2["Iterative loop w/ EXTERNAL LLM"] --> C3["Plan.md → attach to Jira"]
    end
    DONE --> BRAIN --> USE
```

## 2. One full pass (per cron tick)

```mermaid
flowchart TD
    CRON["⏱ cron tick (CRON_SCHEDULE)"] --> Q["Fetch QUEUE: board tickets labeled Ready-For-AI"]
    Q --> EMPTY{"any tickets?"}
    EMPTY -- "no" --> SKIP["skip board — no repo pull, nothing wasted"]
    EMPTY -- "yes" --> REPO["Fetch repo (clone/pull) + runKg (refresh brain if commit changed)"]
    REPO --> LOOP["For each ticket, one at a time →"]
    LOOP --> PLAN["Two-LLM loop → output/KEY-plan.md"]
    PLAN --> WB["Write back: attach plan → comment → flip label LAST"]
    WB --> MORE{"more tickets?"}
    MORE -- "yes" --> LOOP
    MORE -- "no" --> CLEAN["Board cleared? remove clone (keep brain)"]
```

**Ordering matters:** the queue is fetched FIRST (cheap). The repo is pulled and the brain refreshed
only when there is actual work. When a board is fully cleared the clone is removed to free disk; the
brain (`repo.db`) is kept so re-indexing later stays cheap.

## 3. Build the brain — indexing flow (makes the LEAN `repo.db`)

`runKg()` is a checkpoint: it skips when the indexed commit equals HEAD, rebuilds on new commits or a
schema change, and builds from scratch when the brain is missing.

```mermaid
flowchart TD
    S["git pull repo"] --> T["Walk file tree → File / Folder nodes (paths only, NO bodies)"]
    T --> U["tree-sitter parse C# + TS → Class / Method / Function + call/inherit/implement edges"]
    U --> V["Parse extras → ApiEndpoint / DatabaseTable / Terraform Module"]
    V --> W["Bridge → match frontend HTTP calls to ApiEndpoint (front↔back)"]
    W --> X["🔒 Redact secrets (before anything is stored)"]
    X --> Y["Generate embeddings LOCALLY (transformers.js, 384-dim) for every node"]
    Y --> Z["Write → data/kg/repo-name.db"]
    note["❌ Jira, docs & raw file bodies are NOT stored.<br/>Ticket fetched live; file bodies read live from the clone."]:::n -.-> Z
    classDef n fill:#fff3cd,stroke:#b8860b,color:#000
```

## 4. Use the brain — the iterative agent loop (one ticket → Plan.md)

The **external LLM drives** (asks for what it needs). The **local LLM is the secure librarian**
(answers from graph + files). A **notebook** (messages array = conversation memory) grows each round,
is resent whole every call, lives only for this ticket, and is discarded after. **Hard cap: 10
external calls** (configurable via `external.maxCalls`).

```mermaid
flowchart TD
    J["Jira ticket in"] --> K["LOCAL: gatherContext() builds INITIAL findings (graph + files)"]
    K --> NB["Open notebook = [system planner prompt, ticket + initial findings]"]
    NB --> RND{"calls < maxCalls ?"}
    RND -- "no (cap hit)" --> CAP["status: capped → keep label for retry → next ticket"]
    RND -- "yes" --> SEND["Send WHOLE notebook → EXTERNAL planner  (call++)"]
    SEND --> REP{"Planner reply?"}
    REP -- "ask: a question" --> SCREEN["🔒 INBOUND screen (localGuard): extraction / injection?"]
    SCREEN -- "blocked" --> REF["Refuse: answer with a safe note"] --> APP
    SCREEN -- "ok" --> SRC["LOCAL gathers it:<br/>• search_graph(repo.db) + neighbors<br/>• read_file / grep (live clone)<br/>• bounded, scrubbed snippets"]
    SRC --> G{"🔒 EGRESS GUARD<br/>secret? whole-file dump? oversize?"}
    G -- "fail" --> SAFE["Replace with a safe note (ask narrower)"] --> APP
    G -- "pass" --> APP["Append answer to notebook"] --> RND
    REP -- "FINAL_PLAN: ..." --> P["Plan.md (how it works today, what to change, steps, tests, risks)"]
    P --> Q["Write output/KEY-plan.md + KEY-chat.md → write back to Jira → discard notebook → next ticket"]
```

## 5. The security boundary (the non-negotiable rule)

```mermaid
flowchart LR
    subgraph ZA["ZONE A — TRUSTED (local, on-prem)"]
        direction TB
        DB[("repo.db<br/>graph + vectors")]
        FS[("repo clone<br/>files · docs")]
        LL["LOCAL LLM (Qwen)<br/>reads graph + files"]
        DB --- LL
        FS --- LL
    end
    subgraph ZB["ZONE B — UNTRUSTED (external, NO code)"]
        EL["EXTERNAL LLM (Azure Foundry)<br/>planning only — drives the loop"]
    end
    LL -->|"every round"| GUARD["🔒 EGRESS GUARD<br/>names + summaries + bounded scrubbed snippets · fail-closed"] --> EL
    EL -->|"asks for more / submits plan"| LL
    EL --> PLAN["Plan.md"]
```

**Rule:** the external LLM never touches files. Its requests are answered by the local LLM from the
graph + live files. Every outbound message — initial findings AND every follow-up answer — passes the
egress guard, which blocks secrets, whole-file dumps, and oversize payloads while allowing the minimum
bounded context needed to plan. `src/external/egressClient.js` is the only place external HTTP is
allowed, and it writes a content-free audit line for every send/reply/block.

## 6. What the LOCAL LLM can use (its toolbox)

```mermaid
flowchart LR
    LL["LOCAL LLM (Zone A agent)"]
    LL --> GQ["search_graph(repo.db) + neighbors<br/>structural + semantic discovery — the MAP"]
    LL --> RF["read_file / list_files / grep<br/>real content from the clone — the TERRITORY"]
    GQ --> ANS["Sanitized answer: names + summaries + bounded scrubbed snippets"]
    RF --> ANS
```

In this flow, `gatherContext()` digs deterministically (search → neighbors on the top hits →
read the exact symbol bodies → grep docs), the model only summarizes the gathered evidence, and every
cited path/symbol is validated against the brain before it is trusted.

## 7. Write-back to Jira (the commit point)

```mermaid
flowchart LR
    PL["plan ready: output/KEY-plan.md"] --> AT["addAttachment(KEY, plan.md)"]
    AT --> CM["addComment(KEY, 'AI analysis done …')"]
    CM --> LB["setLabels: remove Ready-For-AI, add AI-Analysis-Done"]
    LB --> DONE["ticket done — drops out of next queue"]
    PL -.->|"plan failed / capped"| KEEP["leave Ready-For-AI → retried next pass"]
```

The label flip is **last** on purpose: if attach or comment fails, the ticket keeps `Ready-For-AI` and
is retried. **Status is never touched — only the label.**

---

## Build status — all steps done

| # | Step | Files | State |
|---|------|-------|-------|
| 1 | DB foundation (lean) | `src/kg/schema.js`, `init.js` | ✅ |
| 2 | File tree → nodes | `src/kg/build.js` | ✅ ~2304 File / 597 Folder |
| 3 | Secret redaction | `src/security/redact.js` | ✅ |
| 4 | Code graph + extras + bridge | `src/kg/graph.js`, `parse.js`, `bridge.js` | ✅ ~1737 Class / ~4405 Method / 116 ApiEndpoint |
| 5 | Embeddings + search | `src/kg/embed.js`, `src/retrieval/repoDb.js` | ✅ 9332 embedded |
| 6 | Local librarian | `src/agent/tools.js`, `local.js`, `analyze.js` | ✅ gatherContext + validation |
| 7 | Egress + local guards | `src/security/egressGuard.js`, `localGuard.js` | ✅ fail-closed |
| 8 | Loop + external planner | `src/agent/loop.js`, `src/llm/external.js`, `src/external/egressClient.js` | ✅ notebook, 10-cap |
| 9 | Jira write-back | `src/jira.js` (addComment / addAttachment / setLabels) | ✅ attach + comment + label |
| 10 | Flow + cron | `src/flow.js`, `src/cron.js`, `src/kg/index.js` | ✅ queue → plan → write-back → cleanup |

## Models
- **Local (dev):** `qwen2.5-coder:7b` via Ollama (CPU). Non-thinking, code-tuned, clean tool calls.
  Kept resident between calls via `keepAlive`. Larger/GPU target: `qwen3-coder:30b-a3b`.
- **External:** Azure AI Foundry (OpenAI-compatible chat/completions). Endpoint/model/key in `.env`.
