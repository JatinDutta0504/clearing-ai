# Fire-flow-orchestrator

Automation that reads each `Ready-For-AI` Jira ticket, understands the relevant code in the linked
repository, writes a developer-ready implementation plan, and attaches that plan back to the ticket —
**without the source code ever leaving org infrastructure.**

It runs on a cron timer: every interval it fetches the labeled tickets, processes them one by one,
and flips each finished ticket's label so it is never processed twice.

---

## The non-negotiable rule

> **Source code MUST NEVER leave org infrastructure.**

Two LLMs, two trust zones:

- **LOCAL LLM (Zone A — trusted).** Runs on-prem (Qwen via Ollama). It is the only model that sees
  code. It reads the knowledge graph (`repo.db`) and the live repo clone to understand the ticket.
- **EXTERNAL LLM (Zone B — untrusted).** A hosted planner (Azure AI Foundry). It **drives** the
  conversation (asks questions, then writes the plan) but **never sees the codebase** — only names,
  summaries, relationships, and small bounded, secret-scrubbed snippets that pass the egress guard.

Every message that crosses to the external LLM is validated by a **fail-closed egress guard**:
secrets and whole-file dumps are blocked; only the minimum context needed to plan is allowed through.

---

## How it works (per ticket)

```
Jira ticket ──► LOCAL librarian gathers context (graph + files)
                       │
                       ▼
        ┌──────────  NOTEBOOK  ──────────┐   (conversation, max 10 external calls)
        │  EXTERNAL planner asks a question │
        │  LOCAL librarian answers (guarded)│   ← repeats until the planner has enough
        └────────────────┬─────────────────┘
                         ▼
              EXTERNAL planner writes Plan.md
                         ▼
        attach Plan.md  +  comment  +  flip label  →  next ticket
```

- The **knowledge graph (`repo.db`) is the MAP** — code structure (nodes/edges) + vectors. One file
  per repo. Pure code structure: **no Jira data, no docs, no raw file bodies.**
- The **repo clone is the TERRITORY** — the local LLM reads real file contents live from it.
- The **notebook** is the conversation memory for one ticket. It is resent whole each round and
  discarded when the ticket is done.

See [FLOW.md](FLOW.md) for the full diagrams and [SETUP.md](SETUP.md) for the from-scratch runbook.

---

## The full flow (one cron pass)

`runFlow()` in [src/flow.js](src/flow.js), per active board:

1. **Fetch the queue first** — tickets on the board labeled `Ready-For-AI`. If none, the board is
   skipped entirely (no repo pull, no indexing for nothing).
2. **Fetch the repo + refresh the brain** — `fetchRepo` (clone or pull) then `runKg` (rebuilds the
   knowledge graph only if the commit changed; otherwise skips — cheap).
3. **Process each ticket, one at a time** (each isolated — one failure never stops the rest):
   - fetch the full ticket live (summary + description),
   - run the two-LLM loop → `output/<KEY>-plan.md`,
   - **write back in commit order:** attach the plan → add a comment → flip the label
     `Ready-For-AI` → `AI-Analysis-Done` **last**. The label flip is the commit point: if anything
     earlier fails, the ticket keeps `Ready-For-AI` and is retried next pass. **Status is never
     changed — only the label.**
4. **Free disk when a board is fully cleared** — if every queued ticket was planned, the clone is
   removed (the brain `repo.db` is kept, so re-indexing later stays cheap). Any failed ticket keeps
   its label, so the clone is kept for the retry.

Idempotency is automatic: planned tickets drop out of the next queue; failed ones come back around.

---

## The confidence score (computed, not guessed)

Every plan opens with a **Confidence assessment** — a percentage and a GOOD TO GO / REQUIRES REVIEW
decision. That number is produced by **our own code** in [src/agent/confidence.js](src/agent/confidence.js),
**not** by the external planner. The planner is told to emit a `CONFIDENCE_PLACEHOLDER` line; the
orchestrator computes the real score and replaces that section before the plan is saved
([applyConfidence in loop.js](src/agent/loop.js)).

### Why the external LLM is not trusted with this

An LLM asked "how confident are you, as a percentage?" has **no measuring device**. It does not run
the arithmetic in a scoring rubric — it emits the token that *reads* confident. In practice that is
almost always **85%**, for three reasons that stack:

1. **85 is its default "fairly sure" value** — the most common such number in its training data.
2. **It anchors to the pass threshold.** Told "GOOD TO GO if above 80%," it parks just above the line.
3. **It would justify backward.** Given a rubric, it writes a number first and then invents drivers to
   match — the score is decoration, not a measurement.

The result was the same **85%** on every ticket. A number that never moves carries zero information,
and a self-reported score cannot be audited. So we do not ask the model for it.

### How the score is computed

The local librarian's retrieval pipeline ([analyze.js](src/agent/analyze.js)) already gathers and
**verifies** evidence against the code graph on every call. We accumulate those signals across the
whole ticket (initial findings + every follow-up answer) and deduct from a base of 100:

| Signal (a checked fact, not an opinion) | Deduction if missing/bad |
|---|---|
| Semantic matches found (`search_graph`) | none found → −40 (retrieval is blind) |
| Real code bodies read | none → −20 (names only, nothing verified) |
| Bounded snippets that reached the planner | none → −10 |
| Relationships resolved (the call chain) | none → −15 (flow can't be traced) |
| **Suspect file paths** — cited but NOT in the repo | −8 each (cap −24) |
| **Suspect symbols** — cited but NOT in the repo | −5 each (cap −20) |
| Test files near the affected area | none → −10 (no coverage to mirror) |
| Documentation/conventions found nearby | none → −5 |

The **suspect** rows are the key trust signal: the pipeline checks every path and symbol the model
cited and flags anything that does not exist in the graph — this is the same validator that has caught
the model fabricating columns and methods. The plan prints a clean **drivers list** with the point
cost shown inline `(−N)` on anything that lowered the score, so it reads well and stays auditable —
you can check each driver against the code yourself:

```
## Confidence assessment
Overall confidence: 80%  ·  Decision: ✅ GOOD TO GO

Confidence drivers:
- Verified code references: 15 found and confirmed in the codebase
- End-to-end flow: traced (22 relationships resolved)
- Code reviewed: 9 area(s) read, 6 shared for planning
- Test coverage: none found for the affected area  (−10)
- Documentation: none found nearby  (−5)
- Unverified references (cited but not found in the codebase): DeleteMany  (−5)
```

The score is **deterministic** (same ticket → same number), **moves** with real evidence quality
(a clean ticket scores ~95–100, a thin one drops well below 80), and follows the project rule that
**no result is ever hardcoded or estimated** — it is computed from verified data. One honest limit:
the score measures **grounding** (how well the plan is anchored to confirmed code), not whether the
proposed fix is *correct* — no automatic score can judge that; that still needs a human reviewer.

---

## Repository layout

```
.env                       secrets (gitignored)
.env.example               template for .env
config/boards.json         boards → repos + fetch settings + labels   ← the one project config
config/ai.json             local + external model settings (host, model, maxCalls)

src/config.js              loads/validates env + both config files; ROOT, repoDbPath()
src/jira.js                Jira Cloud REST client — read (issues/boards) + write (comment/attach/label)
src/github.js              repo clone / pull (fetchRepo) + clone cleanup (removeRepo)
src/index.js               CLI: --ready, --list-boards, --board-issues, --issue, --jira-only, --repo-only
src/job.js                 phase-1 helpers (runJira / runRepos / runOnce)

src/kg/                    THE BRAIN BUILDER (one file per concern)
  schema.js                DB blueprint: openDb(), tables, meta helpers
  init.js                  create the empty db
  build.js                 git file tree → File/Folder nodes
  graph.js                 tree-sitter code graph (C# + TS): Class/Method/Function + edges
  parse.js                 ApiEndpoint / DatabaseTable / Terraform Module parsers
  bridge.js                match frontend HTTP calls → ApiEndpoint (connect front↔back)
  embed.js                 embeddings (transformers.js, 384-dim) + embedQuery()
  index.js                 runKg() orchestrator + checkpoint (skip/build/rebuild)

src/retrieval/repoDb.js    read-only graph + vector search (cosine), neighbors(), test down-ranking

src/agent/                 THE LOCAL LIBRARIAN (Zone A)
  tools.js                 the 5 read-only tools: search_graph / neighbors / list_files / read_file / grep
  local.js                 askLocal(): Ollama tool-calling loop (chatOnce)
  analyze.js               gatherContext(): deterministic dig → model summary → citation validation
  confidence.js            deterministic, evidence-based confidence score (computed, not LLM-guessed)
  loop.js                  planTicket(): the notebook loop (external drives, local answers, 10-cap)
  eval.js                  retrieval quality eval harness

src/security/              THE TWO DOORS (fail-closed)
  redact.js                secret scrubber (redactSecrets / scrub)
  egressGuard.js           OUTBOUND validator (allow/block: secrets, oversize, code volume)
  localGuard.js            INBOUND screen (block extraction / prompt-injection requests)

src/llm/external.js        external planner client (Azure AI Foundry, OpenAI-compatible)
src/external/egressClient.js  the ONLY external-HTTP path: runs the egress guard + writes the audit log

src/flow.js                runFlow(): the full pass (queue → repo → plan → write-back → cleanup)
src/cron.js                node-cron entry on CRON_SCHEDULE, with an overlap guard

data/kg/<repo>.db          the knowledge brain (one file per repo)
output/<KEY>-plan.md       the generated implementation plan (attached to the ticket)
output/<KEY>-chat.md       the full local↔external conversation for that ticket
logs/egress-audit.jsonl    content-free audit of every external send/reply/block
```

---

## Configuration

### `config/boards.json` — the project config

```json
{
  "boards": [
    {
      "name": "Hydrants Sprint Board",
      "projectKey": "HYD",
      "boardId": 7641,
      "active": true,
      "repos": [
        {
          "name": "hydrants-app",
          "localPath": "./repos/hydrants-app",
          "branch": "development",
          "url": "https://github.com/eso-development/hydrants-app.git"
        }
      ]
    }
  ],
  "settings": {
    "fields": "*all",
    "maxResults": 50,
    "sampleIssueKey": "HYD-1583",
    "requiredLabel": "Ready-For-AI",
    "doneLabel": "AI-Analysis-Done"
  }
}
```

- **boardId** — the Agile board the tickets live on (the flow scopes its queue to this board).
- **repos[]** — repos a ticket on this board can touch. `localPath` is where the clone lives; `url`
  is the clone source; `branch` is the branch to track.
- **settings.requiredLabel** — only tickets with this label are picked up.
- **settings.doneLabel** — the label a ticket gets after its plan is attached (so it isn't reprocessed).

### `config/ai.json` — model settings

- **local** — `host`, `model` (`qwen2.5-coder:7b`), `keepAlive` (keep the model resident between calls).
- **external** — `provider`, `apiVersion`, `temperature`, `maxOutputTokens`, **`maxCalls`** (hard cap
  on external calls per ticket, default 10). Endpoint/model/key come from `.env` (preferred).

### `.env` — secrets (see [.env.example](.env.example))

```
JIRA_BASE_URL, JIRA_EMAIL, JIRA_API_TOKEN     # Jira Cloud (Basic auth)
GITHUB_PAT                                     # repo clone
AZURE_AI_ENDPOINT, AZURE_AI_MODEL, AZURE_AI_KEY   # external planner (Azure AI Foundry)
CRON_SCHEDULE                                  # e.g. */5 * * * *
```

---

## Setup (quick)

Full from-scratch runbook (Node version, corporate SSL cert, model download) is in **[SETUP.md](SETUP.md)**.

```powershell
npm install
copy .env.example .env      # then fill in the values
# ensure Ollama is running and the model is pulled:  ollama pull qwen2.5-coder:7b
```

---

## Run

| Command | What it does |
|---|---|
| `npm run flow` | **One full pass now** — queue → repo → plan → attach + comment + flip label. Writes to live Jira tickets. |
| `npm run cron` | Start the scheduler on `CRON_SCHEDULE` (overlap-guarded). First pass at the next interval. |
| `npm run flow:now` | Start the scheduler **and** run one pass immediately. |
| `npm run ready` | List the `Ready-For-AI` tickets on the active board (read-only — confirm the board/label). |
| `npm run plan -- <KEY>` | Run the two-LLM loop for **one** ticket → `output/<KEY>-plan.md` (no Jira write-back). |
| `npm run kg` / `npm run kg:status` / `npm run kg:force` | Build/refresh the brain · show the checkpoint decision · force a rebuild. |
| `npm run kg:search "<question>"` | Semantic search over the brain (no LLM needed). |
| `npm run agent:analyze "<question>"` | Run the local librarian's context gathering for a question. |

Flags: `npm run flow -- --keep-repo` keeps the clone after a board clears; `npm run cron -- --now`
runs a pass on startup.

> **Heads up:** on CPU each ticket takes several minutes (context gathering + the external loop), so a
> full pass over several tickets can take 30–40 minutes. The cron overlap guard skips ticks while a
> pass is still running, so a short interval (e.g. `*/5`) is safe.

---

## Where to see what happened

| You want | Where | Auto-saved? |
|---|---|---|
| Live progress (fetch → repo → KG → each ticket → write-back) | terminal (stdout) | No — redirect with `npm run flow 2>&1 \| Tee-Object logs\flow-run.log` |
| The full local↔external conversation (system prompt + every round) | `output/<KEY>-chat.md` | ✅ one per ticket |
| The final plan | `output/<KEY>-plan.md` | ✅ |
| Egress audit (send/reply/block — counts only, no content) | `logs/egress-audit.jsonl` | ✅ |

---

## Notes

- Jira auth is HTTP Basic: `base64(email:apiToken)` (Jira Cloud).
- A repo already on disk is fetched + pulled on its own origin (no PAT). A missing repo is cloned
  from `url` using `GITHUB_PAT`. The PAT is scrubbed from any error output.
- Fail-loud philosophy: a missing required env var throws — no silent defaults, no fallbacks.
- The flow only changes a ticket's **label**, never its **status**.
