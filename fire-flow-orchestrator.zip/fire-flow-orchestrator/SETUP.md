# SETUP — run Fire-flow-orchestrator from scratch

A reproducible runbook for the whole system: build the knowledge brain, configure the two LLMs, and
run the end-to-end flow (Jira ticket → plan → attached back to the ticket). Follow top to bottom on a
fresh machine. Includes the real gotchas we hit (Node version, corporate SSL cert) so you don't
re-debug them.

> Status: the full pipeline is built — brain (steps 1–5) → local librarian (6) → guards (7) →
> external planner loop (8) → Jira write-back (9) → flow + cron (10). `npm run flow` runs it all.

---

## 0. One-time machine setup (the gotchas — do these first)

### 0.1 Node.js 22 (required — NOT 20)
`better-sqlite3` had **no prebuilt binary for Node 20.18** on Windows and fell back to compiling
(which needs Visual Studio C++). Node 22 has prebuilts → no compiler needed.
```powershell
nvm install 22
nvm use 22
node -v        # expect v22.x
```

### 0.2 Zscaler SSL certificate (required behind the Zscaler proxy)
We're behind **Zscaler**, which inspects HTTPS by re-signing every site with its own root CA. Node
doesn't trust that CA out of the box, so downloads from `nodejs.org` / `huggingface.co` / `npm` fail
with `UNABLE_TO_GET_ISSUER_CERT_LOCALLY` (or `SELF_SIGNED_CERT_IN_CHAIN`). You only need to do this
once per machine: **get the Zscaler root CA as a `.pem`, then point Node + npm at it.**

#### Step 1 — Get the Zscaler root certificate
Pick whichever is easiest; they all produce the same cert.

- **Option A — IT / Zscaler portal (cleanest).** Ask IT for the **"Zscaler Root CA"** PEM, or download
  it yourself from the Zscaler portal: `https://help.zscaler.com` → your company's ZIA portal →
  *Administration → Public Certificates / SSL Inspection → download the Zscaler Root Certificate*. Save
  it as `C:\certs\corp-root-ca.pem`.

- **Option B — export it from the Windows trust store (no portal access needed).** Zscaler installs its
  root CA locally, so you can pull it straight out:
  ```powershell
  New-Item -ItemType Directory -Force -Path C:\certs | Out-Null
  # Grab every cert whose name mentions Zscaler from the machine + user root stores, write one PEM:
  $stores = @("Cert:\LocalMachine\Root","Cert:\CurrentUser\Root")
  $zs = foreach ($s in $stores) { Get-ChildItem $s | Where-Object { $_.Subject -match 'Zscaler' } }
  $lines = foreach ($c in ($zs | Sort-Object Thumbprint -Unique)) {
    "-----BEGIN CERTIFICATE-----"
    [System.Convert]::ToBase64String($c.RawData, 'InsertLineBreaks')
    "-----END CERTIFICATE-----"
  }
  $lines | Out-File -FilePath C:\certs\corp-root-ca.pem -Encoding ascii
  Get-Content C:\certs\corp-root-ca.pem | Select-Object -First 1   # sanity: should print the BEGIN line
  ```
  If `$zs` comes back empty (different naming), fall back to exporting the **whole** trust store — it
  still works, just larger:
  ```powershell
  $stores = @("Cert:\LocalMachine\Root","Cert:\LocalMachine\CA","Cert:\CurrentUser\Root","Cert:\CurrentUser\CA")
  $lines = foreach ($s in $stores) {
    foreach ($c in (Get-ChildItem $s -ErrorAction SilentlyContinue)) {
      "-----BEGIN CERTIFICATE-----"
      [System.Convert]::ToBase64String($c.RawData, 'InsertLineBreaks')
      "-----END CERTIFICATE-----"
    }
  }
  $lines | Out-File -FilePath C:\certs\corp-root-ca.pem -Encoding ascii
  ```

- **Option C — export via `certlm.msc` (GUI).** Run `certlm.msc` → *Trusted Root Certification
  Authorities → Certificates* → find **Zscaler Root CA** → right-click → *All Tasks → Export* →
  *Base-64 encoded X.509 (.CER)* → save, then rename the file to `C:\certs\corp-root-ca.pem`.

#### Step 2 — Point Node + npm at the cert (permanent)
```powershell
setx NODE_EXTRA_CA_CERTS "C:\certs\corp-root-ca.pem"
npm config set cafile "C:\certs\corp-root-ca.pem"
```
**Restart the terminal** after `setx` (it only affects new shells).

#### Step 3 — Verify
```powershell
node -e "require('https').get('https://nodejs.org',r=>console.log('OK',r.statusCode)).on('error',e=>console.log('FAIL',e.message))"
# expect: OK 307   (not FAIL)
npm ping            # should succeed, not throw a cert error
```

> Why two settings? `npm config set cafile` fixes **npm** installs; `NODE_EXTRA_CA_CERTS` fixes
> **Node's own `fetch`** — which `transformers.js` uses to download the embedding model. The env var
> must be present **in the shell that runs the scripts** (`kg:embed`, `kg:search`, `agent:*`, `flow`):
> - **PowerShell (per-shell):** `$env:NODE_EXTRA_CA_CERTS="C:\certs\corp-root-ca.pem"`
> - **cmd (per-shell):** `set NODE_EXTRA_CA_CERTS=C:\certs\corp-root-ca.pem`
> The `setx` above makes it permanent for new shells, so you normally don't need the per-shell line.

---

## 1. Install dependencies
```powershell
cd C:\vru\AI-Automation
npm install
```
Key deps (auto-installed): `better-sqlite3` (DB), `web-tree-sitter@0.20.8` + `tree-sitter-wasms`
(code parsing — pinned to match the grammar ABI), `@huggingface/transformers` (embeddings),
`dotenv`, `simple-git`, `node-cron` (the scheduler).

---

## 2. Configure

### 2.1 `.env` — secrets (copy from `.env.example`)
```
# Jira Cloud (Basic auth)
JIRA_BASE_URL=https://your-domain.atlassian.net
JIRA_EMAIL=you@eso.com
JIRA_API_TOKEN=...           # must have permission to comment, attach, and edit labels

# GitHub (clone)
GITHUB_PAT=...               # repo / contents:read

# External planner — Azure AI Foundry (OpenAI-compatible chat/completions)
AZURE_AI_ENDPOINT=https://<resource>.services.ai.azure.com/openai/v1/chat/completions
AZURE_AI_MODEL=gpt-4.1-mini
AZURE_AI_KEY=...

# Scheduler — standard 5-field cron
CRON_SCHEDULE=*/5 * * * *
```
> The Jira token needs **write** permission — the flow comments, attaches a file, and edits labels.
> It never changes ticket status.

### 2.2 `config/boards.json` — board → repo + labels
Maps the board to its repo(s) and the labels that drive the flow. Current setup: board **HYD / 7641**
→ repo **hydrants-app** (branch `development`), `requiredLabel: "Ready-For-AI"`,
`doneLabel: "AI-Analysis-Done"`. See the README for the full schema.

### 2.3 `config/ai.json` — model settings
- **local**: `host` (`http://127.0.0.1:11434`), `model` (`qwen2.5-coder:7b`), `keepAlive` (`1h`).
- **external**: `apiVersion`, `temperature`, `maxOutputTokens`, `maxCalls` (the hard cap on external
  calls per ticket — default 10). Endpoint/model/key are read from `.env` (preferred).

---

## 3. Build the knowledge brain (run in order)
Each command adds its piece to one file: `data/kg/<repo>.db`. All are idempotent (safe to re-run).
You only need this section to understand or rebuild the brain by hand — **`npm run flow` does it for
you** via `runKg` (see §6).

First get the code on disk:
```powershell
npm run repo        # clone (first time) or fetch+pull
```

| # | Command | What it does | Expected (hydrants-app) |
|---|---------|--------------|--------------------------|
| 1 | `npm run kg:init` | Create empty db: tables `meta/files/nodes/edges` | 4 empty tables |
| 2 | `npm run kg:build` | Walk git file tree → File/Folder nodes (paths only) | 2304 File, 597 Folder |
| 3 | `npm run kg:graph` | tree-sitter parse C# + TS → Class/Method/Function + calls/inherits/implements | ~1737 Class, ~4405 Method |
| 4 | `npm run kg:extras` | Parse C# controllers / SQL / Terraform → ApiEndpoint, DatabaseTable, Module | 116 ApiEndpoint, 10 DatabaseTable, 25 Module |
| 5 | `npm run kg:bridge` | Match frontend HTTP calls → ApiEndpoint (connect front↔back) | ~60 bridge edges |
| 6 | `npm run kg:embed` | Embed every node (transformers.js, 384-dim) → vectors in db | 9332/9332 embedded |

> `kg:embed` needs `NODE_EXTRA_CA_CERTS` set (see 0.2) on the FIRST run to download the model.

The smart way — let the checkpoint decide:
```powershell
npm run kg          # build if missing, rebuild if commit changed, skip if current
npm run kg:status   # show the decision (skip/build/rebuild) without doing anything
npm run kg:force    # force a full rebuild
```

---

## 4. Test semantic search (no LLM needed)
```powershell
$env:NODE_EXTRA_CA_CERTS="C:\certs\corp-root-ca.pem"
npm run kg:search "update a hydrant inspection status"
```
Expect a ranked table of relevant methods (e.g. `UpdateInspectionDistrict`, `UpdateHydrant`, …) —
found by meaning, not exact keywords.

---

## 5. Start the local LLM (Ollama + Qwen)
The Ollama desktop app auto-starts the server (system tray). Verify + ensure the model is present:
```cmd
curl http://127.0.0.1:11434/api/tags        REM should return JSON (server is up)
ollama list                                  REM should list qwen2.5-coder:7b
ollama pull qwen2.5-coder:7b                REM only if it's NOT listed (one-time, ~4.7 GB)
```
If the server is NOT running (curl fails), open the Ollama app or run `ollama serve`. The model loads
into RAM on first call and stays resident (`keepAlive: 1h`) so later tickets don't pay reload cost.

Stop it when done (free the RAM):
```cmd
ollama stop qwen2.5-coder:7b
```

---

## 6. Run the end-to-end flow

This is the real thing: fetch the labeled tickets, build/refresh the brain, plan each ticket through
the two-LLM loop, and write the plan back to Jira.

### 6.1 Confirm the board + label first (read-only)
```powershell
npm run ready       # lists the Ready-For-AI tickets on board 7641 — writes nothing
```

### 6.2 One full pass, now
```powershell
$env:NODE_EXTRA_CA_CERTS="C:\certs\corp-root-ca.pem"
npm run flow
```
What happens, per board: fetch the `Ready-For-AI` queue → (if any) pull repo + `runKg` → for each
ticket: gather context → local↔external loop → `output/<KEY>-plan.md` → **attach + comment + flip
label `Ready-For-AI` → `AI-Analysis-Done`** → when the board is cleared, remove the clone (brain kept).

> This WRITES to live tickets. On CPU each ticket takes several minutes, so a multi-ticket pass can
> run 30–40 minutes and blocks the terminal. To prove it on one ticket without write-back first, use
> `npm run plan -- <KEY>` (writes only `output/<KEY>-plan.md`).

### 6.3 On a timer (cron)
```powershell
npm run cron          # schedule on CRON_SCHEDULE; first pass at the next interval
npm run flow:now      # same, but also run one pass immediately on startup
```
The scheduler has an **overlap guard**: it skips a tick if the previous pass is still running, so a
short interval (e.g. `*/5`) is safe even though a pass takes longer than 5 minutes.

Flags: `npm run flow -- --keep-repo` keeps the clone after a board clears (default removes it).

### 6.4 Where to see what happened
| You want | Where |
|---|---|
| Live progress | terminal (redirect: `npm run flow 2>&1 \| Tee-Object logs\flow-run.log`) |
| Full local↔external conversation | `output/<KEY>-chat.md` |
| The plan | `output/<KEY>-plan.md` |
| Egress audit (counts only, no content) | `logs/egress-audit.jsonl` |

---

## 7. File map (what each module does)
```
src/config.js              env + boards.json + ai.json loader; repoDbPath(); ROOT
src/jira.js                Jira client — read (issues/boards) + write (addComment/addAttachment/setLabels)
src/github.js              fetchRepo (clone/pull) + removeRepo (clone cleanup)
src/index.js               CLI flags (--ready, --list-boards, --board-issues, --issue, ...)
src/job.js                 phase-1 helpers (runJira / runRepos / runOnce)

src/kg/schema.js           DB blueprint: openDb(), tables, meta helpers
src/kg/build.js            file tree → File/Folder nodes
src/kg/graph.js            tree-sitter code graph (C# + TS): nodes + edges
src/kg/parse.js            ApiEndpoint / DatabaseTable / Terraform parsers
src/kg/bridge.js           frontend HTTP call → ApiEndpoint (the bridge)
src/kg/embed.js            embeddings (transformers.js) + embedQuery()
src/kg/index.js            runKg() orchestrator + checkpoint (skip/build/rebuild)
src/retrieval/repoDb.js    vector search (cosine) + neighbors() + test down-ranking

src/agent/tools.js         the 5 read-only tools (search_graph/neighbors/list_files/read_file/grep)
src/agent/local.js         askLocal(): Ollama tool-calling loop (chatOnce)
src/agent/analyze.js       gatherContext(): deterministic dig → summarize → validate citations
src/agent/loop.js          planTicket(): the notebook loop (external drives, local answers, 10-cap)

src/security/redact.js     secret scrubber (redactSecrets / scrub)
src/security/egressGuard.js  OUTBOUND validator (block secrets / whole-file dumps / oversize)
src/security/localGuard.js   INBOUND screen (block extraction / prompt-injection requests)
src/llm/external.js        external planner client (Azure AI Foundry)
src/external/egressClient.js  the ONLY external-HTTP path: guard + audit log

src/flow.js                runFlow(): the full pass
src/cron.js                node-cron entry + overlap guard
data/kg/<repo>.db          the knowledge brain (one file per repo)
output/                    <KEY>-plan.md, <KEY>-chat.md
logs/egress-audit.jsonl    content-free egress audit
```

---

## 8. Troubleshooting (issues we actually hit)
| Symptom | Cause | Fix |
|---------|-------|-----|
| `no prebuilt binaries` + `gyp ERR! find VS` on `npm install better-sqlite3` | Node 20 has no prebuilt; compiling needs Visual Studio | Use **Node 22** (§0.1) |
| `UNABLE_TO_GET_ISSUER_CERT_LOCALLY` on npm/node download | Corporate proxy CA not trusted | Export CA + `NODE_EXTRA_CA_CERTS` (§0.2) |
| `transformers.js` `fetch failed` / issuer cert | Model download via Node `fetch` lacks the CA | Set `NODE_EXTRA_CA_CERTS` in the run shell |
| `web-tree-sitter` `getDylinkMetadata` error | web-tree-sitter newer than the grammar ABI | Pin `web-tree-sitter@0.20.8` |
| `Ollama unreachable` mid-run | model unloaded / CPU-RAM contention | `keepAlive` keeps it resident; otherwise it self-heals on retry (hardware limit) |
| `external.endpoint is still a placeholder` | `.env` Azure vars not set | Fill `AZURE_AI_ENDPOINT` / `AZURE_AI_MODEL` / `AZURE_AI_KEY` (§2.1) |
| flow says `repo clone not found` | brain/clone removed | `npm run flow` re-clones automatically; or `npm run repo` then `npm run kg` |

---

## 9. Build order recap (the "why")
`init` (container) → `build` (files) → `graph` (code: backend+frontend) → `extras` (endpoints/tables/
infra) → `bridge` (connect front↔back) → `embed` (make it searchable). Then the local librarian
retrieves over it, the loop plans with the external planner, and the flow attaches the plan to Jira —
all scheduled by cron with an overlap guard.
