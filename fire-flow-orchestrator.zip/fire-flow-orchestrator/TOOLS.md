# TOOLS.md — What we use, why, and how it fits the flow

This walks the system **stage by stage** (build the brain → use the brain) and, for each tool,
explains **what it is, why we chose it, how it's useful, and why it's the best fit for *our*
project**. Read it top-to-bottom and it reads like the flow itself.

## The 4 constraints that decide every choice
1. **Source code never leaves our infrastructure** → everything must run **locally** and be **free/open**.
2. **One VM, simple to run** (managed by PM2) → as few moving services as possible; prefer in-process.
3. **Config-driven & swappable** → no tool/model name hardcoded; we can change picks later.
4. **Lean & stable** → the brain stores the code *map*, not a stale copy of the repo.

---

# PHASE A — Build the brain (indexing → one `repo.db`)

## 1. Runtime — Node.js (ESM)
- **What:** the language/runtime the whole tool already runs on.
- **Why:** Phase 1 (Jira + GitHub fetch) is already Node ESM; we extend, not rewrite.
- **How useful:** one stack, one process model, native `fetch`, easy for PM2 to manage.
- **Best for us:** no new runtime to learn or deploy; keeps the VM simple.

## 2. Repo sync — `simple-git`
- **What:** thin wrapper over git (already in the project).
- **Why:** we already clone/pull `hydrants-app` with it.
- **How useful:** keeps the local clone current so the graph + live file reads are fresh.
- **Best for us:** zero new dependency — reuse what works.

## 3. Code → graph — `tree-sitter` (+ `scip-dotnet` for C#)
- **What:** a fast parser that turns source into a structural tree; we walk it to build
  nodes (Class/Method/Function/Endpoint/Table) and edges (calls/imports/inherits).
- **Why:** we dropped GitNexus (paid/unavailable). tree-sitter is the open, free standard for
  multi-language code parsing; for C# specifically, **`scip-dotnet` (Roslyn)** gives accurate
  calls/inheritance that plain heuristics miss — and hydrants-app is mostly C#.
- **How useful:** produces the durable code *map* — the backbone of the knowledge graph.
- **Best for us:** free, local, language-flexible (C#, TS, SQL, etc.), no external service.

## 4. Storage — **SQLite + `sqlite-vec`** (one `repo.db` per repo)
- **What:** a single SQLite file holding the graph (nodes/edges) **and** the vectors, with
  `sqlite-vec` providing vector (semantic) search inside that same file.
- **Why:** the whole vision is "one file = the brain." `sqlite-vec` is the free, MIT, runs-anywhere
  vector extension; SQLite needs no server.
- **How useful:** one portable file we can copy, back up, or ship; semantic + structural search in
  one place; tiny footprint (hundreds of MB, not GB).
- **Best for us:** no database server to run on the VM (simple), no cloud (secure), one artifact.
- **Note we already know:** pin `sqlite-vec`/`better-sqlite3` versions (a known ABI mismatch);
  fallback is SQLite-Vector (sqlite.ai) if needed.

## 5. Embeddings — `transformers.js` (in-process), one **fixed** code-capable model
- **What:** generates the vectors for each node; runs **inside the Node process** (pure JS/ONNX).
- **Why:** code embeddings must be made **locally** (code can't leave). `transformers.js` needs
  **no separate service and no native build** — perfect for "one VM, simple."
- **How useful:** embeds code at index time and the query at search time — in the **same vector
  space**, which is what makes semantic search actually work.
- **Best for us:** zero extra daemon, runs identically on your laptop and the VM, free, offline.
- **The one rule:** the embedding model is **fixed once and used everywhere** (dev + prod). Changing
  it later means a one-time re-index (we auto-detect this via `meta.embed_model` and rebuild).

---

# PHASE B — Use the brain (per ticket → Plan.md)

## 6. Local LLM — **Qwen2.5-Coder-14B (dev)** / **Qwen3-Coder-30B-A3B (prod VM)** via **Ollama**
- **What:** the local "librarian" agent — understands the ticket, calls tools, reads code, and
  writes sanitized summaries. Run through **Ollama** (one-command local model server, GGUF).
- **Why two models:**
  - **Dev / your laptop (32GB) → Qwen2.5-Coder-14B.** ~9GB RAM, leaves headroom for your IDE +
    browser, fast and reliable. Fully capable for the bounded librarian job (HumanEval ~85%, solid
    tool-calling).
  - **Prod / VM → Qwen3-Coder-30B-A3B.** MoE: 30B total but only **~3.3B active per token**, so it
    reasons like a big model while running light; 256K context; purpose-built for agentic
    tool-calling. On the VM it's the only workload, so it gets the bigger brain.
- **How useful:** does the secure retrieval + summarization so the external model never touches code.
- **Best for us:** open (Apache-2.0), free, local, code-tuned, strong function-calling — exactly the
  skills our agent loop needs, sized to run on our own hardware.
- **⚠️ We can SWAP the model on the VM anytime.** Model names are **config values** (`config/ai.json`
  / `.env`), not hardcoded. So on the VM we can move 14B → 30B-A3B → a better future model with a
  **one-line change + restart** — no code edits. (Only the *embedding* model is special: changing
  that triggers a re-index; the *chat* LLM swaps freely with zero data impact.)

## 7. Retrieval — `sqlite-vec` search + graph queries (our own code)
- **What:** vector (semantic) search + graph traversal (calls/imports) over `repo.db`.
- **Why:** deterministic DB operations are auditable and reproducible — the LLM shouldn't "guess"
  what's in the graph, it should query it.
- **How useful:** finds the right files/functions/edges fast; the LLM just decides *what* to ask.
- **Best for us:** all local, all in the one file, no extra infra.

## 8. Egress guard — **our own plain-JS module** (`src/security/egressGuard.js`)
- **What:** the single code checkpoint every message to the external LLM must pass. **Not a tool or
  library — a file we write.** No AI, no network, no dependency.
- **Why:** we can't trust LLM output to be code-free (mistakes, or prompt-injection in a repo doc).
- **How it works:** **whitelist the shape** — the payload is a typed object (names, paths, short
  summaries); the guard validates each field and **re-serializes ONLY the allowed fields**, dropping
  everything else. Plus a secret scan (`ghp_`, `ATATT`, `AKIA`, PEM, JWT) and a size cap.
  **Fail-closed:** anything off → it throws and blocks the send.
- **Best for us:** turns "source code never leaves" from a hope into a **code-level guarantee**, and
  makes prompt-injection irrelevant (a sneaky field still isn't on the guest list).

## 9. External LLM — pluggable planner (Claude **or** Azure OpenAI — pick later)
- **What:** the frontier model that writes `Plan.md` from the ticket + sanitized context.
- **Why pluggable:** we keep `EXTERNAL_LLM_PROVIDER` in config + an endpoint allowlist, so the choice
  is late-bound and swappable.
- **How useful:** does the heavy creative planning we deliberately keep *off* the local model.
- **Best for us:** frontier-quality plans **without** sending code to a frontier model — the local
  librarian + egress guard make that safe.

## 10. Attach to Jira — existing `JiraClient` (extended)
- **What:** save `Plan.md` and attach it to the ticket; reuse our Jira REST client.
- **Why:** Phase 1 already has the client + auth; we add `addAttachment`/`getAttachments`.
- **How useful:** closes the loop — the plan lands on the ticket automatically.
- **Best for us:** reuse, no new integration.

---

# Cross-cutting

## Process management — **PM2**
- **What/Why:** runs the Node app (and keeps it alive/restarts) on the VM with a simple command.
- **Best for us:** matches the "one VM, simple to run" goal; one process manager for the whole app.

## Scheduling — `node-cron`
- **What/Why:** fires the per-ticket run on `CRON_SCHEDULE`, with an overlap guard (skip a tick if
  the previous run is still going) to keep "one ticket at a time."
- **Best for us:** in-process, no OS-level cron setup, simple on the VM.

## Config — everything is swappable
- Models, providers, retrieval params, `maxCalls` (default **10**) all live in `config/ai.json` /
  `.env`. **Nothing is hardcoded.** Swap the local chat LLM or the external planner freely; only the
  embedding model swap costs a one-time re-index (auto-detected).

---

# One-line summary
**Node + tree-sitter build a lean code graph → stored with embeddings in one `sqlite-vec` file →
a local Qwen coder (14B dev / 30B-A3B prod, swappable on the VM via config) reads it as a secure
librarian → an egress guard lets only names + summaries out → a frontier external LLM writes the
plan → it's attached to Jira.** All local, all free where it touches code, simple to run on one VM.
