import { fileURLToPath } from 'node:url';
import { createAgentTools } from './tools.js';
import { chatOnce } from './local.js';
import { openDb } from '../kg/schema.js';
import { redactSecrets } from '../security/redact.js';
import { inspectEgress } from '../security/egressGuard.js';
import { isTestPath } from '../retrieval/repoDb.js';
import { repoDbPath, getActiveRepos, localEngine } from '../config.js';

// ── SENIOR-ENGINEER RESEARCH PIPELINE ───────────────────────────────────────────────────────────
// The local model can't reliably CHAIN tool calls on its own (proven: pushing it -> hallucination).
// So OUR CODE does the digging deterministically and hands the model the real evidence; the model
// only SUMMARIZES what it can see (its reliable skill). Then we VALIDATE every cited path/symbol
// against the graph. Slower than one search, but grounded + verified — accuracy over speed.
//   gather: search_graph -> neighbors + structural EXPANSION (same-file & naming siblings) ->
//           read real code (seeds + connected, startLine/endLine) -> grep .md docs ->
//           assemble evidence -> model synthesizes a structured package -> validate citations exist.
//
// WHY EXPANSION: the graph is sparse (~0.4 edges/node), so top-15 semantic rank alone misses relevant
// code, and graph neighbors alone can't fill the gap. We therefore surface "probably-connected" code
// from THREE signals — graph neighbors, same-file siblings, and naming-convention siblings (CQRS/.NET:
// UpdateHydrantCommand <-> UpdateHydrantCommandHandler <-> ...Validator) — and read those bodies too.

const EVIDENCE_CHAR_BUDGET = 22_000;
const MAX_NEIGHBOR_HITS = 8;      // how many top seeds we expand (neighbors + structural siblings)
const MAX_FILE_SNIPPETS = 10;     // snippets into the LOCAL evidence blob (never egresses)
const MAX_SNIPPET_LINES = 60;     // per-snippet read window
const MAX_READ_FILES = 16;        // distinct files we read bodies for (seeds + expansion)
const MAX_EXPANSION = 40;         // cap on the connected-candidate set

// What actually crosses to the planner: MINIMAL SUFFICIENT CONTEXT — the few most-relevant snippets a
// senior engineer would paste into a design review, NOT whole files. Bounded + redacted. Sized to the
// egress headroom (policy: 300 code-lines / 8 blocks / 24k chars): 7×40 ≈ ~196 code-like lines < 300.
const SHARE_MAX_SNIPPETS = 7;
const SHARE_SNIPPET_LINES = 40;
const SAME_FILE_SIBLINGS = 6;     // how many same-file siblings to consider per seed
const isStylePath = (f) => /\.(?:scss|css|less)$/i.test(f); // styling: noise for a plan -> never shared

// Connection-signal weights (higher = read/share first). Seeds always outrank expansion.
const SIGNAL_WEIGHT = { neighbor: 3, nameSibling: 2, sameFile: 1 };
// Common .NET/CQRS suffixes. Used to (a) derive a stem from a symbol and (b) match its siblings.
// Longest-first so "CommandHandler" strips before "Handler".
const NAME_SUFFIXES = [
  'CommandHandler', 'QueryHandler', 'Command', 'Query', 'Validator', 'Handler',
  'Controller', 'Repository', 'Service', 'Mapper', 'Factory', 'Request', 'Response', 'Dto', 'Repo',
];
// Stems too generic to expand on (would match a huge fraction of the repo).
const STEM_DENYLIST = new Set(['Base', 'Model', 'Entity', 'Helper', 'Service', 'Controller', 'Manager', 'Provider', 'Base']);

const STOP = new Set(
  'the and for are was its how does what when where which with from into update create delete'
    .split(/\s+/)
);

// Pull content words from the question (for the docs grep). Split on non-alphanumerics (no lone-space literals).
function keywords(q) {
  return [...new Set(q.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 3 && !STOP.has(w)))].slice(0, 6);
}

// Derive candidate stems from a symbol name (and its container) by stripping a known suffix.
// "UpdateHydrantCommandHandler" -> ["UpdateHydrant", "UpdateHydrantCommand"]. Filtered for usefulness.
function stemsOf(name, container) {
  const out = new Set();
  for (const base of [name, container].filter(Boolean)) {
    for (const suf of NAME_SUFFIXES) {
      if (base.length > suf.length + 2 && base.endsWith(suf)) out.add(base.slice(0, -suf.length));
    }
  }
  return [...out].filter((s) => s.length >= 4 && !STEM_DENYLIST.has(s));
}

const clip = (s, n) => (s.length > n ? s.slice(0, n) + '\n...[truncated]' : s);

/**
 * Gather a verified, structured context package for a ticket/question.
 * Returns { package, stats:{hits,chains,expanded,snippets,docs,codeShared}, unverified:{paths,symbols} }.
 */
export async function gatherContext(repo, query, { onStep = null, seenSnippets = null } = {}) {
  const engine = localEngine();
  const tools = createAgentTools(repo);
  const vdb = openDb(repoDbPath(repo.name), { repo: repo.name, branch: repo.branch });
  const step = (tool, info) => onStep && onStep({ tool, info });
  const sharedKeys = seenSnippets || new Set(); // cross-round snippet dedup (per ticket); local if absent

  // Resolve a node id -> { id, type, name, file, startLine, endLine, container } (neighbors/siblings
  // come back without file/lines, so we look them up here).
  const metaOf = (id) => {
    const row = vdb.prepare('SELECT type, name, metadata FROM nodes WHERE id = ?').get(id);
    if (!row) return null;
    let m = {};
    try { m = JSON.parse(row.metadata || '{}'); } catch { /* default */ }
    return {
      id, type: row.type, name: row.name,
      file: m.filePath || m.path || null, startLine: m.startLine || null,
      endLine: m.endLine || null, container: m.container || null,
    };
  };

  // Read a bounded body window for a file (±3 lines around the symbol, capped at MAX_SNIPPET_LINES).
  const readWindow = (file, startLine, endLine, label) => {
    let start = 1, end = MAX_SNIPPET_LINES;
    if (startLine) { start = Math.max(1, startLine - 3); end = (endLine || startLine + MAX_SNIPPET_LINES) + 3; }
    if (end - start > MAX_SNIPPET_LINES) end = start + MAX_SNIPPET_LINES;
    try {
      const f = tools.read_file({ path: file, start, end });
      return {
        file, key: `${file}:${f.lineStart}-${f.lineEnd}`,
        label: `${file}:${f.lineStart}-${f.lineEnd}  (${label})`, content: f.content,
      };
    } catch { return null; }
  };

  try {
    // 1. broad semantic search -> SEEDS
    const hits = await tools.search_graph({ query, k: 15 });
    step('search_graph', `${hits.length} hits`);
    const seedIds = new Set(hits.map((h) => h.id));

    // expansion candidate set: id -> { id, type, name, file, startLine, endLine, weight, signal, via }
    const candidates = new Map();
    const addCand = (m, weight, signal, via) => {
      if (!m || !m.file || seedIds.has(m.id)) return;            // must be readable + not already a seed
      const prev = candidates.get(m.id);
      if (prev) { if (weight > prev.weight) Object.assign(prev, { weight, signal, via }); return; }
      candidates.set(m.id, { ...m, weight, signal, via });
    };

    // 2. neighbors of top seeds -> relationship chains (text) AND connected candidates (code to read)
    const chains = [];
    for (const h of hits.slice(0, MAX_NEIGHBOR_HITS)) {
      const nb = tools.neighbors({ id: h.id, limit: 12 });
      for (const n of nb) {
        chains.push(`${h.name} --${n.relation}/${n.direction}--> ${n.type} ${n.name}`);
        addCand(metaOf(n.id), SIGNAL_WEIGHT.neighbor, 'neighbor', `${n.relation} of ${h.name}`);
      }
    }
    step('neighbors', `${chains.length} relationships`);

    // 3. structural expansion of top seeds: same-file siblings + naming-convention siblings
    for (const h of hits.slice(0, MAX_NEIGHBOR_HITS)) {
      if (h.file) {
        const sibs = vdb.prepare(
          "SELECT id FROM nodes WHERE type IN ('Class','Method','Function') AND json_extract(metadata,'$.filePath') = ? LIMIT ?"
        ).all(h.file, SAME_FILE_SIBLINGS + 5);
        let n = 0;
        for (const r of sibs) {
          if (n >= SAME_FILE_SIBLINGS) break;
          addCand(metaOf(r.id), SIGNAL_WEIGHT.sameFile, 'same-file', `same file as ${h.name}`);
          n++;
        }
      }
      for (const stem of stemsOf(h.name, h.container)) {
        const like = stem.replace(/[\\%_]/g, '\\$&') + '%';
        const rows = vdb.prepare(
          "SELECT id, name FROM nodes WHERE type IN ('Class','Method','Function') AND name LIKE ? ESCAPE '\\' LIMIT 30"
        ).all(like);
        for (const r of rows) {
          if (r.name !== stem && !NAME_SUFFIXES.some((suf) => r.name === stem + suf)) continue;
          addCand(metaOf(r.id), SIGNAL_WEIGHT.nameSibling, 'name-sibling', `name-sibling of ${h.name}`);
        }
      }
    }
    const ranked = [...candidates.values()].sort((a, b) => b.weight - a.weight).slice(0, MAX_EXPANSION);
    step('expand', `${ranked.length} connected candidate(s)`);

    // test coverage signal (for the deterministic confidence score): how many distinct test files
    // surfaced among the seeds + connected candidates. 0 -> no coverage to mirror or verify against.
    const candidateFiles = new Set([...hits, ...ranked].map((x) => x.file).filter(Boolean));
    const testsFound = [...candidateFiles].filter((f) => isTestPath(f)).length;

    // 4. read the ACTUAL code — SEEDS first (by score), then connected candidates (by weight). One
    //    snippet per distinct file, up to MAX_READ_FILES, using stored startLine/endLine.
    const readFiles = new Set();
    const allRead = []; // { file, key, label, content, origin, signal }
    const readOrder = [
      ...hits.map((h) => ({ id: h.id, file: h.file, type: h.type, name: h.name, origin: 'seed', signal: 'semantic' })),
      ...ranked.map((c) => ({ id: c.id, file: c.file, type: c.type, name: c.name, origin: 'expansion', signal: c.signal })),
    ];
    for (const item of readOrder) {
      if (allRead.length >= MAX_READ_FILES) break;
      if (!item.file || readFiles.has(item.file)) continue;
      const m = metaOf(item.id);
      const w = readWindow(item.file, m?.startLine, m?.endLine, `${item.type} ${item.name}`);
      if (!w) continue;
      allRead.push({ ...w, origin: item.origin, signal: item.signal });
      readFiles.add(item.file);
    }
    const snippets = allRead.slice(0, MAX_FILE_SNIPPETS).map((r) => `### ${r.label}\n${r.content}`);
    step('read_file', `${allRead.length} read / ${snippets.length} in evidence`);

    // 5. docs: grep markdown for the question's keywords, read the top matches
    const docSnippets = [];
    const docSeen = new Set();
    for (const k of keywords(query)) {
      const g = tools.grep({ pattern: k, lang: 'markdown', maxHits: 4 });
      for (const d of g.hits) {
        if (docSnippets.length >= 2 || docSeen.has(d.path)) continue;
        docSeen.add(d.path);
        try {
          const f = tools.read_file({ path: d.path, start: Math.max(1, d.line - 3), end: d.line + 30 });
          docSnippets.push(`### ${d.path}\n${f.content}`);
        } catch { /* skip */ }
      }
      if (docSnippets.length) break;
    }
    step('grep(docs)', `${docSnippets.length} doc snippets`);

    // 6. assemble the evidence blob (capped to fit the context window)
    const expansionLines = ranked.length
      ? ranked.slice(0, 20).map((c) => `- [${c.type}] ${c.name}  ${c.file || ''}  (via ${c.via})`)
      : ['(none found)'];
    const evidence = clip([
      'MATCHES (semantic, by score):',
      ...hits.map((h) => `- [${h.type}] ${h.name}${h.route ? ' ' + h.route : ''} (score ${h.score})  ${h.file || ''}`),
      '',
      'RELATIONSHIPS (neighbors of top matches):',
      ...(chains.length ? chains.slice(0, 30) : ['(none found)']),
      '',
      'EXPANSION (probably-connected code, NOT in the top-15 semantic matches):',
      ...expansionLines,
      '',
      'CODE SNIPPETS (actual source of seeds + connected code):',
      ...(snippets.length ? snippets : ['(none read)']),
      '',
      'DOCS (.md matches):',
      ...(docSnippets.length ? docSnippets : ['(no relevant docs found)']),
    ].join('\n'), EVIDENCE_CHAR_BUDGET);

    // 7. synthesize a structured package (NO tools — the model only summarizes provided evidence)
    const sys = [
      `You are a senior software engineer's research assistant for the repository "${repo.name}".`,
      'You receive a TICKET/QUESTION and EVIDENCE gathered from the repository (semantic matches,',
      'relationships, probably-connected code, real code snippets, and docs). Produce a CONTEXT PACKAGE',
      'for a planner.',
      '',
      'Rules:',
      '- Use ONLY the evidence provided. Do NOT invent files, classes, routes, columns, or behavior.',
      '- If the evidence does not cover a section, write "not found in evidence" for it.',
      '- If the matches are clearly unrelated to the question, say the feature does not appear to exist.',
      '- Output NAMES + SUMMARIES + RELATIONSHIPS only. NO code blocks and no copied source lines.',
      '',
      'Use exactly these sections:',
      '## Affected files & components',
      '## Call chain / how it works',
      '## Data / tables',
      '## Tests',
      '## Conventions from docs',
      '## Open questions for the planner',
    ].join('\n');

    const out = await chatOnce(engine, [
      { role: 'system', content: sys },
      { role: 'user', content: `TICKET/QUESTION:\n${query}\n\nEVIDENCE:\n${evidence}` },
    ], { useTools: false });
    let pkg = (out.message?.content || '').trim();

    // 8. validate: every cited path/symbol must exist in the repo; flag what doesn't
    const knownPaths = new Set(vdb.prepare('SELECT path FROM files').all().map((r) => r.path));
    const knownNames = new Set(vdb.prepare('SELECT name FROM nodes').all().map((r) => r.name));
    const citedPaths = [...new Set(pkg.match(/[\w./-]+\.(?:cs|ts|tsx|js|sql|tf|md|json|ya?ml|cshtml)\b/g) || [])];
    const badPaths = citedPaths.filter((p) => !knownPaths.has(p) && ![...knownPaths].some((kp) => kp.endsWith('/' + p)));
    const citedSyms = [...new Set((pkg.match(/`([A-Z][A-Za-z0-9_]{2,})`/g) || []).map((s) => s.replace(/`/g, '')))];
    const badSyms = citedSyms.filter((s) => !knownNames.has(s));

    if (badPaths.length || badSyms.length) {
      pkg += '\n\n## Unverified references (NOT found in the repo — treat as suspect)\n'
        + (badPaths.length ? `- paths: ${badPaths.join(', ')}\n` : '')
        + (badSyms.length ? `- symbols: ${badSyms.join(', ')}\n` : '');
    }

    // 9. attach the IMPORTANT relevant code — bounded + secret-redacted, minimal sufficient context.
    //    Order by signal so the highest-value production code crosses first: seed -> neighbor ->
    //    name-sibling -> same-file. Skip styles/tests, dedup across rounds (sharedKeys), redact, then
    //    SELF-TRIM to stay under the egress guard (pop the lowest-priority snippet until it passes) so
    //    a code-rich answer never gets blocked downstream. We only mark a snippet "seen" once it ships.
    const prioOf = (r) => (r.origin === 'seed' ? 0 : ({ neighbor: 1, 'name-sibling': 2, 'same-file': 3 }[r.signal] ?? 4));
    const shareList = allRead
      .filter((r) => !isStylePath(r.file) && !isTestPath(r.file))
      .sort((a, b) => prioOf(a) - prioOf(b));

    const parts = [];
    let dupSkipped = 0;
    for (const r of shareList) {
      if (parts.length >= SHARE_MAX_SNIPPETS) break;
      if (sharedKeys.has(r.key)) { dupSkipped++; continue; }
      const all = r.content.split('\n');
      const kept = all.slice(0, SHARE_SNIPPET_LINES);
      if (all.length > kept.length) kept.push('// ...[snippet truncated — bounded context]');
      parts.push({ key: r.key, text: '```\n// ' + r.label + '\n' + redactSecrets(kept.join('\n')).text + '\n```' });
    }

    const compose = (ps) => {
      let s = ps.map((p) => p.text).join('\n\n');
      if (dupSkipped) s += `\n\n_(${dupSkipped} relevant snippet(s) already shown in an earlier round — omitted to avoid repetition.)_`;
      return s;
    };
    const SHARE_HEADER = '\n\n## Relevant code (key snippets — bounded, secrets redacted)\n';
    // egress self-trim: drop lowest-priority snippets until pkg + shared passes the guard
    while (parts.length && !inspectEgress(pkg + SHARE_HEADER + compose(parts)).allowed) parts.pop();

    for (const p of parts) sharedKeys.add(p.key); // mark only what actually ships
    const shared = compose(parts);
    if (shared.trim()) pkg += SHARE_HEADER + shared;

    return {
      package: pkg,
      stats: { hits: hits.length, chains: chains.length, expanded: ranked.length, snippets: snippets.length, docs: docSnippets.length, codeShared: parts.length, testsFound },
      unverified: { paths: badPaths, symbols: badSyms },
    };
  } finally {
    tools.close();
    vdb.close();
  }
}

// Run directly: `node src/agent/analyze.js "your ticket/question"`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const query = process.argv.slice(2).join(' ') || 'How is a hydrant inspection status updated and persisted?';
  const repo = getActiveRepos()[0];
  if (!repo) throw new Error('No active repos in config/boards.json');

  console.log(`\n[analyze] repo=${repo.name}  q="${query}"\n`);
  const r = await gatherContext(repo, query, {
    onStep: ({ tool, info }) => console.log(`  [${tool}] ${info}`),
  });
  console.log(`\n--- context package (hits ${r.stats.hits}, chains ${r.stats.chains}, expanded ${r.stats.expanded}, snippets ${r.stats.snippets}, docs ${r.stats.docs}, shared-code ${r.stats.codeShared}) ---\n`);
  console.log(r.package);
  if (r.unverified.paths.length || r.unverified.symbols.length) {
    console.log(`\n[validate] unverified -> paths: ${r.unverified.paths.join(', ') || '-'} | symbols: ${r.unverified.symbols.join(', ') || '-'}`);
  } else {
    console.log('\n[validate] all cited paths/symbols verified against the repo.');
  }
}
