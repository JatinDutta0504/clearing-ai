import { fileURLToPath } from 'node:url';

// ── DETERMINISTIC CONFIDENCE SCORE ──────────────────────────────────────────────────────────────
// The plan's confidence % is NOT estimated by the language model. An LLM asked "how sure are you?"
// has no measuring device — it emits the number that *reads* confident (almost always ~85%, anchored
// to the GOOD-TO-GO threshold), the same value for every ticket. A constant carries zero information.
//
// Instead WE compute it from the retrieval evidence gatherContext already collected and VERIFIED
// against the code graph. Every point traces to a checked fact, so the score is auditable and it
// MOVES per ticket. It measures GROUNDING (how well the plan is anchored to real, confirmed code) —
// NOT whether the proposed fix is correct (no automatic score can judge that; that needs a human).
//
// Signals (all genuine facts from the graph + clone, accumulated across the ticket's retrieval calls):
//   hits        semantic matches found            0 -> retrieval is blind
//   snippets    real code bodies read             0 -> names only, nothing verified
//   codeShared  bounded snippets sent to planner  0 -> planner got names only
//   chains      relationships resolved            0 -> call chain could not be traced
//   suspect*    citations NOT found in the repo    the key fabrication signal (the validator caught it)
//   testsFound  test files near the affected area  0 -> no coverage to mirror/verify against
//   docs        doc snippets found                 0 -> no documented conventions to anchor to

export const GOOD_TO_GO_MIN = 80;

// A fresh per-ticket accumulator. gatherContext runs several times per ticket (initial findings +
// each follow-up question); we fold every call's evidence into one bucket before scoring.
export function newEvidence() {
  return {
    calls: 0, hits: 0, chains: 0, expanded: 0, snippets: 0, codeShared: 0, docs: 0, testsFound: 0,
    suspectPaths: new Set(), suspectSymbols: new Set(),
  };
}

// Fold one gatherContext result ({ stats, unverified }) into the accumulator. Counts SUM across calls;
// suspect references are de-duplicated (a name cited in two rounds is one suspect, not two).
export function foldEvidence(ev, { stats = {}, unverified = {} } = {}) {
  ev.calls += 1;
  ev.hits += stats.hits || 0;
  ev.chains += stats.chains || 0;
  ev.expanded += stats.expanded || 0;
  ev.snippets += stats.snippets || 0;
  ev.codeShared += stats.codeShared || 0;
  ev.docs += stats.docs || 0;
  ev.testsFound += stats.testsFound || 0;
  for (const p of unverified.paths || []) ev.suspectPaths.add(p);
  for (const s of unverified.symbols || []) ev.suspectSymbols.add(s);
  return ev;
}

const cap = (n, max) => Math.min(n, max);

// Start at 100, deduct for each real gap. Returns { score, decision, deductions[], evidence }.
// Each deduction carries a `tag` so the renderer can show the point cost next to the right driver.
export function computeConfidence(ev) {
  const deductions = [];
  const ded = (tag, points) => { if (points > 0) deductions.push({ tag, points }); };

  // 1. retrieval grounding — did we find and read real code at all?
  ded('hits', ev.hits === 0 ? 40 : 0);
  ded('code', (ev.snippets === 0 ? 20 : 0) + (ev.codeShared === 0 ? 10 : 0));

  // 2. call chain — can we trace how it works end to end?
  ded('chains', ev.chains === 0 ? 15 : 0);

  // 3. fabrication — references the model cited that DO NOT exist in the repo (the key trust signal).
  ded('suspect', cap(ev.suspectPaths.size * 8, 24) + cap(ev.suspectSymbols.size * 5, 20));

  // 4. tests — existing coverage to mirror and verify against.
  ded('tests', ev.testsFound === 0 ? 10 : 0);

  // 5. docs — documented conventions to anchor to.
  ded('docs', ev.docs === 0 ? 5 : 0);

  const total = deductions.reduce((s, d) => s + d.points, 0);
  const score = Math.max(0, 100 - total);
  const decision = score >= GOOD_TO_GO_MIN
    ? '✅ GOOD TO GO'
    : '⚠️ REQUIRES DEVELOPER REVIEW BEFORE IMPLEMENTATION';
  return { score, decision, deductions, evidence: ev };
}

// Render the confidence section as clean, readable markdown: a score line + a drivers list, with the
// point cost shown inline (−N) on any driver that lowered the score, so it reads well AND is auditable.
// No prose, no internal plumbing. Names + counts only (no code) so it passes the egress guard when the
// finished plan is sent back out for summarization.
export function renderConfidenceBlock(conf) {
  const ev = conf.evidence;
  const penalty = {};
  for (const d of conf.deductions) penalty[d.tag] = (penalty[d.tag] || 0) + d.points;
  const tail = (tag) => (penalty[tag] ? `  (−${penalty[tag]})` : '');

  const drivers = [
    `- Verified code references: ${ev.hits ? `${ev.hits} found and confirmed in the codebase` : 'none found'}${tail('hits')}`,
    `- End-to-end flow: ${ev.chains ? `traced (${ev.chains} relationships resolved)` : 'not traced — call chain unresolved'}${tail('chains')}`,
    `- Code reviewed: ${ev.snippets} area(s) read, ${ev.codeShared} shared for planning${tail('code')}`,
    `- Test coverage: ${ev.testsFound ? `${ev.testsFound} test file(s) near the affected area` : 'none found for the affected area'}${tail('tests')}`,
    `- Documentation: ${ev.docs ? `${ev.docs} related doc(s) found` : 'none found nearby'}${tail('docs')}`,
  ];
  const suspects = [...ev.suspectPaths, ...ev.suspectSymbols];
  if (suspects.length) {
    drivers.push(`- Unverified references (cited but not found in the codebase): ${suspects.join(', ')}${tail('suspect')}`);
  }

  return [
    '## Confidence assessment',
    `Overall confidence: ${conf.score}%  ·  Decision: ${conf.decision}`,
    '',
    'Confidence drivers:',
    ...drivers,
  ].join('\n');
}

// Replace the plan's "## Confidence assessment" section with our deterministic block (the planner
// emits a placeholder there). If the planner omitted the heading, insert our block before the first
// section so confidence still appears up top. Guarantees the saved number is OURS, never the LLM's.
export function applyConfidence(plan, conf) {
  const body = renderConfidenceBlock(conf).trim() + '\n';
  const hm = plan.match(/##[ \t]*Confidence assessment[^\n]*/i);
  if (hm) {
    const start = hm.index;
    const afterHeader = start + hm[0].length;
    const rel = plan.slice(afterHeader).search(/\n##[ \t]/);
    if (rel === -1) return plan.slice(0, start) + body;            // confidence was the last section
    const nextSec = afterHeader + rel + 1;                          // index of the next "## "
    return plan.slice(0, start) + body + '\n' + plan.slice(nextSec);
  }
  const firstSec = plan.search(/\n##[ \t]/);                        // fallback: heading missing
  if (firstSec !== -1) return plan.slice(0, firstSec + 1) + body + '\n' + plan.slice(firstSec + 1);
  return plan.trimEnd() + '\n\n' + body;                            // no sections at all
}

// Self-test / demo: `node src/agent/confidence.js`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const clean = computeConfidence(foldEvidence(newEvidence(), {
    stats: { hits: 14, chains: 22, snippets: 9, codeShared: 6, docs: 1, testsFound: 2 }, unverified: {},
  }));
  const messy = computeConfidence(foldEvidence(newEvidence(), {
    stats: { hits: 6, chains: 0, snippets: 3, codeShared: 2, docs: 0, testsFound: 0 },
    unverified: { paths: ['src/Made/Up.cs'], symbols: ['DeleteMany', 'HydrantTaskDocument', 'RemoveAgencyOrphans'] },
  }));
  const blind = computeConfidence(newEvidence());
  for (const [name, c] of [['CLEAN', clean], ['MESSY', messy], ['BLIND', blind]]) {
    console.log(`\n=== ${name}: ${c.score}% ${c.decision} ===\n${renderConfidenceBlock(c)}`);
  }
}
