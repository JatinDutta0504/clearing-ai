import { fileURLToPath } from 'node:url';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { ROOT, getActiveRepos } from '../config.js';
import { gatherContext } from './analyze.js';

// Rough eval harness for the local librarian. Runs a spread of query TYPES through the
// senior-engineer research pipeline (gatherContext: deterministic dig + structured synthesis +
// validation), capturing the gathering stats + timing + unverified citations so we can grade
// efficiency and correctness. Results -> output/eval-results.json. Run: `npm run agent:eval`.

const QUERIES = [
  { id: 'q1-write-path', type: 'backend write path',
    q: "How is a hydrant's inspection status updated and persisted? Name the controller method, the command, and the handler. Be concise." },
  { id: 'q2-frontend', type: 'frontend',
    q: 'In the Angular frontend, how are hydrants loaded and shown on the map view? Name the key components and services. Be concise.' },
  { id: 'q3-endpoints', type: 'api surface',
    q: 'What API endpoints exist for creating and updating a hydrant? Give the HTTP method and route for each. Be concise.' },
  { id: 'q4-schema', type: 'data/schema',
    q: 'What database tables store hydrant data, and what are their key columns? Be concise.' },
  { id: 'q5-auth', type: 'cross-cutting',
    q: 'How is authentication and authorization handled on the hydrants API controllers? Be concise.' },
  { id: 'q6-tests', type: 'test coverage',
    q: 'What automated tests cover updating a hydrant? Name the test files and key test methods. Be concise.' },
  { id: 'q7-specific', type: 'specific symbol',
    q: 'What does the HydrantService class do and what are its main methods? Be concise.' },
  { id: 'q8-negative', type: 'honesty (absent feature)',
    q: 'How does the billing and payment processing system work in this repository? Be concise.' },
];

const repo = getActiveRepos()[0];
if (!repo) throw new Error('No active repos in config/boards.json');

console.log(`\n[eval] repo=${repo.name}  model run, ${QUERIES.length} queries\n`);
const results = [];

for (const t of QUERIES) {
  const steps = [];
  const t0 = Date.now();
  let answer = '', stats = {}, unverified = { paths: [], symbols: [] }, error = null;
  try {
    const r = await gatherContext(repo, t.q, { onStep: ({ tool, info }) => steps.push(`${tool}: ${info}`) });
    answer = r.package; stats = r.stats; unverified = r.unverified;
  } catch (e) { error = e.message; }
  const elapsedSec = Math.round((Date.now() - t0) / 1000);

  results.push({ id: t.id, type: t.type, query: t.q, elapsedSec, stats, steps, unverified, answer, error });

  const unv = unverified.paths.length + unverified.symbols.length;
  console.log(`\n===== ${t.id} (${t.type}) — ${elapsedSec}s — ${JSON.stringify(stats)} — unverified:${unv} =====`);
  for (const s of steps) console.log(`  -> ${s}`);
  console.log(`PACKAGE:\n${answer || ('ERROR: ' + error)}`);
}

mkdirSync(resolve(ROOT, 'output'), { recursive: true });
const path = resolve(ROOT, 'output', 'eval-results.json');
writeFileSync(path, JSON.stringify(results, null, 2));

const totalSec = results.reduce((s, r) => s + r.elapsedSec, 0);
console.log(`\n\n[eval] DONE. ${results.length} queries, ${totalSec}s total (avg ${Math.round(totalSec / results.length)}s). -> ${path}`);
