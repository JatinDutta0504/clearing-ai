import { fileURLToPath } from 'node:url';
import { createAgentTools, TOOL_SCHEMAS } from './tools.js';
import { getActiveRepos, localEngine } from '../config.js';

// The local (Zone-A) LLM agent: a code librarian that DRIVES the 6a tools to answer questions
// about the repo. It reads the graph (map) + live files (territory) and never leaves org infra.
// Tool-calling loop over Ollama's /api/chat. No fabrication — every claim must come from a tool.

const MAX_TOOL_RESULT_CHARS = 12_000; // keep one tool result from blowing the context window

function systemPrompt(repoName) {
  return [
    `You are a precise code librarian for the software repository "${repoName}".`,
    ``,
    `HARD RULES:`,
    `- ALWAYS begin by calling search_graph to ground yourself in THIS repository's actual code, even`,
    `  if you think you already know the answer. NEVER answer from generic assumptions about how`,
    `  software is usually structured (e.g. "src/server/...", "PaymentController") — this repo is`,
    `  specific and may not contain what you assume.`,
    `- Use ONLY facts that appear in actual tool RESULTS. If the tools return nothing relevant, state`,
    `  plainly that the feature/code does not appear to exist in this repository. NEVER invent file`,
    `  paths, class names, routes, columns, methods, or behavior — not even plausible-sounding ones.`,
    `- search_graph ALWAYS returns its closest matches even when nothing truly fits. Check each`,
    `  result's score and whether it is genuinely about the question. If the results are unrelated to`,
    `  what was asked (e.g. flow-rate code for a billing question), conclude the feature does not`,
    `  appear to exist — do NOT stretch unrelated results to fit the question.`,
    `- You obtain information ONLY by calling a tool and receiving its result. Do NOT write prose that`,
    `  describes, imagines, or claims tool calls or their results. Either call a tool, or give your`,
    `  final answer — never narrate a tool call in text.`,
    `- Do not answer from one search alone: after locating candidates with search_graph, verify with`,
    `  neighbors and/or read_file before answering.`,
    ``,
    `QUESTION-TYPE HINTS:`,
    `- "tests": the relevant files end in "Tests.cs" or ".spec.ts" — find them with grep/list_files;`,
    `  production classes (services, entities, commands, controllers) are NOT tests.`,
    `- "frontend"/Angular/UI: look under src/client; a ".cs" file is backend, not the Angular frontend.`,
    `- column/schema details: read_file the table config or migration; do not guess columns.`,
    ``,
    `Tools (the system runs them and returns results): search_graph(query, types?), neighbors(id),`,
    `list_files(dir?, contains?, lang?), read_file(path, start?, end?), grep(pattern, dir?, lang?).`,
    ``,
    `When verified, write a concise answer citing only the real paths and names that appeared in`,
    `tool results.`,
  ].join('\n');
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// One non-streaming chat turn against Ollama. A local inference server can briefly drop the
// connection between calls (model load/reload) — that's a NETWORK error, so we retry it with
// backoff (retries beat fallbacks). A real HTTP error status fails loud immediately (no retry).
export async function chatOnce(engine, messages, { retries = 3, useTools = true } = {}) {
  const body = JSON.stringify({
    model: engine.model,
    messages,
    ...(useTools ? { tools: TOOL_SCHEMAS } : {}),
    stream: false,
    keep_alive: engine.keepAlive, // stay resident — avoids cold-reload "unreachable" between calls
    options: { temperature: engine.temperature, num_ctx: engine.numCtx },
    ...(engine.think !== undefined ? { think: engine.think } : {}),
  });

  for (let attempt = 0; ; attempt++) {
    let res;
    try {
      res = await fetch(`${engine.host}/api/chat`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body,
      });
    } catch (err) {
      if (attempt < retries) {
        const wait = 1500 * (attempt + 1);
        process.stderr.write(`\n[local] Ollama unreachable (attempt ${attempt + 1}/${retries + 1}), retrying in ${wait}ms...\n`);
        await sleep(wait);
        continue;
      }
      throw new Error(`cannot reach Ollama at ${engine.host} (is it running? \`ollama serve\`): ${err.message}`);
    }
    if (!res.ok) throw new Error(`Ollama /api/chat ${res.status}: ${await res.text()}`);
    return res.json();
  }
}

// Normalize a structured tool-call's arguments (object, or JSON string on some builds).
function toolArgs(call) {
  const a = call?.function?.arguments;
  if (a && typeof a === 'object') return a;
  if (typeof a === 'string') { try { return JSON.parse(a); } catch { return {}; } }
  return {};
}

const tryJson = (s) => { try { return JSON.parse(s); } catch { return null; } };
// Only count an object as a tool call if it has BOTH a string name AND an args object — this avoids
// mistaking a stray {...} in a prose answer for a call, while catching the real (possibly fenced) one.
const KNOWN_TOOLS = new Set(['search_graph', 'neighbors', 'list_files', 'read_file', 'grep']);
const asCall = (o) => {
  if (!o || typeof o.name !== 'string') return null;
  const args = o.arguments ?? o.args;
  if (args === undefined || typeof args !== 'object') return null;
  if (!KNOWN_TOOLS.has(o.name)) return null;
  return { name: o.name, args };
};

// Scan text for every balanced {...} object (quote/escape aware) and return those that parse to a
// tool call. Robust to ```json fences, bare JSON, and JSON embedded in narration.
function findCalls(text) {
  const calls = [];
  for (let i = 0; i < text.length; i++) {
    if (text[i] !== '{') continue;
    let depth = 0, inStr = false, esc = false;
    for (let j = i; j < text.length; j++) {
      const c = text[j];
      if (esc) { esc = false; continue; }
      if (c === '\\') { esc = true; continue; }
      if (c === '"') inStr = !inStr;
      else if (!inStr && c === '{') depth++;
      else if (!inStr && c === '}') {
        if (--depth === 0) {
          const call = asCall(tryJson(text.slice(i, j + 1)));
          if (call) calls.push(call);
          i = j; // resume scanning after this object
          break;
        }
      }
    }
  }
  return calls;
}

/**
 * Extract tool calls from a model message. Prefers Ollama's structured `tool_calls`, else parses
 * `content` (qwen often emits the call as bare/fenced JSON, sometimes wrapped in narration like
 * "after running X I found..."). We scan for any balanced {...} that parses to a known tool call.
 * Returns [] only when the message is a genuine prose answer with no tool-call JSON in it.
 */
export function extractCalls(msg) {
  if (Array.isArray(msg.tool_calls) && msg.tool_calls.length) {
    return msg.tool_calls.map((c) => ({ name: c.function?.name, args: toolArgs(c) })).filter((c) => c.name);
  }
  const content = (msg.content || '').trim();
  if (!content) return [];

  // <tool_call>...</tool_call> tags first (some templates use them).
  const tagged = [];
  const tagRe = /<tool_call>\s*([\s\S]*?)\s*<\/tool_call>/g;
  let m;
  while ((m = tagRe.exec(content))) { const c = asCall(tryJson(m[1])); if (c) tagged.push(c); }
  if (tagged.length) return tagged;

  // Otherwise scan all balanced objects (catches fenced ```json calls + calls buried in prose).
  return findCalls(content);
}

/**
 * Ask the local agent a question about `repo`. Runs the tool-calling loop until the model answers
 * or hits maxIterations. Returns { answer, rounds, exhausted, transcript }. `onStep` (optional) is
 * called after every tool execution for live logging.
 */
export async function askLocal(repo, question, { onStep = null } = {}) {
  const engine = localEngine();
  const tools = createAgentTools(repo);
  const dispatch = {
    search_graph: tools.search_graph,
    neighbors: tools.neighbors,
    list_files: tools.list_files,
    read_file: tools.read_file,
    grep: tools.grep,
  };
  const messages = [
    { role: 'system', content: systemPrompt(repo.name) },
    { role: 'user', content: question },
  ];

  let anyToolCalled = false; // must ground in a real tool result before any answer is accepted
  let forcedSearch = false;  // we force that grounding at most once

  try {
    for (let round = 1; round <= engine.maxIterations; round++) {
      const out = await chatOnce(engine, messages);
      const msg = out.message || {};
      const calls = extractCalls(msg);

      if (calls.length === 0) {
        // Reject an answer produced without ever consulting the repo — force one search first.
        if (!anyToolCalled && !forcedSearch) {
          forcedSearch = true;
          messages.push({ role: 'assistant', content: msg.content || '' });
          messages.push({
            role: 'user',
            content: 'You have not consulted the repository yet. Call search_graph to find the'
              + ' relevant code in THIS repo, then answer based only on what the tools return.'
              + ' If nothing relevant is found, say it does not appear to exist.',
          });
          continue;
        }
        messages.push({ role: 'assistant', content: msg.content || '' });
        return { answer: msg.content || '', rounds: round, exhausted: false, transcript: messages };
      }

      // Normalize back to structured tool_calls so the chat template re-renders them cleanly.
      messages.push({
        role: 'assistant',
        content: '',
        tool_calls: calls.map((c) => ({ function: { name: c.name, arguments: c.args } })),
      });

      for (const { name, args } of calls) {
        anyToolCalled = true;
        let result;
        try {
          const fn = dispatch[name];
          if (!fn) throw new Error(`unknown tool: ${name}`);
          result = await fn(args);
        } catch (err) {
          result = { error: err.message };
        }
        if (onStep) onStep({ round, tool: name, args, result });
        const content = JSON.stringify(result).slice(0, MAX_TOOL_RESULT_CHARS);
        messages.push({ role: 'tool', name, content });
      }
    }
    return { answer: null, rounds: engine.maxIterations, exhausted: true, transcript: messages };
  } finally {
    tools.close();
  }
}

// Run directly: `node src/agent/local.js "your question about the repo"`
// Requires Ollama running with the configured model pulled. Needs NODE_EXTRA_CA_CERTS (embed model).
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const question = process.argv.slice(2).join(' ') || 'How does updating a hydrant inspection work end to end?';
  const repo = getActiveRepos()[0];
  if (!repo) throw new Error('No active repos in config/boards.json');

  console.log(`\n[local] repo=${repo.name}  q="${question}"\n`);
  const r = await askLocal(repo, question, {
    onStep: ({ round, tool, args, result }) => {
      const n = Array.isArray(result) ? result.length : (result?.hits?.length ?? result?.files?.length ?? '');
      const note = result?.error ? `ERROR ${result.error}` : `${n} result(s)`;
      console.log(`  [r${round}] ${tool}(${JSON.stringify(args)}) -> ${note}`);
    },
  });

  console.log(`\n--- answer (${r.rounds} round(s)${r.exhausted ? ', EXHAUSTED' : ''}) ---\n`);
  console.log(r.answer ?? '(no answer — hit iteration cap)');
}
