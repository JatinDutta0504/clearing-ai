import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ROOT, loadAi, getActiveRepos, getSettings } from '../config.js';
import { JiraClient, adfToText } from '../jira.js';
import { gatherContext } from './analyze.js';
import { newEvidence, foldEvidence, computeConfidence, applyConfidence } from './confidence.js';
import { sendToExternal } from '../external/egressClient.js';
import { inspectRequest } from '../security/localGuard.js';
import { inspectEgress } from '../security/egressGuard.js';
import { redactSecrets } from '../security/redact.js';

// ── THE LOOP (per ticket) ────────────────────────────────────────────────────────────────────
// The EXTERNAL planner drives; the LOCAL librarian answers from the graph + live files. A notebook
// (messages array) grows each round and is resent whole every external call. One notebook per
// ticket, discarded after. HARD CAP on external calls. Two guards on the boundary:
//   inbound  external question  -> inspectRequest (block extraction/injection)
//   outbound everything we send -> egress guard inside sendToExternal (block code/secrets)
// The local answer is also pre-sanitized here so a code-bearing answer never stalls the send.

const PLANNER_SYSTEM = [
  'You are a Principal Software Engineer writing ONE implementation plan for ONE Jira ticket. Your',
  'single deliverable is a developer blueprint: a plan a developer who has never seen this codebase can',
  'read in a few minutes and start solving the ticket from. It explains the issue AND how to fix it —',
  'diagnosis is just the first part of the plan, NOT a separate report. Do exactly one job: produce the',
  'plan that covers everything needed to solve this ticket.',
  '',
  'HOW YOU WORK:',
  'You CANNOT see the source code. A local librarian who CAN see the codebase answers your questions',
  'with names, summaries, relationships, and bounded relevant code snippets. The librarian has already',
  'validated its findings against the code graph: anything marked "unverified/suspect" or "not found"',
  'is NOT confirmed. Gather what you need, then write the plan. You never see or request whole files.',
  '',
  'PROTOCOL — respond with ONLY one of these, nothing else:',
  '  - To ask the librarian:  {"action":"ask","question":"<one specific question>"}',
  '  - To deliver the plan:   a line containing exactly  FINAL_PLAN:  then the full markdown plan on',
  '                           the following lines (raw markdown, NOT wrapped in JSON). The FINAL_PLAN:',
  '                           marker is REQUIRED — without it the plan is not saved.',
  '',
  'ASKING RULES:',
  '- Ask EXACTLY ONE focused question per message — never bundle multiple questions into one. The',
  '  librarian answers one question at a time; a compound question gets a worse answer.',
  '- Only ask about something you do not already know.',
  '- NEVER repeat or rephrase a previous question. If an answer did not come, it is not available.',
  '- If the librarian says a detail is "not found" or "does not appear to exist", treat it as FINAL —',
  '  record it under Assumptions and open questions and move on. Do not probe it again.',
  '- Each question targets a NEW aspect (data model, validation, tests, an existing similar feature to',
  '  mirror, dependencies, permissions...).',
  '- Be efficient: once you understand the issue, what to change, the pattern to follow, the order, and',
  '  how to test it, STOP asking and write the plan. Aim for 2-4 questions.',
  '',
  'GROUNDING RULES (critical):',
  '- Use ONLY files, classes, methods, routes, and tables the librarian actually reported. NEVER invent',
  '  paths, symbols, APIs, tables, or workflows. If you lack something, mark it Unknown or put it under',
  '  Assumptions and open questions — never guess.',
  '- Label anything the librarian flagged "unverified/suspect" as such.',
  '- This is a PRE-IMPLEMENTATION plan: no code has been changed. Never imply work is done.',
  '- Your OUTPUT is ANALYSIS ONLY — do NOT write code, code snippets, or implementation code. Reference',
  '  exact names/routes/fields, but never paste or invent code.',
  '- Incorporate the available inputs: the Jira description, the acceptance criteria (usually inside the',
  '  description), and the librarian findings. Screenshots, attachments, and user comments are NOT',
  '  available to you — do not assume or fabricate them.',
  '',
  'THE PLAN — be thorough but tight. Target about 600 lines and NEVER exceed 800 lines. Write for both a',
  'Support Agent (plain English first) and a Developer (technical detail after). Use these sections;',
  'omit one only if truly N/A:',
  '',
  '# <TICKET-ID> — <Title>  (priority)',
  'One or two lines: what the ticket is about and the goal. End with a one-sentence TL;DR of the fix.',
  '',
  '## Confidence assessment',
  'Do NOT compute or estimate a confidence number. The orchestrator computes the real, evidence-based',
  'score deterministically from the verified retrieval data and replaces this section. Under this',
  'heading output exactly one line and nothing else:',
  'CONFIDENCE_PLACEHOLDER',
  '',
  '## Short answer (for the Support Agent)',
  'A 2-5 sentence plain-English explanation: whether the issue is confirmed or suspected, which part of',
  'the system appears responsible, the high-level reason, and whether developer work is required.',
  '',
  '## What the ticket is reporting',
  'The request/complaint in simple language: "When users do X, they expect Y; instead Z happens."',
  '',
  '## How it works today',
  'Current behavior and the end-to-end path of the relevant flow as a trace:',
  '  entry point -> component -> service -> API/handler -> storage/integration',
  '(grounded in the librarian call chain).',
  '',
  '## Root cause / the issue',
  'If a bug: the root cause and the evidence for it (incorrect logic, null handling, parameter mismatch,',
  'missing validation, wrong query, hardcoded value, etc.). If a feature: the gap being filled. State',
  'whether it is confirmed or suspected.',
  '',
  '## Codebase analysis (mandatory)',
  'From librarian-verified findings ONLY, identify all relevant: modules, services, controllers, APIs,',
  'repositories, database objects, UI components, feature flags, configuration settings, permissions,',
  'background jobs, and external integrations related to the issue.',
  '',
  '## Existing functionality verification (mandatory)',
  'Determine whether this enhancement/bug/feature — or any part of it — already exists or is partially',
  'implemented. Identify reusable services, APIs, components, repositories, DB structures, and patterns.',
  'If found, explain how to LEVERAGE or EXTEND it instead of duplicating. Avoid duplicate implementations.',
  '',
  '## Pattern to follow',
  'The existing convention this change must match (e.g. the CQRS command pattern, the modal service, the',
  'validation approach, the test style), AND a reference: an existing analogous implementation to mirror',
  '(e.g. "schedule() mirrors bulkDelete()"). Real, librarian-verified only.',
  '',
  '## What to change',
  'Start here: `primary/file/path` -> `Class.Method`  (the main entry point to open first).',
  'Then each touch point:',
  '- `exact/file/path` -> `Class.Method` — what to do (add / modify / delete) and why; include the',
  '  exact names/enums/routes/fields to use.',
  'Quick-scan matrix:',
  '| File | Symbol | Change | Priority |',
  '',
  '## Files for developer review',
  'For each file to open:  * File: <path>  ·  Method: <method>  ·  Lines: <range>  ·  Reason: <why>',
  '',
  '## Step-by-step implementation plan (phased)',
  'Break the work into logical phases. Each phase = actionable, trackable tasks; each step names the',
  'impacted area and is independently verifiable. Where applicable, cover: frontend, backend, API,',
  'database, configuration, external integration, and deployment changes.',
  '',
  '## Development tasks (Jira-subtask-ready)',
  'Granular tasks, each suitable to become a Jira subtask. For each give: Description · Impacted',
  'component · Dependencies · Completion criteria.',
  '',
  '## Testing plan (mandatory)',
  'Positive: happy-path workflows, acceptance-criteria validation, expected behavior. Negative: invalid',
  'input, missing data, permission checks, error handling, boundary conditions, edge cases. Regression:',
  'existing workflows and related/previously-implemented features. Integration: API, database, and',
  'external-system interactions. Match the existing test style in this repo.',
  '',
  '## Validation plan',
  'How the team confirms the issue is fully resolved: UI, API, database, business-rule, and data-integrity',
  'validation (plus performance when applicable). Confirm acceptance criteria are met, existing',
  'functionality is unaffected, and no regressions are introduced.',
  '',
  '## Documentation recommendations',
  'What docs or notes should be updated or added (brief).',
  '',
  '## Risks, dependencies & gotchas',
  'Only real ones: DB migrations, feature flags, env/config, concurrency, ordering, breaking changes.',
  'Mark Unknown where the librarian could not confirm.',
  '',
  '## Assumptions & open questions',
  'Everything you could not verify from the codebase — listed explicitly, never silently assumed.',
  '',
  '## Out of scope · Done',
  'What must NOT be touched for this ticket · what "done" looks like (1-2 bullets each).',
].join('\n');

// A separate, post-plan summarization prompt. The planner re-reads its OWN finished plan and writes a
// short, glance-able summary for the Jira comment. This is NOT part of the plan template — it is its
// own dedicated call, so the plan itself is unchanged.
const SUMMARY_SYSTEM = [
  'You summarize a software implementation plan into a short, STRUCTURED Jira comment for someone',
  'scanning the ticket. Output a bullet list — one bullet per line, each starting with "- " and a plain',
  'label followed by a colon — in EXACTLY this order. Do NOT use markdown bold or asterisks (Jira shows',
  'them literally):',
  '- About: what this ticket is about (one line).',
  '- Issue: what is wrong, or what the ticket needs, in plain language.',
  '- Root cause: the underlying cause (brief); use "N/A — new feature" if it is not a bug.',
  '- Fix / approach: the overall fix at a high level — the main area/files and what changes. Add a few',
  '  indented sub-bullets ("  - ...") if there are distinct steps.',
  '- Impact: the key risk or dependency, or "Low" if none significant.',
  '- Confidence: the plan\'s confidence % and GOOD TO GO or NEEDS REVIEW.',
  'Keep each bullet to 1-2 lines, plain language, no code, no markdown headings, no asterisks, no',
  'preamble. Anyone should grasp the ticket, the issue, and the fix in a few seconds. Output ONLY the',
  'bullet list.',
].join('\n');

// Parse the planner's reply. Preferred final form is a `FINAL_PLAN:` marker followed by raw markdown
// (no JSON escaping — robust for a long plan). Otherwise expect an {"action":"ask",...} JSON object
// (bare or embedded in prose). Back-compat: a JSON {"action":"final","plan":...} is still accepted.
function parseAction(content) {
  const text = content || '';
  const fp = text.match(/FINAL_PLAN:\s*([\s\S]*)$/);
  if (fp && fp[1].trim()) return { action: 'final', plan: fp[1].trim() };
  const tryObj = (s) => { try { return JSON.parse(s); } catch { return null; } };
  let o = tryObj(text.trim());
  if (!o) { const m = text.match(/\{[\s\S]*\}/); if (m) o = tryObj(m[0]); }
  if (o && o.action) return o;
  return { action: 'unknown', raw: content };
}

// Gather a verified context package for the question (deterministic dig + synthesis + validation),
// then make SURE it is egress-clean before it enters the notebook. gatherContext already forbids
// code blocks and validates citations; the egress guard is the final backstop (never leak).
async function safeLocalAnswer(repo, question, seenSnippets) {
  const { package: pkg, stats, unverified } = await gatherContext(repo, question, { seenSnippets });
  const answer = (pkg || '').trim();
  // The evidence (stats + suspect citations) was gathered either way — pass it back for the
  // deterministic confidence score even when the answer itself is too large to share.
  if (inspectEgress(answer).allowed) return { answer, sanitized: false, stats, unverified };
  return {
    answer: 'The gathered context exceeded the safe sharing bound (too large, too much code, or a'
      + ' secret was detected). Please ask a narrower, more specific question.',
    sanitized: true, stats, unverified,
  };
}

// One extra external call that turns the finished plan into a short, well-written comment summary.
// Goes through the egress-guarded path like every send. The caller treats this as best-effort — a
// failure here must never fail the (already-written) plan; the comment falls back to extraction.
async function summarizePlan(ticket, plan) {
  const reply = await sendToExternal([
    { role: 'system', content: SUMMARY_SYSTEM },
    { role: 'user', content: `Implementation plan for ${ticket.key} — ${ticket.summary || ''}:\n\n${plan}` },
  ], { ticket: ticket.key, round: 'summary' });
  return (reply.content || '').trim();
}

// Render the full local<->external conversation to a readable markdown file (Zone A, local only).
// This is the human-facing "see the chat" artifact — the egress audit log stays content-free.
function writeChat(ticket, transcript) {
  const path = resolve(ROOT, 'output', `${ticket.key}-chat.md`);
  mkdirSync(resolve(ROOT, 'output'), { recursive: true });
  const head = `# Conversation — ${ticket.key}\n\n> ${ticket.summary || ''}\n\n`
    + `_LOCAL = on-prem librarian (sees code, sends names+summaries only) · `
    + `EXTERNAL = Azure Foundry planner (never sees code)._\n`;
  const body = transcript
    .map((t) => `\n---\n\n## ${t.label}${t.round ? `  ·  round ${t.round}` : ''}\n\n${(t.text || '').trim()}\n`)
    .join('');
  writeFileSync(path, head + body);
  return path;
}

/**
 * Plan one ticket. `ticket` = { key, summary, description }.
 * Returns { status:'planned'|'capped'|'error', plan, rounds, calls, path, chatPath }.
 */
export async function planTicket(repo, ticket, { onEvent = null } = {}) {
  const maxCalls = loadAi().external?.maxCalls ?? 10;
  const emit = (e) => onEvent && onEvent(e);
  const transcript = [];          // full local<->external chat (rendered to output/KEY-chat.md)
  const seenSnippets = new Set();  // (A) snippets already shared this ticket — never re-send the same code
  const evidence = newEvidence();  // accumulates verified retrieval signals -> deterministic confidence

  // 1. Local librarian builds the initial findings for this ticket (sanitized names + summaries).
  const brief = redactSecrets(`${ticket.summary || ''}\n\n${ticket.description || ''}`).text.trim();
  emit({ phase: 'initial', msg: 'local librarian gathering initial context' });
  const initial = await safeLocalAnswer(
    repo,
    `A Jira ticket (${ticket.key}) requests:\n"${brief}"\n\nIdentify the relevant code areas (files,`
    + ` classes, methods, endpoints, tables) and summarize how the current behavior works. Names and`
    + ` summaries only.`,
    seenSnippets
  );
  foldEvidence(evidence, initial);
  emit({ phase: 'initial', msg: 'local librarian gathering initial context', content: initial.answer });

  // 2. Open the notebook.
  const notebook = [
    { role: 'system', content: PLANNER_SYSTEM },
    {
      role: 'user',
      content: `TICKET ${ticket.key}: ${ticket.summary || ''}\n\nDescription:\n${brief}\n\n`
        + `Initial findings from the local librarian:\n${initial.answer}`,
    },
  ];

  // Record the EXACT opening payload that egresses, so chat.md shows everything we send the planner —
  // not just the Q&A. The system prompt is resent verbatim every round; this user message is round 1.
  transcript.push({ label: 'SYSTEM PROMPT → planner (resent verbatim every round)', text: notebook[0].content });
  transcript.push({ label: 'USER → planner (round 1 input: ticket + description + initial findings)', text: notebook[1].content });

  // 3. Drive the loop: external asks, local answers, until a final plan or the cap.
  for (let calls = 1; calls <= maxCalls; calls++) {
    emit({ phase: 'external', round: calls, msg: `sending notebook to planner (call ${calls}/${maxCalls})` });
    const reply = await sendToExternal(notebook, { ticket: ticket.key, round: calls });
    notebook.push({ role: 'assistant', content: reply.content });

    const action = parseAction(reply.content);
    const plannerSay = action.action === 'ask' ? String(action.question || '').trim()
      : action.action === 'final' ? String(action.plan || '').trim()
      : reply.content;
    transcript.push({ label: `EXTERNAL → ${action.action}`, round: calls, text: plannerSay });
    emit({ phase: 'planner', round: calls, action: action.action, content: plannerSay });

    if (action.action === 'final') {
      let plan = String(action.plan || '').trim();
      // Replace the planner's CONFIDENCE_PLACEHOLDER with OUR deterministic, evidence-based score
      // (computed from the verified retrieval signals — never the LLM's guess). This also feeds the
      // comment summary below, since summarizePlan re-reads the finished plan.
      const conf = computeConfidence(evidence);
      plan = applyConfidence(plan, conf);
      emit({ phase: 'confidence', round: calls, msg: `confidence ${conf.score}% (${conf.decision}) — ${conf.deductions.length} deduction(s)` });
      const path = resolve(ROOT, 'output', `${ticket.key}-plan.md`);
      mkdirSync(resolve(ROOT, 'output'), { recursive: true });
      // The plan is self-titled (# <TICKET-ID> — <Title>), so write it as-is — no duplicate header.
      writeFileSync(path, `${plan}\n`);
      // One extra external call: a clean, glance-able summary for the Jira comment. Best-effort —
      // a failure here must NOT fail the already-written plan; the comment falls back to extraction.
      let summary = '';
      emit({ phase: 'summary', round: calls, msg: 'generating comment summary' });
      try { summary = await summarizePlan(ticket, plan); }
      catch (e) { emit({ phase: 'summary', round: calls, msg: `summary skipped: ${e.message}` }); }
      transcript.push({ label: 'EXTERNAL → comment summary', round: calls, text: summary || '(summary call failed — comment will fall back to extraction)' });
      transcript.push({ label: 'ORCHESTRATOR → confidence (deterministic, replaced the placeholder)', round: calls, text: applyConfidence('## Confidence assessment\nCONFIDENCE_PLACEHOLDER', conf).trim() });
      const chatPath = writeChat(ticket, transcript);
      emit({ phase: 'done', round: calls, msg: `plan written -> ${path}  ·  chat -> ${chatPath}` });
      return { status: 'planned', plan, summary, confidence: conf.score, rounds: calls, calls, path, chatPath };
    }

    if (action.action === 'ask') {
      const question = String(action.question || '').trim();
      const screen = inspectRequest(question);
      emit({ phase: 'ask', round: calls, question, blocked: !screen.allowed });

      let answerText;
      if (!screen.allowed) {
        // Inbound attack (extraction/injection) — refuse; do NOT touch the tools for it.
        answerText = `I can't provide that — it requests source code or asks me to bypass my rules`
          + ` (${screen.category}). Ask for a high-level summary, relationships, or impact instead.`;
      } else {
        const a = await safeLocalAnswer(repo, question, seenSnippets);
        foldEvidence(evidence, a);
        answerText = a.answer;
      }
      transcript.push({ label: `LOCAL → answer${screen.allowed ? '' : ' (refused)'}`, round: calls, text: answerText });
      emit({ phase: 'local', round: calls, content: answerText, blocked: !screen.allowed });
      notebook.push({ role: 'user', content: answerText });
      continue;
    }

    // Planner didn't follow the protocol — nudge it once and continue.
    emit({ phase: 'unknown', round: calls, msg: 'planner reply was not valid JSON action' });
    notebook.push({
      role: 'user',
      content: 'Please respond with ONLY a JSON object: {"action":"ask","question":"..."} or {"action":"final","plan":"..."}.',
    });
  }

  const chatPath = writeChat(ticket, transcript);
  emit({ phase: 'capped', msg: `hit ${maxCalls}-call cap without a final plan  ·  chat -> ${chatPath}` });
  return { status: 'capped', plan: null, rounds: maxCalls, calls: maxCalls, path: null, chatPath };
}

// Run directly: `node src/agent/loop.js [ISSUE-KEY]`
//   needs Ollama running + Foundry configured in .env. Fetches the REAL ticket live from Jira
//   (arg overrides settings.sampleIssueKey), runs the full local<->external loop, writes local files.
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const repo = getActiveRepos()[0];
  if (!repo) throw new Error('No active repos in config/boards.json');

  const key = process.argv[2] || getSettings().sampleIssueKey;
  if (!key) throw new Error('No issue key — pass one as an arg or set settings.sampleIssueKey in config/boards.json');
  console.log(`\n[loop] fetching ticket ${key} from Jira ...`);
  const raw = await new JiraClient().getIssue(key, '*all');
  const ticket = {
    key: raw.key || key,
    summary: raw.fields?.summary || '',
    description: adfToText(raw.fields?.description).trim(),
  };
  console.log(`[loop] repo=${repo.name} ticket=${ticket.key} — "${ticket.summary}"\n`);
  const bar = '═'.repeat(78);
  const r = await planTicket(repo, ticket, {
    onEvent: (e) => {
      const tag = `${e.phase}${e.round ? ' r' + e.round : ''}`;
      if (e.content) {
        const who = e.phase === 'planner' ? `🟦 EXTERNAL planner (${e.action})`
          : e.phase === 'local' ? `🟩 LOCAL librarian${e.blocked ? ' (REFUSED)' : ''}`
          : '🟩 LOCAL librarian (initial findings)';
        console.log(`\n${bar}\n  ${who}  ·  ${tag}\n${bar}\n${e.content}\n`);
      } else {
        console.log(`  [${tag}] ${e.msg || ''}`);
      }
    },
  });
  console.log(`\n--- ${r.status} after ${r.calls} call(s) ---`);
  if (r.path) console.log(`plan: ${r.path}`);
  if (r.chatPath) console.log(`chat: ${r.chatPath}`);
}
