import { readFileSync, existsSync, statSync } from 'node:fs';
import { resolve, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb } from '../kg/schema.js';
import { repoDbPath, getActiveRepos, ROOT } from '../config.js';
import { searchByVector, neighbors as edgeNeighbors } from '../retrieval/repoDb.js';
import { embedQuery } from '../kg/embed.js';
import { SECRET_RE } from '../kg/build.js';

// The local (Zone-A) agent's hands. All read-only. Two kinds of sight:
//   the MAP  -> search_graph / neighbors  (repo.db: names, types, edges, summaries — NO bodies)
//   the LAND -> list_files / read_file / grep  (live from the local clone, bounded by the map)
// The file universe is db.files (already .gitignore + secret filtered at index time), so the agent
// can never wander into node_modules / build junk, and every path is jailed to the repo root.

const MAX_FILE_BYTES = 200_000;   // refuse to slurp giant files into context
const MAX_GREP_FILES = 4000;      // safety cap on a single grep sweep
const MAX_GREP_HITS = 200;
const NUL = String.fromCharCode(0); // binary-file heuristic marker (kept out of source as a literal)

// Resolve a repo-relative path to an absolute one, hard-failing if it escapes the repo root.
function jail(root, rel) {
  if (typeof rel !== 'string' || !rel.trim()) throw new Error('path is required');
  const full = resolve(root, rel);
  const back = relative(root, full);
  if (back === '' || back.startsWith('..') || isAbsolute(back)) {
    throw new Error(`path escapes repo root: ${rel}`);
  }
  if (SECRET_RE.test(back.replace(/\\/g, '/'))) throw new Error(`path is denied (secret): ${rel}`);
  return full;
}

const parseMeta = (m) => { try { return m ? JSON.parse(m) : {}; } catch { return {}; } };

/**
 * Build the tool set for one repo. Holds one open read-only db handle for the agent's lifetime.
 * Returns the callable tools + `close()`. Tool args are plain objects (so they map 1:1 onto the
 * model's function-calling JSON in the next step).
 */
export function createAgentTools(repo) {
  const root = resolve(ROOT, repo.localPath);
  if (!existsSync(root)) throw new Error(`repo clone not found: ${root} (run \`npm run repo\` first)`);
  const db = openDb(repoDbPath(repo.name), { repo: repo.name, branch: repo.branch });

  // db.files is the authoritative, pre-filtered file universe (paths only).
  const allFiles = () => db.prepare('SELECT path, lang, size FROM files ORDER BY path').all();

  // --- THE MAP -------------------------------------------------------------

  // Semantic discovery over the graph. Returns names/types/metadata only — never code.
  async function search_graph({ query, k = 12, types = null } = {}) {
    if (!query?.trim()) throw new Error('search_graph: query is required');
    const qvec = await embedQuery(query);
    const hits = searchByVector(db, qvec, { k, types, query }); // pass query -> down-ranks tests for non-test queries
    return hits.map((h) => {
      const m = parseMeta(h.metadata);
      return {
        id: h.id, type: h.type, name: h.name, score: Number(h.score.toFixed(3)),
        file: m.filePath || m.path || null, container: m.container || null,
        route: m.route || null, kind: m.kind || null,
      };
    });
  }

  // Graph walk: 1-hop neighbors of a node id (optionally filtered by relation type).
  function neighbors({ id, rels = null, limit = 50 } = {}) {
    if (!id?.trim()) throw new Error('neighbors: id is required');
    return edgeNeighbors(db, id, { rels, limit }).map((r) => ({
      relation: r.rel, direction: r.source_id === id ? 'out' : 'in',
      id: r.id, type: r.type, name: r.name,
    }));
  }

  // --- THE LAND ------------------------------------------------------------

  // List indexed files, optionally under a path prefix and/or matching a substring.
  function list_files({ dir = '', contains = null, lang = null, limit = 500 } = {}) {
    const pre = dir.replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
    let rows = allFiles();
    if (pre) rows = rows.filter((r) => r.path === pre || r.path.startsWith(pre + '/'));
    if (lang) rows = rows.filter((r) => r.lang === lang);
    if (contains) { const c = contains.toLowerCase(); rows = rows.filter((r) => r.path.toLowerCase().includes(c)); }
    return { total: rows.length, files: rows.slice(0, limit) };
  }

  // Read a file live from the clone (path-jailed, secret-denied). Optional 1-based line slice.
  function read_file({ path, start = null, end = null } = {}) {
    const full = jail(root, path);
    if (!existsSync(full) || !statSync(full).isFile()) throw new Error(`not a file: ${path}`);
    const size = statSync(full).size;
    if (size > MAX_FILE_BYTES && start == null && end == null) {
      throw new Error(`file too large (${size}B > ${MAX_FILE_BYTES}); pass start/end line range`);
    }
    const lines = readFileSync(full, 'utf8').split('\n');
    const s = start ? Math.max(1, start) : 1;
    const e = end ? Math.min(lines.length, end) : lines.length;
    const slice = lines.slice(s - 1, e);
    return {
      path: relative(root, full).replace(/\\/g, '/'),
      lineStart: s, lineEnd: e, totalLines: lines.length,
      content: slice.map((l, i) => `${s + i}\t${l}`).join('\n'),
    };
  }

  // Search file CONTENTS across the indexed set (bodies aren't in the db, so read live).
  function grep({ pattern, flags = 'i', dir = '', lang = null, maxHits = MAX_GREP_HITS } = {}) {
    if (!pattern?.trim()) throw new Error('grep: pattern is required');
    let re;
    try { re = new RegExp(pattern, flags.includes('g') ? flags : flags + 'g'); }
    catch (err) { throw new Error(`grep: bad regex /${pattern}/${flags}: ${err.message}`); }

    const { files } = list_files({ dir, lang, limit: MAX_GREP_FILES });
    const hits = [];
    let scanned = 0, truncated = false;
    for (const f of files) {
      if (hits.length >= maxHits) { truncated = true; break; }
      let text;
      try { text = readFileSync(jail(root, f.path), 'utf8'); } catch { continue; }
      if (text.includes(NUL)) continue; // skip binary
      scanned++;
      const fileLines = text.split('\n');
      for (let i = 0; i < fileLines.length; i++) {
        re.lastIndex = 0;
        if (re.test(fileLines[i])) {
          hits.push({ path: f.path, line: i + 1, text: fileLines[i].trim().slice(0, 240) });
          if (hits.length >= maxHits) { truncated = true; break; }
        }
      }
    }
    return { pattern, scanned, hits, truncated };
  }

  return {
    repo: repo.name, root,
    search_graph, neighbors, list_files, read_file, grep,
    close: () => db.close(),
  };
}

// Function-calling schemas for the local model (next step wires these into Ollama / the engine).
export const TOOL_SCHEMAS = [
  {
    type: 'function',
    function: {
      name: 'search_graph',
      description: 'Semantic search over the code knowledge graph. Returns matching code entities (classes, methods, endpoints, tables) by meaning — names/types/locations only, never source code.',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'Natural-language description of what to find.' },
          k: { type: 'integer', description: 'Max results (default 12).' },
          types: { type: 'array', items: { type: 'string' }, description: 'Filter to node types e.g. ["Method","ApiEndpoint"].' },
        },
        required: ['query'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'neighbors',
      description: 'Walk the graph one hop from a node id to see what it calls, imports, inherits, or is referenced by.',
      parameters: {
        type: 'object',
        properties: {
          id: { type: 'string', description: 'Node id from a prior search_graph result.' },
          rels: { type: 'array', items: { type: 'string' }, description: 'Filter relation types e.g. ["calls","references"].' },
          limit: { type: 'integer' },
        },
        required: ['id'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'list_files',
      description: 'List indexed files, optionally under a directory prefix or matching a substring/language.',
      parameters: {
        type: 'object',
        properties: {
          dir: { type: 'string', description: 'Repo-relative directory prefix.' },
          contains: { type: 'string', description: 'Substring the path must contain.' },
          lang: { type: 'string', description: 'Language tag e.g. "csharp","typescript".' },
          limit: { type: 'integer' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'read_file',
      description: 'Read a file from the local clone. Optional 1-based line range for large files. Output is line-numbered.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Repo-relative file path.' },
          start: { type: 'integer', description: '1-based start line.' },
          end: { type: 'integer', description: '1-based end line.' },
        },
        required: ['path'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'grep',
      description: 'Regex search across indexed file contents. Returns path + line number + matching line.',
      parameters: {
        type: 'object',
        properties: {
          pattern: { type: 'string', description: 'JS regular expression.' },
          flags: { type: 'string', description: 'Regex flags (default "i").' },
          dir: { type: 'string', description: 'Limit to a directory prefix.' },
          lang: { type: 'string', description: 'Limit to a language tag.' },
          maxHits: { type: 'integer' },
        },
        required: ['pattern'],
      },
    },
  },
];

// Smoke test: `node src/agent/tools.js`  (needs NODE_EXTRA_CA_CERTS for the first embed-model load)
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const repo = getActiveRepos()[0];
  if (!repo) throw new Error('No active repos in config/boards.json');
  const t = createAgentTools(repo);
  console.log(`\n[tools] repo=${t.repo} root=${t.root}\n`);

  console.log('# search_graph("update a hydrant inspection status")');
  const found = await t.search_graph({ query: 'update a hydrant inspection status', k: 6 });
  console.table(found.map((f) => ({ type: f.type, name: f.name, score: f.score, file: f.file })));

  if (found[0]) {
    console.log(`\n# neighbors(${found[0].id})`);
    console.table(t.neighbors({ id: found[0].id, limit: 8 }));
  }

  console.log('\n# list_files({ lang: "csharp", contains: "Controller" })');
  const ls = t.list_files({ lang: 'csharp', contains: 'Controller', limit: 8 });
  console.log(`total=${ls.total}`); console.table(ls.files);

  console.log('\n# grep({ pattern: "UpdateHydrant", lang: "csharp" })');
  const g = t.grep({ pattern: 'UpdateHydrant', lang: 'csharp', maxHits: 8 });
  console.log(`scanned=${g.scanned} hits=${g.hits.length} truncated=${g.truncated}`);
  console.table(g.hits);

  if (ls.files[0]) {
    console.log(`\n# read_file({ path: "${ls.files[0].path}", start: 1, end: 12 })`);
    console.log(t.read_file({ path: ls.files[0].path, start: 1, end: 12 }).content);
  }

  t.close();
  console.log('\n[tools] ok.');
}
