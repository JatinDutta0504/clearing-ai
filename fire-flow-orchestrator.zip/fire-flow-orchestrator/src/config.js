import 'dotenv/config';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
export const ROOT = resolve(__dirname, '..');

// Fail loud on missing secrets — no silent defaults.
function req(name) {
  const v = (process.env[name] || '').trim();
  if (!v) throw new Error(`Missing required env var: ${name} (set it in .env)`);
  return v;
}

function readJson(relPath) {
  const full = resolve(ROOT, relPath);
  try {
    return JSON.parse(readFileSync(full, 'utf8'));
  } catch (e) {
    throw new Error(`Failed to read/parse ${relPath}: ${e.message}`);
  }
}

// Atlassian Cloud is always https; normalize if the scheme was omitted.
export function jiraEnv() {
  let baseUrl = req('JIRA_BASE_URL').replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(baseUrl)) baseUrl = `https://${baseUrl}`;
  return { baseUrl, email: req('JIRA_EMAIL'), apiToken: req('JIRA_API_TOKEN') };
}

export function githubEnv() {
  return { pat: req('GITHUB_PAT') };
}

export const cronSchedule = () => (process.env.CRON_SCHEDULE || '*/15 * * * *').trim();

// Where a repo's knowledge-graph brain lives: data/kg/<repo-name>.db (one file per repo).
export const repoDbPath = (repoName) => resolve(ROOT, 'data', 'kg', `${repoName}.db`);

// One config file: boards + their repos + fetch settings.
export const loadConfig = () => readJson('config/boards.json');
export const getSettings = () => loadConfig().settings || {};

// AI/model settings (config/ai.json). Local-engine block is validated fail-loud.
export const loadAi = () => readJson('config/ai.json');
export function localEngine() {
  const l = loadAi().local || {};
  for (const k of ['host', 'model']) {
    if (!l[k]) throw new Error(`config/ai.json: local.${k} is required`);
  }
  return {
    host: l.host.replace(/\/+$/, ''),
    model: l.model,
    temperature: l.temperature ?? 0,
    numCtx: l.numCtx ?? 16384,
    maxIterations: l.maxIterations ?? 12,
    keepAlive: l.keepAlive ?? '30m', // keep the model resident between calls (no unload->reload drops)
    // Qwen3 thinking toggle: false = no reasoning preamble (faster + cleaner tool calls).
    // Omitted from the request unless explicitly boolean (non-thinking models don't accept it).
    think: typeof l.think === 'boolean' ? l.think : undefined,
  };
}

// External planner (Azure AI Foundry, OpenAI-compatible). All connection values can live in .env
// (preferred — keeps Foundry config in one place): AZURE_AI_ENDPOINT, AZURE_AI_MODEL,
// AZURE_AI_API_VERSION, AZURE_AI_KEY. config/ai.json supplies the defaults/tuning (temperature,
// maxOutputTokens, maxCalls) and is the fallback for endpoint/model if the env var is unset.
// Fail-loud — an unset/placeholder endpoint or model, or a missing key, throws.
export function externalEngine() {
  const e = loadAi().external || {};
  const env = (name) => (process.env[name] || '').trim();
  // .env wins; fall back to config/ai.json.
  const endpoint = env('AZURE_AI_ENDPOINT') || e.endpoint || '';
  const model = env('AZURE_AI_MODEL') || e.model || '';
  for (const [k, v] of [['endpoint', endpoint], ['model', model]]) {
    if (!v) throw new Error(`external.${k} is required — set AZURE_AI_${k.toUpperCase()} in .env (or external.${k} in config/ai.json)`);
    if (v.includes('REPLACE-ME')) throw new Error(`external.${k} is still a placeholder — set AZURE_AI_${k.toUpperCase()} in .env (or external.${k} in config/ai.json)`);
  }
  return {
    endpoint: endpoint.replace(/\/+$/, ''),
    apiVersion: env('AZURE_AI_API_VERSION') || e.apiVersion || '2024-05-01-preview',
    model,
    temperature: e.temperature ?? 0.2,
    maxOutputTokens: e.maxOutputTokens ?? 4096,
    maxCalls: e.maxCalls ?? 10,
    apiKey: req('AZURE_AI_KEY'),
  };
}
export const getActiveBoards = () => (loadConfig().boards || []).filter((b) => b.active);

// Flat list of repos across active boards; each repo carries its board for traceability.
export function getActiveRepos() {
  return getActiveBoards().flatMap((b) =>
    (b.repos || []).map((r) => ({ ...r, board: b.name, boardId: b.boardId }))
  );
}
