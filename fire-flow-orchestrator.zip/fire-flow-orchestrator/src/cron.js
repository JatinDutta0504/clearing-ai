import { fileURLToPath } from 'node:url';
import cron from 'node-cron';
import { cronSchedule } from './config.js';
import { runFlow } from './flow.js';

// ── CRON ENTRY ──────────────────────────────────────────────────────────────────────────────────
// Schedule the full flow on CRON_SCHEDULE with an OVERLAP GUARD. A single pass (clone/pull + KG +
// the CPU-bound local<->external loop across several tickets) can take far longer than the interval,
// so we must never start a new pass while one is still running — we just skip that tick.

let running = false;

async function tick(trigger, keepRepo) {
  if (running) {
    console.log(`[cron] ${trigger}: previous pass still running — skipping this tick`);
    return;
  }
  running = true;
  const startedAt = new Date().toISOString();
  console.log(`\n[cron] ${trigger} pass started ${startedAt}`);
  try {
    await runFlow({ onStep: (m) => console.log(m), keepRepo });
  } catch (e) {
    console.error(`[cron] pass crashed: ${e.message}`); // never let one bad pass kill the scheduler
  } finally {
    running = false;
    console.log(`[cron] pass finished (started ${startedAt})`);
  }
}

// Run: `node src/cron.js [--now]`  (also: `npm run cron`)
//   --now : also run one pass immediately on startup (otherwise the first pass is at the next tick).
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const schedule = cronSchedule();
  if (!cron.validate(schedule)) {
    throw new Error(`Invalid CRON_SCHEDULE "${schedule}" — use a cron expression like "*/5 * * * *"`);
  }
  const runNow = process.argv.includes('--now');
  const keepRepo = process.argv.includes('--keep-repo');
  console.log(`[cron] scheduled "${schedule}" (overlap-guarded${keepRepo ? ', clones kept' : ', clones removed when a board clears'}).`);
  console.log(`[cron] ${runNow ? 'running one pass now, then on schedule.' : 'first pass at the next interval.'}`);
  console.log('[cron] press Ctrl+C to stop.');
  cron.schedule(schedule, () => tick('scheduled', keepRepo));
  if (runNow) tick('startup --now', keepRepo);
}
