import { mkdirSync, appendFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ROOT } from '../config.js';
import { callExternalRaw } from '../llm/external.js';
import { inspectEgress } from '../security/egressGuard.js';

// ── EGRESS CLIENT ────────────────────────────────────────────────────────────────────────────
// The ONE place a message is allowed to cross from Zone A to Zone B. It runs the egress guard on
// EVERY outbound message (fail-closed: one blocked message aborts the whole send — nothing leaks),
// writes a content-free audit record, then calls the external planner. The audit log records counts
// + verdicts only, never the message text, so the log itself can't leak what it's protecting.

const AUDIT_PATH = resolve(ROOT, 'logs', 'egress-audit.jsonl');

function audit(entry) {
  mkdirSync(resolve(ROOT, 'logs'), { recursive: true });
  appendFileSync(AUDIT_PATH, JSON.stringify(entry) + '\n');
}

const contentOf = (m) => (typeof m.content === 'string' ? m.content : JSON.stringify(m.content ?? ''));

/**
 * Guard every message, audit, then send to the external planner.
 * Throws (and sends nothing) if ANY message fails the egress guard.
 * Returns { content, usage, model } from the planner.
 */
export async function sendToExternal(messages, { ticket = null, round = null, policy = {} } = {}) {
  const ts = () => new Date().toISOString();
  const perMsg = [];

  for (const m of messages) {
    const v = inspectEgress(contentOf(m), policy);
    perMsg.push({ role: m.role, ...v.stats, allowed: v.allowed, violations: v.violations.map((x) => x.check) });
    if (!v.allowed) {
      audit({ ts: ts(), ticket, round, event: 'BLOCKED', role: m.role, violations: v.violations.map((x) => x.check), stats: v.stats });
      const err = new Error(`egress blocked (fail-closed) on ${m.role} message: ${v.violations.map((x) => x.check).join(', ')}`);
      err.verdict = v;
      throw err;
    }
  }

  audit({ ts: ts(), ticket, round, event: 'SEND', msgCount: messages.length, perMsg });
  const out = await callExternalRaw(messages);
  audit({ ts: ts(), ticket, round, event: 'REPLY', chars: out.content.length, usage: out.usage });
  return out;
}

// Self-test: `node src/external/egressClient.js`
// Proves the guard fires BEFORE any HTTP: a code-bearing message is blocked with no network call;
// a clean message passes the guard and only then fails reaching the (unconfigured) planner.
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const dirty = [
    { role: 'system', content: 'You are a planner.' },
    { role: 'user', content: 'public async Task<ActionResult> UpdateHydrant(Guid id) {\n  await _h.HandleAsync(BuildUpdateHydrantCommand(id));\n  return NoContent();\n}' },
  ];
  const clean = [
    { role: 'system', content: 'You are a planner. Ask the local librarian for what you need.' },
    { role: 'user', content: 'Ticket HYD-1583: allow editing a hydrant inspection status. Relevant: UpdateHydrant in HydrantsController.cs, validated by VerifyUnmodifiedCondition.' },
  ];

  console.log('# dirty payload (expect: egress BLOCKED, no HTTP)');
  try { await sendToExternal(dirty, { ticket: 'TEST', round: 1 }); console.log('  FAIL — should have blocked'); }
  catch (e) { console.log(`  blocked as expected -> ${e.message}`); }

  console.log('\n# clean payload (expect: guard PASSES, then a config/network error reaching Foundry)');
  try { await sendToExternal(clean, { ticket: 'TEST', round: 1 }); console.log('  reached planner (unexpected without creds)'); }
  catch (e) { console.log(`  guard passed; client error -> ${e.message}`); }

  console.log(`\n[egressClient] audit log: ${AUDIT_PATH}`);
}
