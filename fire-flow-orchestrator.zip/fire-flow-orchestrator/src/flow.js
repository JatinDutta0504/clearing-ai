import { fileURLToPath } from 'node:url';
import { JiraClient, adfToText } from './jira.js';
import { fetchRepo, removeRepo } from './github.js';
import { runKg } from './kg/index.js';
import { planTicket } from './agent/loop.js';
import { getActiveBoards, getSettings } from './config.js';

// ── THE PRODUCTION FLOW (one full pass) ─────────────────────────────────────────────────────────
// For each active board:
//   1. build the QUEUE = tickets on that board carrying the requiredLabel ("Ready-For-AI").
//      If the queue is empty, skip the board entirely — no repo pull, no KG work for nothing.
//   2. only THEN fetch/pull the repo and build/refresh its brain (runKg skips if current).
//   3. drain the queue one ticket at a time (each isolated — one failure never stops the rest):
//        a. fetch the FULL ticket live (summary + description) — never stored in the brain.
//        b. planTicket() runs the local<->external loop -> output/KEY-plan.md.
//        c. write back IN COMMIT ORDER: attach plan -> comment -> flip label LAST. The label flip is
//           the commit point: if any earlier step throws, the ticket keeps "Ready-For-AI" and is
//           retried next pass (idempotent). Status is NEVER changed — only the label.
// This is exactly what the cron entry (src/cron.js) calls on every tick.

// The queue for one board: tickets carrying the required label, scoped server-side to the board.
async function fetchQueue(jira, board, label) {
  const { issues } = await jira.getBoardIssues(board.boardId, {
    fields: ['summary', 'status', 'labels'],
    maxResults: 100,
    jql: `labels = "${label}"`,
  });
  return issues;
}

// Keep a summary a glance: cap at 20 lines (room for the structured bullets) with a char backstop.
function capSummary(text) {
  let s = String(text || '').trim();
  const lines = s.split('\n');
  if (lines.length > 20) s = lines.slice(0, 20).join('\n').trimEnd() + '\n…';
  if (s.length > 2000) s = s.slice(0, 2000).trimEnd() + ' …';
  return s;
}

// FALLBACK summary (used only if the planner's dedicated summary call failed): extract the title's
// TL;DR line (the fix) + the "Short answer" section (the issue) from the generated plan markdown.
function planSummary(plan) {
  const text = String(plan || '');
  const titleDesc = (text.match(/^#\s+.*\r?\n+([\s\S]*?)\r?\n##\s/) || [])[1]?.trim() || '';
  const shortAns = (text.match(/##\s*Short answer[^\n]*\r?\n+([\s\S]*?)(?:\r?\n##\s|$)/i) || [])[1]?.trim() || '';
  return capSummary([titleDesc, shortAns].filter(Boolean).join('\n\n'));
}

/**
 * Run one full pass over all active boards. Returns a counts summary.
 * `onStep(msg)` receives human-readable progress lines (defaults to console.log).
 */
export async function runFlow({ onStep = null, keepRepo = false } = {}) {
  const step = (m) => (onStep ? onStep(m) : console.log(m));
  const boards = getActiveBoards();
  if (boards.length === 0) throw new Error('No active boards in config/boards.json');

  const settings = getSettings();
  const requiredLabel = settings.requiredLabel || 'Ready-For-AI';
  const doneLabel = settings.doneLabel || 'AI-Analysis-Done';
  const jira = new JiraClient();
  const totals = { queued: 0, planned: 0, failed: 0 };

  for (const board of boards) {
    const repos = board.repos || [];
    if (repos.length === 0) {
      step(`[flow] board "${board.name}": no repos configured — skip`);
      continue;
    }

    // 1. Build the queue FIRST — cheap. If nothing is labeled, do no repo/KG work at all.
    const queue = await fetchQueue(jira, board, requiredLabel);
    totals.queued += queue.length;
    step(`[flow] board "${board.name}" (${board.boardId}): ${queue.length} "${requiredLabel}" ticket(s) queued`);
    if (queue.length === 0) {
      step(`[flow] board "${board.name}": nothing to do — skip repo pull + KG`);
      continue;
    }

    // 2. There's work — NOW get every repo on disk + brain current.
    for (const repo of repos) {
      const r = { ...repo, board: board.name, boardId: board.boardId };
      step(`[flow] repo "${repo.name}" — fetch/pull...`);
      const fetched = await fetchRepo(r);
      step(`[flow] repo "${repo.name}" — ${fetched.action} (${fetched.branch})`);
      step(`[flow] repo "${repo.name}" — knowledge graph...`);
      const kg = await runKg(r, { onStep: (m) => step(`    kg: ${m}`) });
      step(`[flow] repo "${repo.name}" — brain ${kg.status} @ ${kg.head.slice(0, 8)} (${kg.reason})`);
    }
    // Planning runs against the board's first repo (one repo per board today).
    const planRepo = { ...repos[0], board: board.name, boardId: board.boardId };
    if (repos.length > 1) step(`[flow] note: board has ${repos.length} repos — planning against "${planRepo.name}"`);

    // 3. Drain the queue, one ticket at a time.
    let boardFailed = 0;
    for (const item of queue) {
      const key = item.key;
      try {
        step(`\n[flow] ── ${key} : ${(item.summary || '').slice(0, 70)} ─────────────`);

        // 3a. Live full ticket (summary + flattened ADF description).
        const raw = await jira.getIssue(key, '*all');
        const ticket = {
          key: raw.key || key,
          summary: raw.fields?.summary || item.summary || '',
          description: adfToText(raw.fields?.description).trim(),
        };

        // 3b. Two-LLM loop -> output/KEY-plan.md.
        const res = await planTicket(planRepo, ticket, {
          onEvent: (e) => step(`    [${e.phase}${e.round ? ' r' + e.round : ''}] ${e.msg || e.action || ''}`),
        });

        if (res.status !== 'planned' || !res.path) {
          totals.failed++;
          boardFailed++;
          step(`[flow] ${key}: ${res.status} after ${res.calls} call(s) — keeping "${requiredLabel}" for retry`);
          continue;
        }

        // 3c. Write back. Attach + comment first; flip the label LAST (the commit point).
        step(`[flow] ${key}: attaching ${res.path} ...`);
        await jira.addAttachment(key, res.path);
        // Prefer the planner's dedicated, well-written summary; fall back to extraction if it failed.
        const summary = res.summary?.trim() ? capSummary(res.summary) : planSummary(res.plan);
        await jira.addComment(
          key,
          `AI analysis done — the implementation plan is attached (${key}-plan.md).`
          + (summary ? `\n\nSummary\n${summary}` : '')
        );
        await jira.setLabels(key, { remove: requiredLabel, add: doneLabel });
        totals.planned++;
        step(`[flow] ${key}: DONE — plan attached + commented, label "${requiredLabel}" -> "${doneLabel}"`);
      } catch (e) {
        totals.failed++;
        boardFailed++;
        step(`[flow] ${key}: ERROR — ${e.message} (label left as "${requiredLabel}" for retry)`);
      }
    }

    // 4. Board fully cleared (every queued ticket planned, nothing left labeled)? The clone is now
    //    dead weight — remove it to free disk. Keep the brain (cheap re-index later). If anything
    //    failed, its label is still "Ready-For-AI", so we KEEP the clone for next pass's retry.
    if (keepRepo) {
      step(`[flow] board "${board.name}": --keep-repo set — leaving clone(s) on disk`);
    } else if (boardFailed > 0) {
      step(`[flow] board "${board.name}": ${boardFailed} ticket(s) still "${requiredLabel}" — keeping clone for retry`);
    } else {
      for (const repo of repos) {
        const r = await removeRepo({ ...repo, board: board.name, boardId: board.boardId });
        step(`[flow] board "${board.name}": all clear — clone ${r.action} (${repo.name}); brain kept`);
      }
    }
  }

  step(`\n[flow] pass complete: queued=${totals.queued} planned=${totals.planned} failed=${totals.failed}`);
  return totals;
}

// Run one full pass directly: `node src/flow.js [--keep-repo]`  (also: `npm run flow`)
//   --keep-repo : don't delete the clone after a board is fully cleared (default removes it).
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  await runFlow({ keepRepo: process.argv.includes('--keep-repo') });
  console.log('\n[flow] done.');
}
