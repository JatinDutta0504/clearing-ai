import { existsSync, rmSync } from 'node:fs';
import { resolve } from 'node:path';
import { simpleGit } from 'simple-git';
import { githubEnv, ROOT } from './config.js';
import { scrub } from './security/redact.js';

// Inject the PAT into the clone URL without exposing it in logs.
function authUrl(repoUrl, pat) {
  const u = new URL(repoUrl);
  u.username = pat; // URL setter percent-encodes for us
  u.password = 'x-oauth-basic';
  return u.toString();
}

/**
 * Get a repo onto the right branch:
 *  - already on disk -> fetch + checkout + pull (uses the repo's own origin; no PAT needed)
 *  - not on disk     -> clone from `url` using the GitHub PAT
 * Returns { name, action: 'pulled' | 'cloned', path, branch }.
 */
export async function fetchRepo(repo) {
  const { name, url, branch = 'main', localPath } = repo;
  if (!localPath) throw new Error(`repo "${name || '?'}" needs "localPath"`);

  const dest = resolve(ROOT, localPath);
  let pat;
  try {
    if (existsSync(dest)) {
      const git = simpleGit(dest);
      if (!(await git.checkIsRepo())) {
        throw new Error(`${localPath} exists but is not a git repository`);
      }
      await git.fetch();
      await git.checkout(branch);
      await git.pull('origin', branch);
      return { name, action: 'pulled', path: dest, branch };
    }

    if (!url) {
      throw new Error(`repo "${name}" not found at ${localPath} and has no "url" to clone from`);
    }
    pat = githubEnv().pat; // PAT only needed for a fresh clone
    const remote = authUrl(url, pat);
    await simpleGit().clone(remote, dest, ['--branch', branch, '--single-branch', '--depth', '1']);
    return { name, action: 'cloned', path: dest, branch };
  } catch (e) {
    throw new Error(`git operation failed for "${name}": ${scrub(e.message, pat)}`);
  }
}

/**
 * Delete a repo's local clone (the "territory"). The brain (data/kg/<name>.db) is NOT touched — it's
 * the cached artifact, so re-indexing later stays cheap. A missing clone is a no-op.
 * Returns { name, action: 'removed' | 'absent', path }.
 */
export function removeRepo(repo) {
  const { name, localPath } = repo;
  if (!localPath) throw new Error(`repo "${name || '?'}" needs "localPath"`);
  const dest = resolve(ROOT, localPath);
  if (!existsSync(dest)) return { name, action: 'absent', path: dest };
  rmSync(dest, { recursive: true, force: true });
  return { name, action: 'removed', path: dest };
}
