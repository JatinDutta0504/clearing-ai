import { runOnce } from './job.js';
import { JiraClient } from './jira.js';
import { getSettings, getActiveBoards } from './config.js';

const args = process.argv.slice(2);
const has = (flag) => args.includes(flag);
const argVal = (flag) => {
  const i = args.indexOf(flag);
  return i >= 0 ? args[i + 1] : undefined;
};

async function main() {
  // Setup helper: discover board ids/keys to populate config/boards.json.
  if (has('--list-boards')) {
    const name = argVal('--list-boards');
    const boards = await new JiraClient().getBoards(name);
    console.log(`\n[Jira] Boards${name ? ` matching "${name}"` : ''}: ${boards.length}`);
    console.table(boards);
    return;
  }

  // Setup helper: peek at a board's issues (also grabs a real sampleIssueKey).
  if (has('--board-issues')) {
    const boardId = argVal('--board-issues');
    const { fields } = getSettings();
    const { total, issues } = await new JiraClient().getBoardIssues(boardId, {
      fields,
      maxResults: 5,
    });
    console.log(`\n[Jira] Board ${boardId} has ${total} issue(s); showing ${issues.length}:`);
    console.table(issues);
    return;
  }

  // Confirmation: which tickets on the active board carry the "Ready-For-AI" label?
  // Case-tolerant discovery JQL (Jira labels are case-sensitive) so we learn the EXACT label string.
  if (has('--ready')) {
    const board = getActiveBoards()[0];
    if (!board) throw new Error('No active board in config/boards.json');
    const variants = ['Ready-For-AI', 'Ready-for-AI', 'Ready-For-Ai', 'ready-for-ai', 'READY-FOR-AI', 'Ready-for-Ai'];
    const jql = `labels in (${[...new Set(variants)].map((v) => `"${v}"`).join(', ')})`;
    const { total, issues } = await new JiraClient().getBoardIssues(board.boardId, {
      fields: ['summary', 'status', 'labels'],
      maxResults: 100,
      jql,
    });
    console.log(`\n[Jira] Board ${board.boardId} — issues labeled Ready-For-AI: ${issues.length} (board total reported: ${total})`);
    console.table(issues.map((i) => ({ key: i.key, summary: (i.summary || '').slice(0, 60), status: i.status, labels: (i.labels || []).join(', ') })));
    return;
  }

  await runOnce({
    jiraOnly: has('--jira-only'),
    repoOnly: has('--repo-only'),
    issueKey: argVal('--issue'),
  });
  console.log('\nDone.');
}

main().catch((err) => {
  console.error('\nERROR:', err.message);
  process.exit(1);
});
