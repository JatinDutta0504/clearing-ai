import { readFileSync } from 'node:fs';
import { basename } from 'node:path';
import { jiraEnv } from './config.js';

// Flatten Jira's nested field objects into useful scalar values.
function pickField(name, fields) {
  const v = fields?.[name];
  switch (name) {
    case 'status':
    case 'priority':
    case 'issuetype':
      return v?.name ?? null;
    case 'assignee':
    case 'reporter':
      return v?.displayName ?? null;
    default:
      return v ?? null; // summary, labels, created, updated, ...
  }
}

// Output shape is driven by the requested `fields` list — nothing hardcoded.
function normalizeIssue(raw, fields) {
  const out = { id: raw.id, key: raw.key };
  for (const name of fields) out[name] = pickField(name, raw.fields);
  return out;
}

/**
 * Flatten a Jira ADF (Atlassian Document Format) node tree to plain text.
 * Jira Cloud v3 returns `description`/`comment` bodies as nested ADF JSON, not strings.
 * Handles the common nodes (paragraphs, headings, lists, code, breaks); descends into any other.
 * Returns '' for null/undefined; passes through a plain string unchanged.
 */
export function adfToText(node) {
  if (node == null) return '';
  if (typeof node === 'string') return node;
  if (node.type === 'text') return node.text || '';
  if (node.type === 'hardBreak') return '\n';
  if (node.type === 'rule') return '\n---\n';
  const kids = Array.isArray(node.content) ? node.content.map(adfToText).join('') : '';
  switch (node.type) {
    case 'paragraph':
    case 'heading':
    case 'codeBlock':
      return kids + '\n\n';
    case 'listItem':
      return '- ' + kids.trim() + '\n';
    default:
      return kids; // doc, bulletList/orderedList, blockquote, table, and unknown containers
  }
}

// Wrap plain text into a minimal ADF doc (Jira Cloud v3 comment bodies must be ADF, not strings).
// Each line becomes a paragraph; blank lines become empty paragraphs.
function textToAdf(text) {
  const lines = String(text ?? '').split('\n');
  return {
    type: 'doc',
    version: 1,
    content: lines.map((line) => ({
      type: 'paragraph',
      content: line ? [{ type: 'text', text: line }] : [],
    })),
  };
}

// `fields` may be an array of names, or "*all" to pull the entire ticket raw.
function fieldsParam(fields) {
  if (fields === '*all' || fields === 'all') return { param: '*all', full: true };
  return { param: fields.map(encodeURIComponent).join(','), full: false };
}

/**
 * Minimal Jira Cloud REST client (API v3 + Agile v1).
 * Auth: HTTP Basic with base64(email:apiToken).
 */
export class JiraClient {
  constructor(creds = jiraEnv()) {
    const { baseUrl, email, apiToken } = creds;
    this.baseUrl = baseUrl;
    this.authHeader =
      'Basic ' + Buffer.from(`${email}:${apiToken}`).toString('base64');
  }

  async #request(path) {
    const url = `${this.baseUrl}${path}`;
    let res;
    try {
      res = await fetch(url, {
        headers: { Authorization: this.authHeader, Accept: 'application/json' },
      });
    } catch (e) {
      throw new Error(`Jira network error for ${path}: ${e.message}`);
    }
    return this.#parse(res, `GET ${path}`);
  }

  // Shared response handler for both reads and writes: fail loud on non-2xx, parse JSON when present.
  async #parse(res, label) {
    const body = await res.text();
    if (!res.ok) {
      throw new Error(`Jira ${res.status} ${res.statusText} for ${label}: ${body || '(empty body)'}`);
    }
    if (!body) return null; // 204 No Content (e.g. label update) — nothing to parse
    try {
      return JSON.parse(body);
    } catch {
      throw new Error(`Jira returned non-JSON for ${label}: ${body.slice(0, 200)}`);
    }
  }

  // Mutating request (POST/PUT). `json` -> application/json body; `form` -> multipart (attachments,
  // needs the X-Atlassian-Token: no-check header; fetch sets the multipart boundary itself).
  async #mutate(method, path, { json, form } = {}) {
    const url = `${this.baseUrl}${path}`;
    const headers = { Authorization: this.authHeader, Accept: 'application/json' };
    let body;
    if (form) {
      headers['X-Atlassian-Token'] = 'no-check';
      body = form;
    } else if (json !== undefined) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(json);
    }
    let res;
    try {
      res = await fetch(url, { method, headers, body });
    } catch (e) {
      throw new Error(`Jira network error for ${method} ${path}: ${e.message}`);
    }
    return this.#parse(res, `${method} ${path}`);
  }

  /**
   * Fetch a single issue.
   * - fields = array  -> flattened subset (id, key, ...named fields)
   * - fields = "*all" -> the complete raw Jira issue object
   */
  async getIssue(key, fields = ['summary', 'status']) {
    if (!key) throw new Error('getIssue: issue key is required');
    const { param, full } = fieldsParam(fields);
    const data = await this.#request(
      `/rest/api/3/issue/${encodeURIComponent(key)}?fields=${param}`
    );
    return full ? data : normalizeIssue(data, fields);
  }

  /** List Agile boards, optionally filtered by (partial) name. */
  async getBoards(name) {
    const q = name ? `?name=${encodeURIComponent(name)}` : '';
    const data = await this.#request(`/rest/agile/1.0/board${q}`);
    return (data.values || []).map((b) => ({
      boardId: b.id,
      name: b.name,
      type: b.type,
      projectKey: b.location?.projectKey ?? null,
      projectName: b.location?.projectName ?? null,
    }));
  }

  /** Fetch issues on a board. Honors the same `fields` / "*all" contract. Optional `jql` filters
   *  server-side (e.g. by label). */
  async getBoardIssues(boardId, { fields = ['summary', 'status'], maxResults = 50, jql = null } = {}) {
    if (!boardId) throw new Error('getBoardIssues: boardId is required');
    const { param, full } = fieldsParam(fields);
    const q = jql ? `&jql=${encodeURIComponent(jql)}` : '';
    const data = await this.#request(
      `/rest/agile/1.0/board/${encodeURIComponent(boardId)}/issue` +
        `?maxResults=${encodeURIComponent(maxResults)}&fields=${param}${q}`
    );
    return {
      total: data.total,
      issues: (data.issues || []).map((it) => (full ? it : normalizeIssue(it, fields))),
    };
  }

  // ── WRITE METHODS (used by the production flow's write-back step) ────────────────────────────
  // These mutate the ticket: attach the plan, comment, flip the label. They NEVER touch status.

  /** Add a plain-text comment (wrapped as ADF). */
  async addComment(key, text) {
    if (!key) throw new Error('addComment: issue key is required');
    if (!text || !text.trim()) throw new Error('addComment: comment text is required');
    return this.#mutate('POST', `/rest/api/3/issue/${encodeURIComponent(key)}/comment`, {
      json: { body: textToAdf(text) },
    });
  }

  /** Attach a local file to an issue (multipart upload). Returns the created attachment metadata. */
  async addAttachment(key, filePath) {
    if (!key) throw new Error('addAttachment: issue key is required');
    if (!filePath) throw new Error('addAttachment: filePath is required');
    const buf = readFileSync(filePath); // throws loud if the plan file isn't there
    const form = new FormData();
    form.append('file', new Blob([buf]), basename(filePath));
    return this.#mutate('POST', `/rest/api/3/issue/${encodeURIComponent(key)}/attachments`, { form });
  }

  /**
   * Update ONLY the labels on an issue (add and/or remove). Uses the `update.labels` op array so it
   * touches nothing else — status, assignee, etc. are never sent. `add`/`remove` accept a string or
   * an array. Returns null (Jira replies 204 No Content).
   */
  async setLabels(key, { add = [], remove = [] } = {}) {
    if (!key) throw new Error('setLabels: issue key is required');
    const arr = (v) => (Array.isArray(v) ? v : v ? [v] : []);
    const ops = [
      ...arr(remove).map((l) => ({ remove: l })),
      ...arr(add).map((l) => ({ add: l })),
    ];
    if (ops.length === 0) return null;
    return this.#mutate('PUT', `/rest/api/3/issue/${encodeURIComponent(key)}`, {
      json: { update: { labels: ops } },
    });
  }
}
