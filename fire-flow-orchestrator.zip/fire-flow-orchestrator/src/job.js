import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { JiraClient } from './jira.js';
import { fetchRepo } from './github.js';
import { getSettings, getActiveRepos, ROOT } from './config.js';

const isFullFields = (fields) => fields === '*all' || fields === 'all';

// Persist the complete raw ticket and print a readable summary of it.
function saveFullTicket(key, issue) {
  const dir = resolve(ROOT, 'output');
  mkdirSync(dir, { recursive: true });
  const file = resolve(dir, `${key}.json`);
  writeFileSync(file, JSON.stringify(issue, null, 2), 'utf8');

  const f = issue.fields || {};
  console.log(`\n[Jira] Full ticket saved -> ${file}`);
  console.table({
    key: issue.key,
    id: issue.id,
    summary: f.summary ?? null,
    status: f.status?.name ?? null,
    assignee: f.assignee?.displayName ?? null,
    priority: f.priority?.name ?? null,
    issuetype: f.issuetype?.name ?? null,
    created: f.created ?? null,
    updated: f.updated ?? null,
    comments: f.comment?.comments?.length ?? 0,
    attachments: Array.isArray(f.attachment) ? f.attachment.length : 0,
    totalFields: Object.keys(f).length,
  });
}

export async function runJira({ issueKey } = {}) {
  const { fields = ['summary', 'status'], sampleIssueKey } = getSettings();
  const key = issueKey || sampleIssueKey;
  if (!key) {
    throw new Error(
      'No issue key. Set settings.sampleIssueKey in config/boards.json or pass --issue KEY'
    );
  }

  const jira = new JiraClient();
  const issue = await jira.getIssue(key, fields);

  if (isFullFields(fields)) {
    saveFullTicket(issue.key || key, issue);
  } else {
    console.log('\n[Jira] Ticket fetched:');
    console.table([issue]);
  }
  return issue;
}

export async function runRepos() {
  const repos = getActiveRepos();
  if (repos.length === 0) {
    throw new Error('No repos found under any active board in config/boards.json');
  }

  const results = [];
  for (const repo of repos) {
    const branch = repo.branch || 'main';
    console.log(`\n[GitHub] (${repo.board}) fetching "${repo.name}" [${branch}] ...`);
    const result = await fetchRepo(repo);
    console.log(`[GitHub] ${result.action} -> ${result.path}`);
    results.push(result);
  }
  return results;
}

// One full pass. Phase 2's cron entry will import and schedule this.
export async function runOnce({ jiraOnly = false, repoOnly = false, issueKey } = {}) {
  if (!repoOnly) await runJira({ issueKey });
  if (!jiraOnly) await runRepos();
}
