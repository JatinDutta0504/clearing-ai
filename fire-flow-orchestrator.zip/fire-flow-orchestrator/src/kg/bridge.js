import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb } from './schema.js';
import { getParser, GRAMMAR } from './graph.js';
import { repoDbPath, getActiveRepos, ROOT } from '../config.js';

// Step 4e — connect the islands: frontend HTTP call → ApiEndpoint (whose controller method is
// already linked in 4d). Turns "frontend graph" + "backend graph" into one walkable chain.

const nameField = (n) => n.childForFieldName('name')?.text ?? null;
const HTTP_VERB = /^(get|post|put|delete|patch|head|options)$/i;
const CLASS_TYPES = new Set(['class_declaration', 'abstract_class_declaration', 'interface_declaration']);
const METHOD_TYPES = new Set(['method_definition', 'function_declaration', 'generator_function_declaration']);

// Nearest enclosing method name + class for a node (climb parents).
function enclosing(node) {
  let method = null, container = null, n = node.parent;
  while (n) {
    if (!method && METHOD_TYPES.has(n.type)) method = nameField(n);
    if (CLASS_TYPES.has(n.type)) { container = nameField(n); break; }
    n = n.parent;
  }
  return { method, container };
}

// Find `this.http.get('/url')`-style calls.
function collectHttpCalls(tree, path) {
  const calls = [];
  const stack = [tree.rootNode];
  while (stack.length) {
    const n = stack.pop();
    if (n.type === 'call_expression') {
      const fn = n.childForFieldName('function');
      if (fn?.type === 'member_expression') {
        const prop = fn.childForFieldName('property')?.text ?? '';
        const obj = fn.childForFieldName('object')?.text ?? '';
        if (HTTP_VERB.test(prop) && /http/i.test(obj)) {
          const url = n.childForFieldName('arguments')?.namedChildren?.[0]?.text ?? '';
          const { method, container } = enclosing(n);
          calls.push({ verb: prop.toUpperCase(), url, method, container, filePath: path });
        }
      }
    }
    for (const c of n.namedChildren) stack.push(c);
  }
  return calls;
}

const GENERIC = new Set(['api', 'v1', 'v2', 'v3', 'rest', 'app']);

// 'api/hydrants/${id}' → ['api','hydrants']  (keep all literal segments; drop interpolations + params)
function frontendSegs(url) {
  const s = url.replace(/\$\{[^}]*\}/g, '/').replace(/[`'"]/g, '');
  return s.split('/').map((x) => x.replace(/[+\s]/g, '')).filter(Boolean)
    .filter((x) => !x.includes(':') && !/^\{.*\}$/.test(x)).map((x) => x.toLowerCase());
}
// '/api/Hydrants/{id}' → ['api','hydrants']  (drop {param} segments)
const endpointSegs = (route) =>
  route.split('/').filter(Boolean).filter((x) => !/^\{.*\}$/.test(x)).map((x) => x.toLowerCase());

export async function buildBridge(repo) {
  const db = openDb(repoDbPath(repo.name), { repo: repo.name, branch: repo.branch });
  const repoRoot = resolve(ROOT, repo.localPath);

  // Index endpoints by verb → [{ id, segs }]
  const eps = db.prepare("SELECT id, json_extract(metadata,'$.method') verb, json_extract(metadata,'$.route') route FROM nodes WHERE type='ApiEndpoint'").all();
  const byVerb = new Map();
  for (const e of eps) {
    const segs = endpointSegs(e.route || '');
    if (!segs.length) continue;
    (byVerb.get(e.verb) ?? byVerb.set(e.verb, []).get(e.verb)).push({ id: e.id, segs });
  }

  // Best UNIQUE endpoint by segment overlap. Requires ≥1 shared non-generic (resource) segment;
  // ties (equally-good candidates) are skipped to stay precise.
  function matchEndpoint(verb, fsegs) {
    const fset = new Set(fsegs);
    const cands = (byVerb.get(verb) || [])
      .map((c) => {
        let inter = 0, sig = 0;
        for (const s of c.segs) if (fset.has(s)) { inter++; if (!GENERIC.has(s)) sig++; }
        return { id: c.id, inter, sig, elen: c.segs.length };
      })
      .filter((c) => c.sig >= 1);
    if (!cands.length) return null;
    const key = (c) => `${c.inter}|${Math.abs(c.elen - fsegs.length)}`;
    cands.sort((a, b) => b.inter - a.inter || Math.abs(a.elen - fsegs.length) - Math.abs(b.elen - fsegs.length));
    const top = cands[0];
    const ties = cands.filter((c) => key(c) === key(top));
    return ties.length === 1 ? top.id : null;
  }

  const tsFiles = db.prepare("SELECT path FROM files WHERE lang='typescript' ORDER BY path").all();
  const findMethod = db.prepare(
    "SELECT id FROM nodes WHERE type IN ('Method','Function') AND name=? AND json_extract(metadata,'$.filePath')=? LIMIT 1"
  );
  const upEdge = db.prepare(
    `INSERT INTO edges(source_id, target_id, relation_type, summary, metadata) VALUES(?, ?, 'calls', NULL, NULL)
     ON CONFLICT(source_id, target_id, relation_type) DO NOTHING`
  );

  let httpCalls = 0, matched = 0, edgesAdded = 0;
  const pending = [];
  for (const { path } of tsFiles) {
    let src; try { src = readFileSync(resolve(repoRoot, path), 'utf8'); } catch { continue; }
    const grammar = path.endsWith('.tsx') ? GRAMMAR.tsx : GRAMMAR.typescript;
    let tree; try { tree = (await getParser(grammar)).parse(src); } catch { continue; }
    for (const call of collectHttpCalls(tree, path)) {
      httpCalls++;
      const epId = matchEndpoint(call.verb, frontendSegs(call.url));
      if (!epId) continue;
      matched++;
      const src2 = call.method ? findMethod.get(call.method, path) : null;
      pending.push({ s: src2?.id ?? `file:${path}`, t: epId });
    }
    tree.delete?.();
  }

  db.transaction(() => { for (const e of pending) { if (upEdge.run(e.s, e.t).changes) edgesAdded++; } })();

  const callsEdges = db.prepare("SELECT count(*) c FROM edges WHERE relation_type='calls'").get().c;
  db.close();
  return { repo: repo.name, tsFiles: tsFiles.length, httpCalls, matched, edgesAdded, totalCallEdges: callsEdges };
}

// Debug: sample frontend URLs + endpoint routes so we can calibrate the matcher.
export async function debugSamples(repo) {
  const db = openDb(repoDbPath(repo.name), { repo: repo.name, branch: repo.branch });
  const repoRoot = resolve(ROOT, repo.localPath);
  const eps = db.prepare("SELECT json_extract(metadata,'$.method') verb, json_extract(metadata,'$.route') route FROM nodes WHERE type='ApiEndpoint' LIMIT 12").all();
  console.log('\n-- sample ENDPOINTS --');
  for (const e of eps) console.log(`  ${e.verb} ${e.route}   segs=[${endpointSegs(e.route || '')}]`);

  const tsFiles = db.prepare("SELECT path FROM files WHERE lang='typescript' ORDER BY path").all();
  console.log('\n-- sample FRONTEND http calls --');
  let shown = 0;
  for (const { path } of tsFiles) {
    if (shown >= 12) break;
    let src; try { src = readFileSync(resolve(repoRoot, path), 'utf8'); } catch { continue; }
    const grammar = path.endsWith('.tsx') ? GRAMMAR.tsx : GRAMMAR.typescript;
    let tree; try { tree = (await getParser(grammar)).parse(src); } catch { continue; }
    for (const call of collectHttpCalls(tree, path)) {
      if (shown >= 12) break;
      console.log(`  ${call.verb} ${JSON.stringify(call.url)}   segs=[${frontendSegs(call.url)}]`);
      shown++;
    }
    tree.delete?.();
  }
  db.close();
}

// Run directly: `node src/kg/bridge.js [debug]`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const repos = getActiveRepos();
  if (repos.length === 0) throw new Error('No active repos in config/boards.json');
  const debug = process.argv[2] === 'debug';
  for (const repo of repos) {
    if (debug) { await debugSamples(repo); continue; }
    const r = await buildBridge(repo);
    console.log(`\n[kg] ${r.repo}: HTTP calls found ${r.httpCalls} | matched to endpoints ${r.matched} | bridge edges added ${r.edgesAdded}`);
  }
  if (!debug) console.log('\n[kg] bridge (frontend → endpoint) done.');
}
