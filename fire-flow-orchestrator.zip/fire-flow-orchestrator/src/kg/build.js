import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { simpleGit } from 'simple-git';
import { openDb, setMeta } from './schema.js';
import { repoDbPath, getActiveRepos, ROOT } from '../config.js';

// Files we never index — their very paths/contents are sensitive.
// Exported so the agent tools share ONE denylist (the local LLM can't read these either).
export const SECRET_RE =
  /(^|\/)\.env(\.[^/]*)?$|\.(pem|key|pfx|p12|pkcs12|keystore|jks|crt)$|(^|\/)secrets?\//i;

// Map a file extension to a language tag (null = unknown/binary/other).
const LANG_BY_EXT = {
  cs: 'csharp', csproj: 'msbuild', sln: 'msbuild',
  ts: 'typescript', tsx: 'typescript', js: 'javascript', jsx: 'javascript', mjs: 'javascript',
  json: 'json', sql: 'sql', tf: 'terraform', tfvars: 'terraform',
  yaml: 'yaml', yml: 'yaml', md: 'markdown', html: 'html', htm: 'html',
  css: 'css', scss: 'scss', less: 'less', xml: 'xml', config: 'xml',
  sh: 'shell', ps1: 'powershell', bat: 'batch', dockerfile: 'docker',
};
const langOf = (p) => LANG_BY_EXT[(p.split('.').pop() || '').toLowerCase()] ?? null;

// Parse `git ls-tree -r --long <branch>` → [{ path, sha, size }] (blobs only).
function parseLsTree(raw) {
  const out = [];
  for (const line of raw.split('\n')) {
    const tab = line.indexOf('\t');
    if (tab < 0) continue;
    const meta = line.slice(0, tab).trim().split(/\s+/); // [mode, type, sha, size]
    if (meta[1] !== 'blob') continue; // skip trees/submodules
    out.push({ path: line.slice(tab + 1), sha: meta[2], size: Number(meta[3]) || 0 });
  }
  return out;
}

// Derive every ancestor folder path from a list of file paths.
function foldersOf(paths) {
  const set = new Set();
  for (const p of paths) {
    const segs = p.split('/');
    segs.pop(); // drop the filename
    let acc = '';
    for (const s of segs) {
      acc = acc ? `${acc}/${s}` : s;
      set.add(acc);
    }
  }
  return [...set];
}

const parentOf = (p) => (p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : null);
const nameOf = (p) => p.slice(p.lastIndexOf('/') + 1);

/**
 * Walk the repo's committed file tree (git, so .gitignore is honored automatically) and write
 * Repository / Folder / File nodes + the `files` bookkeeping rows. Paths + metadata only — no
 * file bodies. Idempotent: stable ids upsert on re-run.
 */
export async function buildFileTree(repo) {
  const dest = resolve(ROOT, repo.localPath);
  const branch = repo.branch || 'main';
  const git = simpleGit(dest);

  const head = (await git.revparse([branch])).trim();
  const all = parseLsTree(await git.raw(['ls-tree', '-r', '--long', branch]));
  const files = all.filter((f) => !SECRET_RE.test(f.path));
  const skippedSecrets = all.length - files.length;
  const folders = foldersOf(files.map((f) => f.path));

  const db = openDb(repoDbPath(repo.name), { repo: repo.name, branch });
  const upNode = db.prepare(
    `INSERT INTO nodes(id, type, name, summary, metadata) VALUES(?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET
       type = excluded.type, name = excluded.name, summary = excluded.summary, metadata = excluded.metadata`
  );
  const upFile = db.prepare(
    `INSERT INTO files(path, lang, blob_sha, size, node_id, indexed_at) VALUES(?, ?, ?, ?, ?, ?)
     ON CONFLICT(path) DO UPDATE SET
       lang = excluded.lang, blob_sha = excluded.blob_sha, size = excluded.size,
       node_id = excluded.node_id, indexed_at = excluded.indexed_at`
  );
  const now = new Date().toISOString();

  db.transaction(() => {
    upNode.run(`repo:${repo.name}`, 'Repository', repo.name,
      `Repository ${repo.name} (${branch})`, JSON.stringify({ branch, localPath: repo.localPath }));

    for (const dir of folders) {
      upNode.run(`folder:${dir}`, 'Folder', nameOf(dir), null,
        JSON.stringify({ path: dir, parent: parentOf(dir) }));
    }

    for (const f of files) {
      const id = `file:${f.path}`;
      const lang = langOf(f.path);
      upNode.run(id, 'File', nameOf(f.path), null,
        JSON.stringify({ path: f.path, parent: parentOf(f.path), lang, size: f.size }));
      upFile.run(f.path, lang, f.sha, f.size, id, now);
    }

    setMeta(db, 'last_indexed_commit', head);
  })();

  const c = (sql) => db.prepare(sql).get().c;
  const counts = {
    File: c("SELECT count(*) c FROM nodes WHERE type='File'"),
    Folder: c("SELECT count(*) c FROM nodes WHERE type='Folder'"),
    Repository: c("SELECT count(*) c FROM nodes WHERE type='Repository'"),
    fileRows: c('SELECT count(*) c FROM files'),
  };
  db.close();
  return { repo: repo.name, head, counts, tracked: all.length, indexed: files.length, skippedSecrets };
}

// Run directly: `node src/kg/build.js`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const repos = getActiveRepos();
  if (repos.length === 0) throw new Error('No active repos in config/boards.json');
  for (const repo of repos) {
    const r = await buildFileTree(repo);
    console.log(`\n[kg] ${r.repo} @ ${r.head.slice(0, 8)} -> ${repoDbPath(r.repo)}`);
    console.log(`[kg] tracked files: ${r.tracked} | indexed: ${r.indexed} | skipped (secrets): ${r.skippedSecrets}`);
    console.table(r.counts);
  }
  console.log('\n[kg] file tree done.');
}
