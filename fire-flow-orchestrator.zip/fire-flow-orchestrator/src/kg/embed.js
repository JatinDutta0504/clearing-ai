import { basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { pipeline } from '@huggingface/transformers';
import { openDb, setMeta, getMeta } from './schema.js';
import { repoDbPath, getActiveRepos } from '../config.js';

// Fixed, CPU-friendly embedding model (run locally via transformers.js). Lock it once —
// changing it requires a re-embed (the meta keys let us detect that later).
export const EMBED_MODEL = 'Xenova/all-MiniLM-L6-v2';
export const EMBED_DIM = 384;

// Turn an identifier into readable words so the embedder captures meaning:
// "UpdateHydrantStatus" → "Update Hydrant Status", "hydrant_service.ts" → "hydrant service ts"
function humanize(s) {
  if (!s) return '';
  return String(s)
    .replace(/[._\-/]+/g, ' ')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .replace(/\s+/g, ' ')
    .trim();
}

// The text we embed for a node = its meaning in words (name + type + context). NOT code bodies.
function embedText(node) {
  const m = node.metadata ? JSON.parse(node.metadata) : {};
  const parts = [node.type, humanize(node.name)];
  if (m.container) parts.push('in ' + humanize(m.container));
  if (m.kind && m.kind !== node.type.toLowerCase()) parts.push(`(${m.kind})`);
  if (m.route) parts.push(m.route);
  if (m.filePath) parts.push(`[${basename(m.filePath)}]`);
  return parts.join(' ');
}

const toBlob = (arr) => Buffer.from(new Float32Array(arr).buffer);

// Lazily-loaded extractor for embedding a single query string (same model = same vector space).
let _queryExtractor = null;
export async function embedQuery(text) {
  if (!_queryExtractor) _queryExtractor = await pipeline('feature-extraction', EMBED_MODEL);
  const out = await _queryExtractor([text], { pooling: 'mean', normalize: true });
  return out.tolist()[0];
}

export async function embedAll(repo, { batch = 64, onlyMissing = false } = {}) {
  const db = openDb(repoDbPath(repo.name), { repo: repo.name, branch: repo.branch });
  const where = onlyMissing ? 'WHERE embedding IS NULL' : '';
  const nodes = db.prepare(`SELECT id, type, name, metadata FROM nodes ${where}`).all();
  const total = db.prepare('SELECT count(*) c FROM nodes').get().c;
  if (nodes.length === 0) { db.close(); return { total, embedded: 0, withVec: total, model: EMBED_MODEL, dim: EMBED_DIM }; }

  console.log(`[kg] loading model ${EMBED_MODEL} (first run downloads it)...`);
  const extractor = await pipeline('feature-extraction', EMBED_MODEL);
  const upd = db.prepare('UPDATE nodes SET embedding = ? WHERE id = ?');

  let done = 0;
  for (let i = 0; i < nodes.length; i += batch) {
    const chunk = nodes.slice(i, i + batch);
    const out = await extractor(chunk.map(embedText), { pooling: 'mean', normalize: true });
    const vecs = out.tolist();
    db.transaction(() => { for (let j = 0; j < chunk.length; j++) upd.run(toBlob(vecs[j]), chunk[j].id); })();
    done += chunk.length;
    process.stdout.write(`\r[kg] embedded ${done}/${nodes.length}   `);
  }
  process.stdout.write('\n');

  setMeta(db, 'embed_model', EMBED_MODEL);
  setMeta(db, 'embed_dim', EMBED_DIM);
  const withVec = db.prepare('SELECT count(*) c FROM nodes WHERE embedding IS NOT NULL').get().c;
  db.close();
  return { total, embedded: done, withVec, model: EMBED_MODEL, dim: EMBED_DIM };
}

// Run directly: `node src/kg/embed.js [--missing]`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const onlyMissing = process.argv.includes('--missing');
  const repos = getActiveRepos();
  if (repos.length === 0) throw new Error('No active repos in config/boards.json');
  for (const repo of repos) {
    const r = await embedAll(repo, { onlyMissing });
    console.log(`\n[kg] ${repo.name}: embedded ${r.embedded} nodes | with vectors: ${r.withVec}/${r.total} | model ${r.model} (${r.dim}d)`);
  }
  console.log('\n[kg] embeddings done.');
}
