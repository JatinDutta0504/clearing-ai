import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import Parser from 'web-tree-sitter';
import { openDb } from './schema.js';
import { repoDbPath, getActiveRepos, ROOT } from '../config.js';

const require = createRequire(import.meta.url);
const CORE_WASM = require.resolve('web-tree-sitter/tree-sitter.wasm');
export const GRAMMAR = {
  csharp: require.resolve('tree-sitter-wasms/out/tree-sitter-c_sharp.wasm'),
  typescript: require.resolve('tree-sitter-wasms/out/tree-sitter-typescript.wasm'),
  tsx: require.resolve('tree-sitter-wasms/out/tree-sitter-tsx.wasm'),
};

// ---------------- parser pool (one per grammar, lazy) ----------------
let _inited = false;
const _parsers = new Map();
export async function getParser(grammarPath) {
  if (!_inited) { await Parser.init({ locateFile: () => CORE_WASM }); _inited = true; }
  if (_parsers.has(grammarPath)) return _parsers.get(grammarPath);
  const p = new Parser();
  p.setLanguage(await Parser.Language.load(readFileSync(grammarPath)));
  _parsers.set(grammarPath, p);
  return p;
}

const nameField = (n) => n.childForFieldName('name')?.text ?? null;
const looksLikeInterface = (name, node) => node?.meta.kind === 'interface' || /^I[A-Z]/.test(name);

// ---------------- shared helpers ----------------
function dedupeIds(nodes) {
  const seen = new Map();
  for (const n of nodes) {
    const c = (seen.get(n.id) || 0) + 1;
    seen.set(n.id, c);
    if (c > 1) n.id = `${n.id}#${c}`;
  }
  return nodes;
}

function indexByName(all, types) {
  const set = new Set([].concat(types));
  const idx = new Map();
  for (const n of all) {
    if (!set.has(n.type)) continue;
    (idx.get(n.name) ?? idx.set(n.name, []).get(n.name)).push(n);
  }
  return idx;
}
const uniq = (idx, name) => { const m = idx.get(name); return m && m.length === 1 ? m[0] : null; };

// Resolve per-node relationship hints (.bases / .inherits / .implements / .calls) into edges,
// keeping ONLY unambiguous, repo-internal targets (precision over recall).
function resolveEdges(all) {
  const classIdx = indexByName(all, 'Class');
  const callIdx = indexByName(all, ['Method', 'Function']);
  const edges = [];
  const link = (s, t, rel) => { if (t && t.id !== s.id) edges.push({ s: s.id, t: t.id, rel }); };
  for (const n of all) {
    for (const b of n.bases || []) {           // C#: base_list, classify by heuristic
      const t = uniq(classIdx, b);
      if (t) link(n, t, looksLikeInterface(b, t) ? 'implements' : 'inherits');
    }
    for (const b of n.inherits || []) link(n, uniq(classIdx, b), 'inherits');     // TS explicit
    for (const b of n.implements || []) link(n, uniq(classIdx, b), 'implements'); // TS explicit
    for (const c of n.calls || []) link(n, uniq(callIdx, c), 'calls');
  }
  return edges;
}

// ---------------- C# extractor ----------------
const CS_TYPE_DECLS = new Set(['class_declaration', 'interface_declaration', 'struct_declaration', 'record_declaration', 'record_struct_declaration', 'enum_declaration']);
const CS_METHOD_DECLS = new Set(['method_declaration', 'constructor_declaration', 'destructor_declaration', 'operator_declaration']);

function csTypeName(node) {
  if (!node) return null;
  if (node.type === 'identifier') return node.text;
  if (node.type === 'generic_name') return nameField(node) ?? node.text.replace(/<.*$/s, '');
  if (node.type === 'qualified_name') return csTypeName(node.namedChildren.at(-1));
  return null;
}
const csBaseNames = (t) => (t.namedChildren.find((c) => c.type === 'base_list')?.namedChildren ?? []).map(csTypeName).filter(Boolean);

function calledNameGeneric(inv, propField) {
  const fn = inv.childForFieldName('function') ?? inv.namedChildren[0];
  if (!fn) return null;
  if (fn.type === 'identifier') return fn.text;
  if (fn.type === 'member_access_expression' || fn.type === 'member_expression') return fn.childForFieldName(propField)?.text ?? null;
  return null;
}
function scanCalls(node, callType, propField) {
  const names = new Set(), stack = [node];
  while (stack.length) {
    const n = stack.pop();
    for (const c of n.namedChildren) {
      if (c.type === callType) { const nm = calledNameGeneric(c, propField); if (nm) names.add(nm); }
      stack.push(c);
    }
  }
  return [...names];
}

function extractCSharp(tree, path) {
  const out = [];
  const walk = (node, stack) => {
    for (const child of node.namedChildren) {
      if (CS_TYPE_DECLS.has(child.type)) {
        const nm = nameField(child);
        if (!nm) { walk(child, stack); continue; }
        out.push({ id: `Class:${path}:${[...stack, nm].join('.')}`, type: 'Class', name: nm,
          meta: { kind: child.type.replace('_declaration', ''), filePath: path, startLine: child.startPosition.row + 1, endLine: child.endPosition.row + 1, container: stack.join('.') || null },
          bases: csBaseNames(child) });
        walk(child, [...stack, nm]);
      } else if (CS_METHOD_DECLS.has(child.type)) {
        const owner = stack.join('.') || '(global)';
        const nm = nameField(child) || (child.type === 'constructor_declaration' ? (stack.at(-1) || 'ctor') : null);
        if (!nm) { walk(child, stack); continue; }
        out.push({ id: `Method:${path}:${owner}.${nm}`, type: 'Method', name: nm,
          meta: { kind: child.type.replace('_declaration', ''), filePath: path, startLine: child.startPosition.row + 1, endLine: child.endPosition.row + 1, container: owner },
          calls: scanCalls(child, 'invocation_expression', 'name') });
        walk(child, stack);
      } else walk(child, stack);
    }
  };
  walk(tree.rootNode, []);
  return out;
}

// ---------------- TypeScript extractor ----------------
const TS_TYPE_DECLS = new Set(['class_declaration', 'abstract_class_declaration', 'interface_declaration', 'enum_declaration']);
const TS_METHOD_DECLS = new Set(['method_definition']);
const TS_FUNC_DECLS = new Set(['function_declaration', 'generator_function_declaration']);

function tsName(node) {
  if (!node) return null;
  if (node.type === 'identifier' || node.type === 'type_identifier' || node.type === 'property_identifier') return node.text;
  if (node.type === 'member_expression') return node.childForFieldName('property')?.text ?? null;
  if (node.type === 'generic_type') return tsName(node.childForFieldName('name') ?? node.namedChildren[0]);
  if (node.type === 'nested_type_identifier') return tsName(node.namedChildren.at(-1));
  return null;
}
function tsHeritage(classNode) {
  const inherits = [], implement = [];
  for (const h of classNode.namedChildren) {
    if (h.type === 'class_heritage') {
      for (const c of h.namedChildren) {
        const bucket = c.type === 'implements_clause' ? implement : c.type === 'extends_clause' ? inherits : null;
        if (bucket) for (const t of c.namedChildren) { const n = tsName(t); if (n) bucket.push(n); }
      }
    } else if (h.type === 'extends_type_clause') {
      for (const t of h.namedChildren) { const n = tsName(t); if (n) inherits.push(n); }
    }
  }
  return { inherits, implements: implement };
}

function extractTypeScript(tree, path) {
  const out = [];
  const walk = (node, stack) => {
    for (const child of node.namedChildren) {
      if (TS_TYPE_DECLS.has(child.type)) {
        const nm = nameField(child);
        if (!nm) { walk(child, stack); continue; }
        const h = tsHeritage(child);
        out.push({ id: `Class:${path}:${[...stack, nm].join('.')}`, type: 'Class', name: nm,
          meta: { kind: child.type.replace('_declaration', ''), filePath: path, startLine: child.startPosition.row + 1, endLine: child.endPosition.row + 1, container: stack.join('.') || null },
          inherits: h.inherits, implements: h.implements });
        walk(child, [...stack, nm]);
      } else if (TS_METHOD_DECLS.has(child.type)) {
        const owner = stack.join('.') || '(global)';
        const nm = nameField(child);
        if (!nm) { walk(child, stack); continue; }
        out.push({ id: `Method:${path}:${owner}.${nm}`, type: 'Method', name: nm,
          meta: { kind: 'method', filePath: path, startLine: child.startPosition.row + 1, endLine: child.endPosition.row + 1, container: owner },
          calls: scanCalls(child, 'call_expression', 'property') });
        walk(child, stack);
      } else if (TS_FUNC_DECLS.has(child.type)) {
        const nm = nameField(child);
        if (!nm) { walk(child, stack); continue; }
        out.push({ id: `Function:${path}:${nm}`, type: 'Function', name: nm,
          meta: { kind: 'function', filePath: path, startLine: child.startPosition.row + 1, endLine: child.endPosition.row + 1, container: stack.join('.') || null },
          calls: scanCalls(child, 'call_expression', 'property') });
        walk(child, stack);
      } else walk(child, stack);
    }
  };
  walk(tree.rootNode, []);
  return out;
}

// ---------------- language configs ----------------
const LANGS = {
  csharp: { langKey: 'csharp', grammarFor: () => GRAMMAR.csharp, extract: extractCSharp },
  typescript: { langKey: 'typescript', grammarFor: (p) => (p.endsWith('.tsx') ? GRAMMAR.tsx : GRAMMAR.typescript), extract: extractTypeScript },
};

// ---------------- driver ----------------
export async function buildLanguageGraph(repo, cfg) {
  const db = openDb(repoDbPath(repo.name), { repo: repo.name, branch: repo.branch });
  const files = db.prepare('SELECT path FROM files WHERE lang = ? ORDER BY path').all(cfg.langKey);
  const repoRoot = resolve(ROOT, repo.localPath);

  let parsed = 0, failed = 0;
  const all = [];
  for (const { path } of files) {
    let src;
    try { src = readFileSync(resolve(repoRoot, path), 'utf8'); } catch { failed++; continue; }
    try {
      const parser = await getParser(cfg.grammarFor(path));
      const tree = parser.parse(src);
      all.push(...dedupeIds(cfg.extract(tree, path)));
      tree.delete?.();
      parsed++;
    } catch { failed++; }
  }
  const edges = resolveEdges(all);

  const upNode = db.prepare(
    `INSERT INTO nodes(id, type, name, summary, metadata) VALUES(@id, @type, @name, NULL, @metadata)
     ON CONFLICT(id) DO UPDATE SET type = excluded.type, name = excluded.name, metadata = excluded.metadata`
  );
  const upEdge = db.prepare(
    `INSERT INTO edges(source_id, target_id, relation_type, summary, metadata) VALUES(?, ?, ?, NULL, NULL)
     ON CONFLICT(source_id, target_id, relation_type) DO NOTHING`
  );
  db.transaction(() => {
    for (const n of all) upNode.run({ id: n.id, type: n.type, name: n.name, metadata: JSON.stringify(n.meta) });
    for (const e of edges) upEdge.run(e.s, e.t, e.rel);
  })();

  const one = (sql, ...a) => db.prepare(sql).get(...a).c;
  const result = {
    lang: cfg.langKey, files: files.length, parsed, failed, extracted: all.length, edgesAdded: edges.length,
    totals: {
      Class: one("SELECT count(*) c FROM nodes WHERE type='Class'"),
      Method: one("SELECT count(*) c FROM nodes WHERE type='Method'"),
      Function: one("SELECT count(*) c FROM nodes WHERE type='Function'"),
      edges: one('SELECT count(*) c FROM edges'),
    },
  };
  db.close();
  return result;
}

// Back-compat: C#-only entry.
export const buildCodeGraph = (repo) => buildLanguageGraph(repo, LANGS.csharp);

// Full code graph for a repo: both languages, in order. Used by the runKg orchestrator.
export async function buildGraph(repo) {
  const results = [];
  for (const langKey of ['csharp', 'typescript']) {
    results.push(await buildLanguageGraph(repo, LANGS[langKey]));
  }
  return results;
}

// Run directly: `node src/kg/graph.js [csharp|typescript]`  (no arg = both)
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const which = process.argv[2];
  const toRun = which ? [which] : ['csharp', 'typescript'];
  const repos = getActiveRepos();
  if (repos.length === 0) throw new Error('No active repos in config/boards.json');
  for (const repo of repos) {
    let last;
    for (const langKey of toRun) {
      last = await buildLanguageGraph(repo, LANGS[langKey]);
      console.log(`\n[kg] ${repo.name} / ${last.lang}: ${last.parsed}/${last.files} files parsed (${last.failed} failed), ${last.extracted} decls, +${last.edgesAdded} edges`);
    }
    console.table(last.totals);
  }
  console.log('\n[kg] code graph done.');
}
