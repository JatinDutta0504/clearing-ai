import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { simpleGit } from 'simple-git';
import { openDb, getMeta, SCHEMA_VERSION } from './schema.js';
import { repoDbPath, getActiveRepos, ROOT } from '../config.js';
import { buildFileTree } from './build.js';
import { buildGraph } from './graph.js';
import { buildExtras } from './parse.js';
import { buildBridge } from './bridge.js';
import { embedAll } from './embed.js';

// ── KG ORCHESTRATOR + CHECKPOINT ──────────────────────────────────────────────────────────────
// Build a repo's knowledge-graph brain ONLY IF NEEDED. The brain (data/kg/<name>.db) persists, so
// re-running shouldn't redo the work when nothing changed. Decision:
//   no db            -> FULL build
//   schema changed   -> FULL rebuild (table shape differs)
//   commit unchanged -> SKIP (brain is already current)  ← the common case
//   new commits      -> REBUILD (idempotent upserts; embeddings only-missing so it's cheap)
// The current HEAD is read the SAME way build.js stamps `last_indexed_commit`, so the comparison
// is apples-to-apples. Pass { force:true } to always rebuild.

// Current committed HEAD of the repo's clone (matches build.js's stamp).
async function currentHead(repo) {
  const dest = resolve(ROOT, repo.localPath);
  const branch = repo.branch || 'main';
  return (await simpleGit(dest).revparse([branch])).trim();
}

// Read the brain's checkpoint state without building anything. Returns { exists, schemaVersion,
// lastCommit, embedModel } — handle always closed.
export function readCheckpoint(repo) {
  const dbPath = repoDbPath(repo.name);
  if (!existsSync(dbPath)) return { exists: false };
  const db = openDb(dbPath, { repo: repo.name, branch: repo.branch });
  try {
    return {
      exists: true,
      schemaVersion: getMeta(db, 'schema_version'),
      lastCommit: getMeta(db, 'last_indexed_commit'),
      embedModel: getMeta(db, 'embed_model'),
    };
  } finally {
    db.close();
  }
}

// Decide what to do WITHOUT side effects — handy for `kg:status` and tests.
export async function kgDecision(repo, { force = false } = {}) {
  const head = await currentHead(repo);
  const cp = readCheckpoint(repo);
  if (force) return { action: 'rebuild', reason: 'forced', head, cp };
  if (!cp.exists) return { action: 'build', reason: 'no-brain', head, cp };
  if (cp.schemaVersion !== String(SCHEMA_VERSION)) {
    return { action: 'rebuild', reason: `schema ${cp.schemaVersion}->${SCHEMA_VERSION}`, head, cp };
  }
  if (cp.lastCommit && cp.lastCommit === head) {
    return { action: 'skip', reason: 'up-to-date', head, cp };
  }
  return { action: 'rebuild', reason: `commit ${(cp.lastCommit || 'none').slice(0, 8)}->${head.slice(0, 8)}`, head, cp };
}

/**
 * Build the knowledge graph for `repo` if needed. Runs the full pipeline (file tree -> code graph ->
 * extras -> bridge -> embeddings) when building/rebuilding; does nothing when the brain is current.
 * Returns { repo, status:'skipped'|'built'|'rebuilt', head, reason }.
 */
export async function runKg(repo, { force = false, onStep = null } = {}) {
  const step = (m) => onStep && onStep(m);
  const d = await kgDecision(repo, { force });

  if (d.action === 'skip') {
    step(`brain current @ ${d.head.slice(0, 8)} — skip (${d.reason})`);
    return { repo: repo.name, status: 'skipped', head: d.head, reason: d.reason };
  }

  step(`${d.action} — ${d.reason}`);
  step('file tree...');                  await buildFileTree(repo);
  step('code graph (c#/ts)...');         await buildGraph(repo);
  step('extras (sql/tf/endpoints)...');  await buildExtras(repo);
  step('bridge (frontend<->api)...');    await buildBridge(repo);
  step('embeddings (only-missing)...');  await embedAll(repo, { onlyMissing: true });

  return { repo: repo.name, status: d.action === 'build' ? 'built' : 'rebuilt', head: d.head, reason: d.reason };
}

// Run directly: `node src/kg/index.js [--force] [--status]`
//   --status : print the checkpoint decision for every active repo, build nothing.
//   --force  : rebuild even if current.
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const force = process.argv.includes('--force');
  const statusOnly = process.argv.includes('--status');
  const repos = getActiveRepos();
  if (repos.length === 0) throw new Error('No active repos in config/boards.json');

  for (const repo of repos) {
    if (statusOnly) {
      const d = await kgDecision(repo, { force });
      console.log(`[kg] ${repo.name}: ${d.action.toUpperCase()} (${d.reason})`
        + ` | head ${d.head.slice(0, 8)}`
        + ` | indexed ${(d.cp.lastCommit || '-').slice(0, 8)}`
        + ` | schema ${d.cp.schemaVersion ?? '-'} | model ${d.cp.embedModel ?? '-'}`);
      continue;
    }
    console.log(`\n[kg] ${repo.name} — checking...`);
    const r = await runKg(repo, { force, onStep: (m) => console.log(`  ${m}`) });
    console.log(`[kg] ${repo.name}: ${r.status.toUpperCase()} @ ${r.head.slice(0, 8)} (${r.reason})`);
  }
  console.log('\n[kg] done.');
}
