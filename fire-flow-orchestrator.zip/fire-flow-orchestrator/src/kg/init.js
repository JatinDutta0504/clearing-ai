import { openDb, tableNames, getMeta, SCHEMA_VERSION } from './schema.js';
import { repoDbPath, getActiveRepos } from '../config.js';

// Step 1: create the lean repo.db (empty graph + bookkeeping tables) for each active repo,
// then print the tables so we can verify the foundation.
const repos = getActiveRepos();
if (repos.length === 0) {
  throw new Error('No active repos found under any active board in config/boards.json');
}

for (const repo of repos) {
  const dbPath = repoDbPath(repo.name);
  const db = openDb(dbPath, { repo: repo.name, branch: repo.branch });

  console.log(`\n[kg] ${repo.name} -> ${dbPath}`);
  console.log(`[kg] schema_version (stored / code): ${getMeta(db, 'schema_version')} / ${SCHEMA_VERSION}`);
  console.log(`[kg] repo / branch: ${getMeta(db, 'repo')} / ${getMeta(db, 'branch')}`);
  console.table(tableNames(db).map((name) => ({ table: name })));

  db.close();
}

console.log('\n[kg] init done.');
