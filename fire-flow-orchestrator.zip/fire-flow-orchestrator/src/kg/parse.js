import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb } from './schema.js';
import { getParser, GRAMMAR } from './graph.js';
import { repoDbPath, getActiveRepos, ROOT } from '../config.js';

// Our own parsers for what tree-sitter grammars here don't cover:
//   ApiEndpoint  ← C# controller [HttpX]/[Route] attributes
//   DatabaseTable ← SQL CREATE TABLE
//   Service/Module ← Terraform resource/module blocks

// ---------------- C# attribute helpers (tree-sitter) ----------------
const nameField = (n) => n.childForFieldName('name')?.text ?? null;
const HTTP = /^Http(Get|Post|Put|Delete|Patch|Head|Options)$/;

function attrString(attr) {
  const args = attr.namedChildren.find((x) => x.type === 'attribute_argument_list');
  if (!args) return null;
  const stack = [...args.namedChildren];
  while (stack.length) {
    const n = stack.shift();
    if (/string/.test(n.type)) return n.text.replace(/^@?\$?"/, '').replace(/"$/, '');
    stack.push(...n.namedChildren);
  }
  return null;
}
function attributesOf(node) {
  const out = [];
  for (const c of node.namedChildren) {
    if (c.type !== 'attribute_list') continue;
    for (const a of c.namedChildren) {
      if (a.type !== 'attribute') continue;
      out.push({ name: a.childForFieldName('name')?.text ?? a.namedChildren[0]?.text ?? '', node: a });
    }
  }
  return out;
}
const routeAttr = (attrs) => {
  const r = attrs.find((a) => /^Route(Prefix)?$/.test(a.name));
  return r ? attrString(r.node) : null;
};
const httpAttr = (attrs) => attrs.find((a) => HTTP.test(a.name));

function composeRoute(classRoute, methodRoute, controller, action) {
  const parts = [classRoute, methodRoute].filter((p) => p != null && p !== '');
  let route = parts.join('/');
  route = route
    .replace(/\[controller\]/gi, controller.replace(/Controller$/, ''))
    .replace(/\[action\]/gi, action)
    .replace(/\{[^}]+\}/g, (m) => m); // keep {id} params as-is
  route = '/' + route.replace(/^\/+/, '').replace(/\/{2,}/g, '/');
  return route.replace(/\/+$/, '') || '/';
}

function extractEndpoints(tree, path) {
  const eps = [];
  const walk = (node) => {
    for (const c of node.namedChildren) {
      if (c.type === 'class_declaration') {
        const cname = nameField(c);
        const cattrs = attributesOf(c);
        const isController = (cname && /Controller$/.test(cname)) || cattrs.some((a) => /ApiController|^Route$/.test(a.name));
        if (isController && cname) {
          const classRoute = routeAttr(cattrs);
          const body = c.childForFieldName('body') ?? c;
          for (const m of body.namedChildren) {
            if (m.type !== 'method_declaration') continue;
            const mattrs = attributesOf(m);
            const verbAttr = httpAttr(mattrs);
            if (!verbAttr) continue;
            const verb = verbAttr.name.replace(/^Http/, '').toUpperCase();
            const mroute = attrString(verbAttr.node) ?? routeAttr(mattrs);
            eps.push({
              verb, route: composeRoute(classRoute, mroute, cname, nameField(m) ?? ''),
              controller: cname, action: nameField(m), filePath: path, startLine: m.startPosition.row + 1,
            });
          }
        }
        walk(c);
      } else walk(c);
    }
  };
  walk(tree.rootNode);
  return eps;
}

// ---------------- regex extractors ----------------
const CREATE_TABLE = /\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:TRANSIENT\s+|TEMPORARY\s+|GLOBAL\s+|LOCAL\s+)*TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([A-Za-z0-9_."`[\]]+)/gi;
const TF_RESOURCE = /\bresource\s+"([^"]+)"\s+"([^"]+)"/g;
const TF_MODULE = /\bmodule\s+"([^"]+)"/g;

const cleanTable = (raw) => raw.replace(/[`"\[\]]/g, '').replace(/\.+$/, '');

// ---------------- driver ----------------
export async function buildExtras(repo) {
  const db = openDb(repoDbPath(repo.name), { repo: repo.name, branch: repo.branch });
  const repoRoot = resolve(ROOT, repo.localPath);
  const filesByLang = (lang) => db.prepare('SELECT path FROM files WHERE lang = ? ORDER BY path').all(lang);
  const read = (p) => { try { return readFileSync(resolve(repoRoot, p), 'utf8'); } catch { return null; } };

  const upNode = db.prepare(
    `INSERT INTO nodes(id, type, name, summary, metadata) VALUES(@id, @type, @name, NULL, @metadata)
     ON CONFLICT(id) DO UPDATE SET type = excluded.type, name = excluded.name, metadata = excluded.metadata`
  );
  const upEdge = db.prepare(
    `INSERT INTO edges(source_id, target_id, relation_type, summary, metadata) VALUES(?, ?, ?, NULL, NULL)
     ON CONFLICT(source_id, target_id, relation_type) DO NOTHING`
  );
  const findMethod = db.prepare(
    "SELECT id FROM nodes WHERE type='Method' AND name=? AND json_extract(metadata,'$.filePath')=? AND json_extract(metadata,'$.container')=? LIMIT 1"
  );

  // --- API endpoints (from controller .cs files) ---
  const controllerFiles = db.prepare(
    "SELECT path FROM files WHERE lang='csharp' AND lower(path) LIKE '%controller%'"
  ).all();
  const parser = await getParser(GRAMMAR.csharp);
  const endpoints = [];
  for (const { path } of controllerFiles) {
    const src = read(path);
    if (!src) continue;
    try { const t = parser.parse(src); endpoints.push(...extractEndpoints(t, path)); t.delete?.(); } catch { /* skip */ }
  }

  // --- DB tables (SQL) ---
  const tables = [];
  for (const { path } of filesByLang('sql')) {
    const src = read(path);
    if (!src) continue;
    for (const m of src.matchAll(CREATE_TABLE)) tables.push({ name: cleanTable(m[1]), filePath: path });
  }

  // --- Terraform resources/modules ---
  const infra = [];
  for (const { path } of filesByLang('terraform')) {
    const src = read(path);
    if (!src) continue;
    for (const m of src.matchAll(TF_RESOURCE)) infra.push({ type: 'Service', id: `service:${m[1]}.${m[2]}`, name: `${m[1]}.${m[2]}`, filePath: path });
    for (const m of src.matchAll(TF_MODULE)) infra.push({ type: 'Module', id: `module:${m[1]}`, name: m[1], filePath: path });
  }

  let endpointEdges = 0;
  db.transaction(() => {
    for (const e of endpoints) {
      const id = `api:${e.verb}:${e.route}`;
      upNode.run({ id, type: 'ApiEndpoint', name: `${e.verb} ${e.route}`,
        metadata: JSON.stringify({ method: e.verb, route: e.route, controller: e.controller, action: e.action, filePath: e.filePath, startLine: e.startLine }) });
      const m = e.action ? findMethod.get(e.action, e.filePath, e.controller) : null;
      if (m) { upEdge.run(id, m.id, 'references'); endpointEdges++; }
    }
    for (const t of tables) {
      if (!t.name) continue;
      upNode.run({ id: `table:${t.name}`, type: 'DatabaseTable', name: t.name, metadata: JSON.stringify({ filePath: t.filePath }) });
    }
    for (const i of infra) upNode.run({ id: i.id, type: i.type, name: i.name, metadata: JSON.stringify({ filePath: i.filePath }) });
  })();

  const one = (sql) => db.prepare(sql).get().c;
  const result = {
    controllerFiles: controllerFiles.length,
    counts: {
      ApiEndpoint: one("SELECT count(*) c FROM nodes WHERE type='ApiEndpoint'"),
      DatabaseTable: one("SELECT count(*) c FROM nodes WHERE type='DatabaseTable'"),
      Service: one("SELECT count(*) c FROM nodes WHERE type='Service'"),
      Module: one("SELECT count(*) c FROM nodes WHERE type='Module'"),
    },
    endpointEdges,
  };
  db.close();
  return result;
}

// Run directly: `node src/kg/parse.js`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const repos = getActiveRepos();
  if (repos.length === 0) throw new Error('No active repos in config/boards.json');
  for (const repo of repos) {
    const r = await buildExtras(repo);
    console.log(`\n[kg] ${repo.name}: scanned ${r.controllerFiles} controller files; endpoint→method edges: ${r.endpointEdges}`);
    console.table(r.counts);
  }
  console.log('\n[kg] extras (endpoints / tables / infra) done.');
}
