import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

// Bump when the table shape changes — a mismatch forces a rebuild later.
export const SCHEMA_VERSION = 1;

// The lean code-graph brain:
//   nodes + edges  = the graph (the MAP)
//   files + meta   = bookkeeping that keeps it fresh (incremental) and safe (staleness/model swap)
// No jira, no docs, no file bodies — those are fetched/read live. Vector tables (vec_*) are
// added later when we wire sqlite-vec; `embedding` columns hold a raw copy in the meantime.
const DDL = `
CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS files (
  path        TEXT PRIMARY KEY,   -- repo-relative, POSIX
  lang        TEXT,
  blob_sha    TEXT,               -- git blob sha -> incremental dirty-check
  size        INTEGER,
  node_id     TEXT,               -- -> nodes.id of this file's File node
  indexed_at  TEXT
);

CREATE TABLE IF NOT EXISTS nodes (
  id        TEXT PRIMARY KEY,     -- stable UID (e.g. file:<path>, Class:<path>:<Name>)
  type      TEXT NOT NULL,        -- File|Folder|Class|Function|Method|Service|Module|ApiEndpoint|DatabaseTable|Repository
  name      TEXT NOT NULL,
  summary   TEXT,
  metadata  TEXT,                 -- JSON
  embedding BLOB                  -- filled at the embeddings step
);
CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(type);
CREATE INDEX IF NOT EXISTS idx_nodes_name ON nodes(name);

CREATE TABLE IF NOT EXISTS edges (
  id            INTEGER PRIMARY KEY,
  source_id     TEXT NOT NULL,    -- -> nodes.id
  target_id     TEXT NOT NULL,    -- -> nodes.id
  relation_type TEXT NOT NULL,    -- calls|imports|depends_on|inherits|implements|modifies|references
  summary       TEXT,
  metadata      TEXT,
  embedding     BLOB
);
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(source_id, relation_type);
CREATE INDEX IF NOT EXISTS idx_edges_tgt ON edges(target_id, relation_type);
CREATE UNIQUE INDEX IF NOT EXISTS idx_edges_triple ON edges(source_id, target_id, relation_type);
`;

// Upsert a single meta key (used by openDb and later by the indexer).
export function setMeta(db, key, value) {
  db.prepare(
    'INSERT INTO meta(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
  ).run(key, String(value));
}

export function getMeta(db, key) {
  const row = db.prepare('SELECT value FROM meta WHERE key = ?').get(key);
  return row ? row.value : null;
}

// List the real (non-internal) tables — handy for verification.
export function tableNames(db) {
  return db
    .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    .all()
    .map((r) => r.name);
}

/**
 * Open (creating if missing) the repo.db at dbPath, ensure the schema + pragmas.
 * Returns the better-sqlite3 Database handle.
 */
export function openDb(dbPath, { repo, branch } = {}) {
  mkdirSync(dirname(dbPath), { recursive: true });
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(DDL);
  setMeta(db, 'schema_version', SCHEMA_VERSION);
  if (repo) setMeta(db, 'repo', repo);
  if (branch) setMeta(db, 'branch', branch);
  return db;
}
