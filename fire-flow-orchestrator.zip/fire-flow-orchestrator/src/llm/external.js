import { externalEngine } from '../config.js';

// ── EXTERNAL PLANNER CLIENT (Zone B) ─────────────────────────────────────────────────────────
// Azure AI Foundry, OpenAI-compatible chat/completions schema (model-agnostic behind Foundry).
// This module ONLY formats the request and sends it. It does NOT enforce egress — that is the job
// of egressClient.js, which is the single allowed caller. Never import this directly from the loop.
// Fail-loud: no silent fallback on network/credential errors.

export async function callExternalRaw(messages, { temperature, maxTokens } = {}) {
  const e = externalEngine();
  // Two Azure surfaces: the new v1 API (/openai/v1/...) is OpenAI-SDK compatible — path-versioned
  // (no ?api-version) and Bearer-authed. Classic Azure OpenAI uses ?api-version + the api-key header.
  const isV1 = /\/openai\/v1\//.test(e.endpoint);
  const url = isV1 || /[?&]api-version=/.test(e.endpoint)
    ? e.endpoint
    : `${e.endpoint}?api-version=${e.apiVersion}`;
  const headers = { 'content-type': 'application/json' };
  if (isV1) headers['authorization'] = `Bearer ${e.apiKey}`;
  else headers['api-key'] = e.apiKey;

  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: e.model,
        messages,
        temperature: temperature ?? e.temperature,
        max_tokens: maxTokens ?? e.maxOutputTokens,
      }),
    });
  } catch (err) {
    throw new Error(`cannot reach external planner at ${e.endpoint}: ${err.message}`);
  }
  if (!res.ok) throw new Error(`external planner ${res.status}: ${await res.text()}`);

  const j = await res.json();
  const content = j.choices?.[0]?.message?.content ?? '';
  if (!content) throw new Error('external planner returned an empty message');
  return { content, usage: j.usage ?? null, model: e.model };
}
