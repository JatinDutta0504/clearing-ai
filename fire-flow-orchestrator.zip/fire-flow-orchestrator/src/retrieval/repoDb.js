import { fileURLToPath } from 'node:url';
import { openDb } from '../kg/schema.js';
import { repoDbPath, getActiveRepos } from '../config.js';
import { embedQuery } from '../kg/embed.js';

// Read-only accessor over repo.db: vector (semantic) search + simple graph traversal.
// At our scale (~9k nodes) brute-force cosine in JS is sub-10ms; sqlite-vec is a future swap-in.

const decode = (buf) => new Float32Array(buf.buffer, buf.byteOffset, buf.byteLength / 4);
function dot(a, b) { let s = 0; for (let i = 0; i < a.length; i++) s += a[i] * b[i]; return s; } // cosine (vectors are normalized)

// Is this a TEST / test-support file? Catches JS/TS specs, C# *Tests.cs, lowercase test dirs, and
// .NET test PROJECT segments (Foo.UnitTests/, Foo.SystemTests/, Foo.Testing.Common/). Case-sensitive
// on the PascalCase forms so production words like "latest"/"greatest" don't false-match.
export function isTestPath(p) {
  if (!p) return false;
  if (/\.(?:spec|test)\.[tj]sx?$/i.test(p)) return true;                                  // a.spec.ts / a.test.tsx
  if (/Tests?\.cs$/.test(p)) return true;                                                 // FooTests.cs / FooTest.cs
  if (/(?:^|\/)(?:tests?|system-tests|ui-automation|e2e|cypress|__tests__)\//i.test(p)) return true; // test dirs
  if (/(?:^|[./])[A-Za-z]*Tests?(?=[./])/.test(p)) return true;                           // .NET *Tests/ project segment
  if (/(?:^|[./])Testing(?=[./])/.test(p)) return true;                                   // .NET *.Testing.* helper project
  return false;
}
// Does the QUERY itself ask about tests? Then we must NOT penalize test files.
const ABOUT_TESTS = /\b(tests?|spec|specs|unit[\s-]?test|coverage|jasmine|xunit|nunit|cypress)\b/i;
const TEST_PENALTY = 0.6; // multiply a test file's score by this for non-test queries -> they rank lower
const metaPath = (s) => { try { const m = JSON.parse(s || '{}'); return m.filePath || m.path || ''; } catch { return ''; } };

// Top-k nodes by semantic similarity to a query vector. Optional type filter. When `query` is given
// and is NOT about tests, test files are down-ranked so production code surfaces first.
export function searchByVector(db, qvec, { k = 20, types = null, query = '' } = {}) {
  let sql = 'SELECT id, type, name, metadata, embedding FROM nodes WHERE embedding IS NOT NULL';
  const params = [];
  if (types?.length) { sql += ` AND type IN (${types.map(() => '?').join(',')})`; params.push(...types); }
  const rows = db.prepare(sql).all(...params);
  const penalizeTests = Boolean(query) && !ABOUT_TESTS.test(query);
  const scored = rows.map((r) => {
    let score = dot(qvec, decode(r.embedding));
    if (penalizeTests && isTestPath(metaPath(r.metadata))) score *= TEST_PENALTY;
    return { id: r.id, type: r.type, name: r.name, metadata: r.metadata, score };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, k);
}

// Direct neighbors of a node (1 hop), optionally filtered by relation type.
export function neighbors(db, nodeId, { rels = null, limit = 50 } = {}) {
  let sql = `SELECT e.relation_type rel, n.id, n.type, n.name, e.source_id, e.target_id
             FROM edges e JOIN nodes n ON n.id = CASE WHEN e.source_id = ? THEN e.target_id ELSE e.source_id END
             WHERE (e.source_id = ? OR e.target_id = ?)`;
  const params = [nodeId, nodeId, nodeId];
  if (rels?.length) { sql += ` AND e.relation_type IN (${rels.map(() => '?').join(',')})`; params.push(...rels); }
  sql += ' LIMIT ?'; params.push(limit);
  return db.prepare(sql).all(...params);
}

// Convenience: embed the query text, then search.
export async function searchText(repo, text, opts = {}) {
  const db = openDb(repoDbPath(repo.name), { repo: repo.name, branch: repo.branch });
  const qvec = await embedQuery(text);
  const res = searchByVector(db, qvec, opts);
  db.close();
  return res;
}

// Run directly: `node src/retrieval/repoDb.js "your search query"`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const q = process.argv.slice(2).join(' ') || 'update hydrant status';
  const repo = getActiveRepos()[0];
  if (!repo) throw new Error('No active repos in config/boards.json');
  const res = await searchText(repo, q, { k: 12, types: ['Class', 'Method', 'Function', 'ApiEndpoint', 'DatabaseTable'] });
  console.log(`\nquery: "${q}"  (repo: ${repo.name})\n`);
  console.table(res.map((r) => ({ type: r.type, name: r.name, score: Number(r.score.toFixed(3)) })));
}
