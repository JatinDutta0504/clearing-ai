import { fileURLToPath } from 'node:url';
import { redactSecrets } from './redact.js';

// ── EGRESS GUARD ──────────────────────────────────────────────────────────────────────────────
// The fail-closed boundary between Zone A (local, trusted, sees code) and Zone B (external planner).
// Policy (revised): the planner is allowed MINIMAL SUFFICIENT CONTEXT — the few relevant snippets a
// senior engineer would paste into a design review. So bounded code is OK. What must NEVER cross:
//   1. SECRETS — always blocked, bounded or not.
//   2. WHOLESALE DUMPS — whole files / many files / minified blobs. Enforced by hard caps on total
//      size, total code-shaped lines, number of fenced blocks, and per-line length.
// It is a VALIDATOR, not a sanitizer: verdict is allow/block only. A block is NOT fatal in the loop —
// it signals "you tried to send too much; narrow it." Counts only in stats (audit-safe).

export const DEFAULT_POLICY = {
  maxMessageChars: 24000,  // prose + a few bounded snippets; bigger than this = file/repo dump -> block
  maxLineChars: 2000,      // a single line longer than this = minified/verbatim source dump -> block
  maxCodeBlocks: 8,        // more fenced blocks than this = dumping many files -> block
  maxCodeLines: 300,       // more code-shaped lines than this across the whole message = wholesale -> block
};

// SOFT signal: is this single line shaped like a line of code (vs a sentence)? Used only to MEASURE
// code VOLUME now (not to block a single line — bounded code is allowed).
function isCodeLikeLine(line) {
  const s = line.trim();
  if (!s) return false;
  if (s === '}' || s === '};' || s === '{' || s.endsWith(') {') || s.endsWith('){')) return true;
  if (/;\s*$/.test(s) && /[=(]/.test(s)) return true;          // statement ending in ; with a call/assign
  if (/=>/.test(s)) return true;                                // arrow
  if (/(?:==|!=|<=|>=|\+\+|--|\+=|-=|&&|\|\|)/.test(s)) return true; // operators rare in prose
  if (/^(?:if|for|while|switch|return|throw|var|let|const|public|private|protected|await|new)\b[\s(]/.test(s)) return true;
  return false;
}

/**
 * Inspect an outbound message. Returns { allowed, violations:[{check,detail}], stats }.
 * `stats` is safe to log (counts only — never the content). Pass a policy override to tune limits.
 */
export function inspectEgress(text, policy = {}) {
  const p = { ...DEFAULT_POLICY, ...policy };
  const violations = [];
  const msg = typeof text === 'string' ? text : '';

  // 1. size — a payload this large is a file/repo dump, not curated context
  if (msg.length > p.maxMessageChars) {
    violations.push({ check: 'oversize', detail: `${msg.length} chars > ${p.maxMessageChars}` });
  }

  // 2. secrets — ALWAYS blocked, bounded or not (re-scan at the boundary; block, never silent-redact)
  const { hits } = redactSecrets(msg);
  if (hits > 0) violations.push({ check: 'secret', detail: `${hits} secret-shaped token(s)` });

  // 3. code VOLUME — bounded relevant snippets are fine; wholesale dumps are not
  const lines = msg.split('\n');
  let codeLike = 0;
  let longLine = false;
  for (const ln of lines) {
    if (ln.length > p.maxLineChars) longLine = true;
    if (isCodeLikeLine(ln)) codeLike++;
  }
  const codeBlocks = Math.floor((msg.match(/(?:```|~~~)/g) || []).length / 2);
  if (longLine) violations.push({ check: 'long-line', detail: `line > ${p.maxLineChars} chars (minified/dumped)` });
  if (codeBlocks > p.maxCodeBlocks) violations.push({ check: 'too-many-blocks', detail: `${codeBlocks} code blocks > ${p.maxCodeBlocks}` });
  if (codeLike > p.maxCodeLines) violations.push({ check: 'code-volume', detail: `${codeLike} code-like lines > ${p.maxCodeLines}` });

  return {
    allowed: violations.length === 0,
    violations,
    stats: { chars: msg.length, lines: lines.length, codeLikeLines: codeLike, codeBlocks, secretHits: hits },
  };
}

// Throwing form for the egress client (Step 8). Never includes the raw message in the error.
export function assertEgress(text, policy = {}) {
  const v = inspectEgress(text, policy);
  if (!v.allowed) {
    const names = v.violations.map((x) => x.check).join(', ');
    const err = new Error(`egress blocked (fail-closed): ${names}`);
    err.verdict = v;
    throw err;
  }
  return v;
}

// Self-test: `node src/security/egressGuard.js`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const bigDump = Array.from({ length: 320 }, (_, i) => `  var line${i} = repo.Get(${i});`).join('\n');
  const manyBlocks = Array.from({ length: 9 }, (_, i) => '```\nvar x' + i + ' = 1;\n```').join('\n\n');
  const cases = [
    ['clean summary', 'The UpdateHydrant method in HydrantsController.cs handles the PUT /api/v{version:apiVersion}/Hydrants/{hydrantId} endpoint. It calls VerifyNotFoundCondition and VerifyUnmodifiedCondition, then BuildUpdateHydrantCommand, and dispatches via a CQRS command handler.', true],
    ['file list + relationships', 'Files involved: HydrantsController.cs, HydrantService.cs, UpdateHydrantCommand.cs. The controller depends on ICommandHandlerAsync<UpdateHydrantCommand>. Risk: optimistic concurrency via If-Unmodified-Since.', true],
    ['bounded C# method body (now ALLOWED)', 'public async Task<ActionResult> UpdateHydrant(Guid id) {\n    var cmd = BuildUpdateHydrantCommand(id);\n    await _handler.HandleAsync(cmd);\n    return NoContent();\n}', true],
    ['bounded fenced snippet (now ALLOWED)', 'Here is the relevant code:\n```csharp\nvar x = repo.Get(id);\n```', true],
    ['bounded TS snippet (now ALLOWED)', "```\nimport { Http } from '@angular/common/http';\nconst load = (id) => this.http.get(`/api/hydrants/${id}`);\n```", true],
    ['bounded sql ddl (now ALLOWED)', 'CREATE TABLE Hydrants (\n  Id uniqueidentifier PRIMARY KEY,\n  AgencyId uniqueidentifier\n);', true],
    ['leaked secret (BLOCKED)', 'The service authenticates with token ghp_' + 'a'.repeat(36) + ' to reach GitHub.', false],
    ['wholesale code dump (BLOCKED)', bigDump, false],
    ['too many code blocks (BLOCKED)', manyBlocks, false],
    ['oversize dump (BLOCKED)', 'x'.repeat(25000), false],
  ];
  let pass = 0;
  for (const [label, text, expectAllowed] of cases) {
    const v = inspectEgress(text);
    const ok = v.allowed === expectAllowed;
    if (ok) pass++;
    console.log(`${ok ? 'PASS' : 'FAIL'}  [${label}] allowed=${v.allowed} (expected ${expectAllowed})  ${v.violations.map((x) => x.check).join(',') || '-'}`);
  }
  console.log(`\n[egressGuard] ${pass}/${cases.length} cases passed.`);
  if (pass !== cases.length) process.exit(1);
}
