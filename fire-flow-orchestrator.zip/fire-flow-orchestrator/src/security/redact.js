import { fileURLToPath } from 'node:url';

// Known secret shapes: [type, regex]. Ordered most-specific first.
// Used to scrub secrets out of ANY text before it is read into summaries, embeddings, or logs —
// so a hardcoded key in the source can never reach an embedding, the local LLM, or the egress path.
const PATTERNS = [
  ['private-key', /-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----/g],
  ['github-pat', /\bghp_[A-Za-z0-9]{36}\b/g],
  ['github-pat', /\bgithub_pat_[A-Za-z0-9_]{22,}\b/g],
  ['github-oauth', /\bgh[osur]_[A-Za-z0-9]{36}\b/g],
  ['atlassian', /\bATATT[A-Za-z0-9_\-=.]{16,}\b/g],
  ['aws-key-id', /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/g],
  ['google-api', /\bAIza[0-9A-Za-z\-_]{35}\b/g],
  ['slack', /\bxox[baprs]-[0-9A-Za-z-]{10,}\b/g],
  ['stripe', /\bsk_live_[0-9A-Za-z]{16,}\b/g],
  ['jwt', /\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g],
  ['conn-string', /\b[a-z][a-z0-9+.-]*:\/\/[^\s:@/]+:[^\s:@/]+@/gi], // scheme://user:pass@host
  ['generic-secret', /\b(?:api[_-]?key|secret|token|password|passwd|pwd|bearer)\b\s*[:=]\s*["']?[A-Za-z0-9_\-./+]{12,}["']?/gi],
];

/**
 * Replace every secret-shaped token with ***REDACTED:<type>***.
 * Returns { text, hits } so callers can log how many secrets were scrubbed.
 */
export function redactSecrets(text) {
  if (typeof text !== 'string' || !text) return { text: text ?? '', hits: 0 };
  let out = text;
  let hits = 0;
  for (const [type, re] of PATTERNS) {
    out = out.replace(re, () => {
      hits++;
      return `***REDACTED:${type}***`;
    });
  }
  return { text: out, hits };
}

// Redact and return just the string (when the count isn't needed).
export const redacted = (text) => redactSecrets(text).text;

/**
 * Strip a single KNOWN secret value out of text (e.g. the GitHub PAT in an error message).
 * Promoted from github.js so there is one scrub implementation, used everywhere.
 */
export function scrub(text, secret) {
  return secret ? String(text).split(secret).join('***') : text;
}

// Run directly for a quick self-test: `node src/security/redact.js`
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const sample = [
    `const pat = "ghp_${'a'.repeat(36)}";`,
    `jiraToken: ATATT3xFfGF0aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789`,
    `password = "SuperSecret_value123"`,
    `db = "postgres://admin:hunter2@db.internal:5432/app"`,
    `aws = AKIAIOSFODNN7EXAMPLE`,
    `// normal code: function updateStatus(id) { return repo.get(id); }`,
  ].join('\n');

  const { text, hits } = redactSecrets(sample);
  console.log(`[redact] self-test — secrets found: ${hits}\n`);
  console.log(text);
  console.log(`\n[redact] still contains a raw 'ghp_' token? ${/ghp_[A-Za-z0-9]{36}/.test(text)}`);
}
